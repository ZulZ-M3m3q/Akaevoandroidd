#!/usr/bin/env python3
"""Turns a fresh checkout of jpd002/Play- into AkaiserEvodroid A.1. Fails LOUDLY if an anchor is not found."""
import os, re, sys, shutil, glob

PLAY = os.path.abspath(sys.argv[1]); HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
APP_ID = "com.akaiser.evodroid"; APP_NAME = "AkaiserEvodroid"; VERSION = "A.2"
def log(*a): print("[akevo]", *a, flush=True)
def die(m): print("[akevo] ERROR:", m); sys.exit(1)
def rd(p): return open(p, encoding="utf-8", errors="surrogateescape").read()
def wr(p, s): open(p, "w", encoding="utf-8", errors="surrogateescape").write(s)
def walk(sub, pat):
    for r, d, f in os.walk(os.path.join(PLAY, sub)):
        d[:] = [x for x in d if x not in ("build", ".git", "Dependencies", "node_modules", ".gradle")]
        for n in f:
            if re.search(pat, n): yield os.path.join(r, n)

# 1. copy overlay sources next to Play!'s Android Java sources -------------------------------------
emu = [p for p in walk("Source", r"^EmulatorActivity\.java$")]
if not emu: die("EmulatorActivity.java not found - Play! source layout changed")
jdir = os.path.dirname(emu[0]); dst = os.path.join(jdir, "akevo"); os.makedirs(dst, exist_ok=True)
for f in glob.glob(os.path.join(ROOT, "overlay", "akevo", "*.java")): shutil.copy(f, dst)
log("copied overlay to", dst)

# 2. endpoint auto-detection (Play!'s Arcade I/O HTTP server) --------------------------------------
port, path, method, body, detected = 8080, "/", "POST", "{code}", False
cands = []
for p in list(walk("Source", r"\.(cpp|h|hpp|mm|java)$")):
    try: s = rd(p)
    except Exception: continue
    if "/akevo/" in p.replace(os.sep, "/"): continue          # skip our own files
    if re.search(r"barcode", s, re.I) and re.search(r"http", s, re.I):
        cands.append((p, s))
log("AKEVO endpoint scan: %d candidate files" % len(cands))
for p, s in cands:
    log("  candidate:", os.path.relpath(p, PLAY))
    for m in re.finditer(r"(?:\.|->)(Get|Post|Put)\(\s*(?:R?\"([^\"]*)\")", s):
        log("    route:", m.group(1), m.group(2))
        if not detected:
            method = m.group(1).upper(); path = m.group(2) if m.group(2).startswith("/") else "/" + m.group(2)
            path = re.sub(r"\(\.\*\)|\(\[\^/\]\+\)|\{[a-z_]+\}|:[a-z_]+", "{code}", path); detected = True
    for m in re.finditer(r"(?:listen|bind_to_port)\([^,]*,\s*(\d{3,5})", s):
        log("    port:", m.group(1)); port = int(m.group(1))
    for m in re.finditer(r"(?i)(\w*port\w*)\s*[=:(]\s*(\d{4,5})", s):
        if "http" in m.group(0).lower() or "server" in m.group(1).lower(): log("    port?:", m.group(0))
# Known from Play! source (CSys147::HandleIoServerRequest): POST /sys147/barcode with the 8-char code as body.
port, path, method, body, detected = 8080, "/sys147/barcode", "POST", "{code}", True
tmpl = rd(os.path.join(ROOT, "overlay", "akevo", "AkDefaults.java.template"))
wr(os.path.join(dst, "AkDefaults.java"), tmpl.replace("@PORT@", str(port)).replace("@PATH@", path).replace("@METHOD@", method).replace("@BODY@", body).replace("@DETECTED@", "true" if detected else "false"))
os.remove(os.path.join(dst, "AkDefaults.java.template")) if os.path.exists(os.path.join(dst, "AkDefaults.java.template")) else None
log("endpoint defaults: %s http://127.0.0.1:%d%s detected=%s" % (method, port, path, detected))

# 3. hook the overlay into EmulatorActivity.onCreate ----------------------------------------------
s = rd(emu[0]); HOOK = "com.virtualapplications.play.akevo.AkOverlay.attach(this);"
if HOOK not in s:
    m = re.search(r"super\.onCreate\([^;]*\);", s)
    if not m: die("super.onCreate(...) not found in EmulatorActivity.java")
    s = s[:m.end()] + "\n\t\t" + HOOK + s[m.end():]; wr(emu[0], s)
log("hooked EmulatorActivity")

# 4. manifest ----------------------------------------------------------------------------------------
mans = [p for p in walk(".", r"^AndroidManifest\.xml$") if ("EmulatorActivity" in rd(p) or "virtualapplications" in rd(p))]
if not mans: die("AndroidManifest.xml not found")
man = mans[0]; m = rd(man)
if "AkImportActivity" not in m:
    add = ('\n\t<activity android:name="com.virtualapplications.play.akevo.AkSettingsActivity" android:exported="false" android:label="AkaiserEvodroid Settings" android:theme="@android:style/Theme.Material.Light.NoActionBar"/>'
           '\n\t<activity android:name="com.virtualapplications.play.akevo.AkImportActivity" android:exported="false" android:theme="@android:style/Theme.Material.Light.NoActionBar"/>'
           '\n\t<activity android:name="com.virtualapplications.play.akevo.AkScanActivity" android:exported="false" android:theme="@style/Theme.AppCompat.NoActionBar"/>\n')
    if "</application>" not in m: die("</application> not in manifest")
    m = m.replace("</application>", add + "</application>", 1)
    perms = ""
    for pm in ("android.permission.CAMERA", "android.permission.INTERNET", "android.permission.VIBRATE"):
        if pm not in m: perms += '\n\t<uses-permission android:name="%s"/>' % pm
    m = re.sub(r"(<manifest[^>]*>)", lambda x: x.group(1) + perms, m, 1)
    m = re.sub(r'(<application[^>]*?android:label=")[^"]*(")', r"\g<1>%s\2" % APP_NAME, m, 1)
    wr(man, m)
log("patched manifest", os.path.relpath(man, PLAY))

# 5. app name / id / version / dependencies -------------------------------------------------------------
for p in walk(".", r"^strings\.xml$"):
    if "/deps/" in p.replace(os.sep, "/"): continue
    t = rd(p)
    if 'name="app_name"' in t:
        wr(p, re.sub(r'(<string name="app_name"[^>]*>)[^<]*(</string>)', r"\g<1>%s\2" % APP_NAME, t)); log("app_name in", os.path.relpath(p, PLAY))
allg = [p for p in walk("build_android", r"^build\.gradle(\.kts)?$") if "/Dependencies/" not in p.replace(os.sep, "/")]
log("gradle files under build_android:", [os.path.relpath(x, PLAY) for x in allg])
deps = ["androidx.camera:camera-core:1.3.4", "androidx.camera:camera-camera2:1.3.4", "androidx.camera:camera-lifecycle:1.3.4",
        "androidx.camera:camera-view:1.3.4", "com.google.mlkit:barcode-scanning:17.3.0"]
id_done = False
for g in allg:
    t = rd(g); kts = g.endswith(".kts"); orig = t
    idline = ('applicationId = "%s"' if kts else 'applicationId "%s"') % APP_ID
    if re.search(r"applicationId\s*=?\s*[\"']", t):
        t = re.sub(r"applicationId\s*=?\s*[\"'][^\"']+[\"']", idline, t, 1); id_done = True
    else:
        m3 = re.search(r"defaultConfig\s*\{", t)
        if m3 and "android" in t:
            t = t[:m3.end()] + "\n        " + idline + t[m3.end():]; id_done = True
            log("inserted applicationId into", os.path.relpath(g, PLAY))
    if re.search(r"versionName\s*=?\s*[\"']", t):
        t = re.sub(r"versionName\s*=?\s*[\"'][^\"']*[\"']", ('versionName = "%s"' if kts else 'versionName "%s"') % VERSION, t, 1)
    if t != orig: wr(g, t); log("patched", os.path.relpath(g, PLAY))
if not id_done: log("WARNING: could not set applicationId - app keeps Play!'s package name")
# make sure no hard-coded provider authorities collide with the original Play! app
for mf in walk("build_android", r"^AndroidManifest\.xml$"):
    t = rd(mf)
    if "com.virtualapplications.play." in t and "authorities" in t:
        log("NOTE manifest has fixed authorities:", os.path.relpath(mf, PLAY), re.findall(r'authorities="([^"]+)"', t))
# 7. arcade support: boot *.arcadedef through Play!'s own ArcadeUtils ------------------------------------------
NATIVE_CODE = r'''
// ===== AkaiserEvodroid arcade support (appended by apply_patches.py) =====
#include <android/log.h>

extern "C" JNIEXPORT void JNICALL Java_com_virtualapplications_play_akevo_AkArcade_nativeRegister(JNIEnv* env, jclass clazz, jstring defPathJ, jstring titleJ)
{
	try
	{
		auto defPath = fs::path(GetStringFromJstring(env, defPathJ));
		auto title = GetStringFromJstring(env, titleJ);
		BootablesDb::CClient::GetInstance().RegisterBootable(defPath, "", "", BootableUtils::PS2_ARCADE);
		BootablesDb::CClient::GetInstance().SetTitle(defPath, title.c_str());
	}
	catch(const std::exception& exception)
	{
		__android_log_print(ANDROID_LOG_WARN, "AkArcade", "nativeRegister failed: %s", exception.what());
	}
}

static void AkLogStep(const std::string& text, bool truncate = false)
{
	try
	{
		auto path = Framework::PathUtils::GetPersonalDataPath() / "akevo_boot.log";
		FILE* f = fopen(path.string().c_str(), truncate ? "w" : "a");
		if(!f) return;
		fprintf(f, "%s\n", text.c_str());
		fclose(f);
	}
	catch(...)
	{
	}
}

extern "C" JNIEXPORT void JNICALL Java_com_virtualapplications_play_akevo_AkArcade_nativeBoot(JNIEnv* env, jclass clazz, jstring defPathJ, jstring romsDirJ, jint port)
{
	assert(g_virtualMachine != nullptr);
	try
	{
		AkLogStep("1 nativeBoot start", true);
		auto defPath = fs::path(GetStringFromJstring(env, defPathJ));
		auto romsDir = fs::path(GetStringFromJstring(env, romsDirJ));
		AkLogStep("   def=" + defPath.string() + " roms=" + romsDir.string());
		auto& config = CAppConfig::GetInstance();
		try { config.SetPreferencePath(PREF_PS2_ARCADEROMS_DIRECTORY, romsDir); } catch(...) { AkLogStep("   WARN could not set arcade roms dir"); }
		try { config.SetPreferenceBoolean(PREF_PS2_ARCADE_IO_SERVER_ENABLED, true); } catch(...) { AkLogStep("   WARN could not enable io server"); }
		try { config.SetPreferenceInteger(PREF_PS2_ARCADE_IO_SERVER_PORT, port); } catch(...) { AkLogStep("   WARN could not set io server port"); }
		AkLogStep("2 preferences set");
		g_virtualMachine->Pause();
		g_virtualMachine->ReloadSpuBlockCount();
		g_virtualMachine->ReloadFrameRateLimit();
		SetupSoundHandler();
		AkLogStep("3 calling BootArcadeMachine");
		ArcadeUtils::BootArcadeMachine(g_virtualMachine, defPath);
		AkLogStep("4 BootArcadeMachine returned");
		g_virtualMachine->Pause();
		AkLogStep("5 DONE (machine paused, waiting for the screen)");
	}
	catch(const std::exception& exception)
	{
		AkLogStep(std::string("EXCEPTION: ") + exception.what());
		jclass exceptionClass = env->FindClass("java/lang/Exception");
		env->ThrowNew(exceptionClass, exception.what());
	}
}
'''
ni = list(walk("Source", r"^NativeInterop\.cpp$"))
if not ni: die("NativeInterop.cpp not found")
t = rd(ni[0])
if "AkArcade" not in t:
    inc = '#include "ui_shared/StatsManager.h"'
    if inc not in t: die("anchor include not found in NativeInterop.cpp")
    t = t.replace(inc, inc + '\n#include "ui_shared/ArcadeUtils.h"\n#include "ui_shared/BootablesDbClient.h"\n#include "ui_shared/BootableUtils.h"', 1)
    t = t.rstrip() + "\n" + NATIVE_CODE
    wr(ni[0], t)
log("native arcade functions added to", os.path.relpath(ni[0], PLAY))

au = list(walk("Source", r"^ArcadeUtils\.cpp$"))
if not au: die("ArcadeUtils.cpp not found")
t = rd(au[0]); needle = 'Framework::PathUtils::GetAppResourcesPath() / "arcadedefs"'
if needle not in t: die("arcadedefs path anchor not found in ArcadeUtils.cpp")
t = t.replace(needle, 'fs::path("/")')   # arcadedef is passed as an absolute path; "/" / "/abs/path" == "/abs/path"
if "#ifndef DEBUGGER_INCLUDED" not in t: die("DEBUGGER_INCLUDED anchor not found in ArcadeUtils.cpp")
t = t.replace("#ifndef DEBUGGER_INCLUDED", "#if !defined(DEBUGGER_INCLUDED) && !defined(__ANDROID__)")   # Android resumes the VM itself once the screen exists
wr(au[0], t); log("ArcadeUtils.cpp: arcadedefs now resolved from absolute path")

vm = list(walk("Source", r"^VirtualMachineManager\.java$"))
if not vm: die("VirtualMachineManager.java not found")
t = rd(vm[0]); needle = "if(BootablesInterop.IsBootableExecutablePath(_bootablePath))"
if needle not in t: die("launch anchor not found in VirtualMachineManager.java")
if "AkArcade" not in t:
    t = t.replace(needle, 'if(_bootablePath.endsWith(".arcadedef"))\n\t\t\t\t{\n\t\t\t\t\tcom.virtualapplications.play.akevo.AkArcade.boot(_ctx);\n\t\t\t\t}\n\t\t\t\telse ' + needle, 1)
    wr(vm[0], t)
log("hooked VirtualMachineManager (arcade launch)")

ma = list(walk("Source", r"^MainActivity\.java$"))
if not ma: die("MainActivity.java not found")
t = rd(ma[0]); needle = "NativeInterop.setContentResolver(getApplicationContext().getContentResolver());"
if needle not in t: die("setContentResolver anchor not found in MainActivity.java")
if "AkArcade" not in t:
    t = t.replace(needle, needle + "\n\t\ttry { com.virtualapplications.play.akevo.AkArcade.register(this); } catch(Throwable akT) { }", 1)
    wr(ma[0], t)
log("hooked MainActivity (arcade registration + import prompt)")

log("DONE - AkaiserEvodroid", VERSION)

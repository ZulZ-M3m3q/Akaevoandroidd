package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import java.io.File;
import java.io.FileOutputStream;

/** Arcade support glue: embeds the Animal Kaiser Evolution definition, keeps the game file in app storage, boots through Play!'s ArcadeUtils. */
public final class AkArcade {
    public static final String GAME_ID = "akaievo";
    public static final String TITLE = "Animal Kaiser Evolution";
    public static final String NAND_NAME = "kp012b_k9k8g08u0b.ic31";
    private static boolean promptShown = false;

    private static final String DEF_JSON =
        "{\"id\":\"akaievo\",\"name\":\"Animal Kaiser Evolution\",\"driver\":\"sys147\",\"nand\":{\"name\":\"kp012b_k9k8g08u0b"
        + ".ic31\",\"mounts\":{\"atfile0\":24576,\"atfile1\":65536,\"atfile2\":131072,\"atfile3\":196608,\"atfile4\":262144,"
        + "\"atfile5\":327680,\"atfile6\":393216}},\"buttons\":{\"108\":\"0:l1\",\"109\":\"0:cross\",\"110\":\"0:dpad_up\",\"111\":"
        + "\"0:dpad_down\",\"116\":\"0:dpad_left\",\"117\":\"0:dpad_right\",\"118\":\"1:dpad_right\",\"119\":\"1:dpad_left\"},\"bo"
        + "ot\":\"atfile0:main.elf\",\"patches\":[{\"address\":\"0x001021E8\",\"value\":\"0x0\",\"description\":\"Prevent stori"
        + "ng dispenser jammed & no cards\"},{\"address\":\"0x00102208\",\"value\":\"0x0\",\"description\":\"Prevent storin"
        + "g dispenser jammed & no cards\"},{\"address\":\"0x0015FA18\",\"value\":\"0x0\",\"description\":\"Fake IC card ke"
        + "y parity & checksum success\"},{\"address\":\"0x0015FC20\",\"value\":\"0x0\",\"description\":\"Fake IC card key "
        + "parity & checksum success\"},{\"address\":\"0x001D8A0C\",\"value\":\"0x24027FFF\",\"description\":\"Set audio le"
        + "vel to 7\"},{\"address\":\"0x001051b4\",\"value\":\"0x240F02BC\",\"description\":\"Evo 1\"}]}";

    private static native void nativeRegister(String defPath, String title);
    private static native void nativeBoot(String defPath, String romsDir, int port);

    public static File defFile(Context c) { return new File(new File(c.getFilesDir(), "arcadedefs"), GAME_ID + ".arcadedef"); }
    public static File romsRoot(Context c) { return new File(c.getFilesDir(), "arcaderoms"); }
    public static File romDir(Context c) { return new File(romsRoot(c), GAME_ID); }
    public static File nandFile(Context c) { return new File(romDir(c), NAND_NAME); }
    public static boolean hasNand(Context c) { File f = nandFile(c); return f.isFile() && f.length() > 1024 * 1024; }

    private static void writeDef(Context c) throws Exception {
        File f = defFile(c); f.getParentFile().mkdirs();
        FileOutputStream o = new FileOutputStream(f); o.write(DEF_JSON.getBytes("UTF-8")); o.close();
        romDir(c).mkdirs();
    }

    /** Called from MainActivity.onCreate: puts the game in the list, and asks for the game file if it is missing. */
    public static void register(final Activity a) {
        try {
            writeDef(a);
            nativeRegister(defFile(a).getAbsolutePath(), TITLE);
        } catch (Throwable t) { android.util.Log.w("AkArcade", "register failed", t); return; }
        if (!hasNand(a) && !promptShown) {
            promptShown = true;
            try {
                new AlertDialog.Builder(a).setTitle(TITLE)
                    .setMessage("Choose your game file (" + NAND_NAME + ") once. The app copies it into its own storage (about 1 GB), so keep some free space.")
                    .setPositiveButton("Choose file", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                        a.startActivity(new Intent(a, AkImportActivity.class)); } })
                    .setNegativeButton("Later", null).show();
            } catch (Throwable ignored) { }
        }
    }

    /** Called from VirtualMachineManager for *.arcadedef bootables. Throws with a readable message on failure. */
    public static void boot(Context c) throws Exception {
        writeDef(c);
        if (!hasNand(c))
            throw new Exception("The game file " + NAND_NAME + " has not been imported yet. Restart the app and choose 'Choose file', or use Settings > Import.");
        nativeBoot(defFile(c).getAbsolutePath(), romsRoot(c).getAbsolutePath(), AkConfig.port(c));
    }
}

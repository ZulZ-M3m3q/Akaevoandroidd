package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** The AKaiserEvodroid launcher screen: landscape, wallpaper, 3-bar side menu, version picker + PLAY button, launcher song. */
public final class AkLauncher {
    private static MediaPlayer player;
    private static Activity launcher;
    private static boolean callbacksRegistered;

    private static FrameLayout root, menuScrim, versionScrim;
    private static LinearLayout menuPanel;
    private static TextView versionBtn, muteItem;
    private static final java.util.ArrayList<TextView> tiles = new java.util.ArrayList<TextView>();
    private static boolean menuOpen, versionOpen;
    private static androidx.activity.OnBackPressedCallback backCb;

    // ------------------------------------------------------------------ helpers
    private static GradientDrawable box(int color, float radiusDp, int strokeColor, float strokeDp, float d) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radiusDp * d);
        if (strokeDp > 0) g.setStroke(Math.max(1, (int) (strokeDp * d)), strokeColor);
        return g;
    }

    private static final class Bars extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bars(Context c) { super(c); p.setColor(0xFFFFFFFF); p.setStrokeCap(Paint.Cap.ROUND); }
        @Override protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(); p.setStrokeWidth(h * 0.085f);
            for (int i = 0; i < 3; i++) { float y = h * (0.33f + 0.17f * i); cv.drawLine(w * 0.27f, y, w * 0.73f, y, p); }
        }
    }

    private static String shortName(String id) { String n = id.substring(AkArcade.GAME_ID.length()); return "Evolution " + (n.length() == 0 ? "1" : n); }
    private static String numberOf(String id) { String n = id.substring(AkArcade.GAME_ID.length()); return n.length() == 0 ? "1" : n; }

    // ------------------------------------------------------------------ music
    private static void startMusic(Context c) {
        try {
            if (AkConfig.muteSong(c)) { pauseMusic(); return; }
            if (player == null) {
                player = MediaPlayer.create(c.getApplicationContext(), com.virtualapplications.play.R.raw.ak_launcher_song);
                if (player != null) { player.setLooping(true); player.setVolume(0.7f, 0.7f); }
            }
            if (player != null && !player.isPlaying()) player.start();
        } catch (Throwable ignored) { }
    }
    private static void pauseMusic() { try { if (player != null && player.isPlaying()) player.pause(); } catch (Throwable ignored) { } }
    private static void stopMusic() { try { if (player != null) player.release(); } catch (Throwable ignored) { } player = null; }

    private static void registerCallbacks(Activity a) {
        if (callbacksRegistered) return; callbacksRegistered = true;
        a.getApplication().registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            public void onActivityResumed(Activity x) { if (x == launcher) startMusic(x); }
            public void onActivityPaused(Activity x) { if (x == launcher) pauseMusic(); }          // game / settings opened, or app sent to background
            public void onActivityDestroyed(Activity x) { if (x == launcher) { stopMusic(); launcher = null; } }
            public void onActivityCreated(Activity x, Bundle b) { }
            public void onActivityStarted(Activity x) { }
            public void onActivityStopped(Activity x) { }
            public void onActivitySaveInstanceState(Activity x, Bundle b) { }
        });
    }

    // ------------------------------------------------------------------ version
    private static String selectedId(Context c) {
        String v = AkConfig.launchVersion(c);
        for (String id : AkDefs.IDS) if (id.equals(v)) return v;
        return AkDefs.IDS[AkDefs.IDS.length - 1];
    }

    private static void refreshVersion(Context c) {
        String sel = selectedId(c);
        if (versionBtn != null) versionBtn.setText(shortName(sel) + "  \u25BC");
        float d = c.getResources().getDisplayMetrics().density;
        for (TextView t : tiles) {
            boolean on = sel.equals(t.getTag());
            t.setBackground(box(on ? 0xFF2EA043 : 0xFF263238, 14, on ? 0xFFF2B705 : 0x55FFFFFF, on ? 3 : 1, d));
        }
    }

    // ------------------------------------------------------------------ open / close panels
    private static void updateBack() { if (backCb != null) backCb.setEnabled(menuOpen || versionOpen); }

    private static void openMenu(Activity a) {
        float d = a.getResources().getDisplayMetrics().density;
        menuScrim.setVisibility(View.VISIBLE); menuOpen = true; updateBack();
        menuPanel.setTranslationX(-300 * d); menuPanel.animate().translationX(0).setDuration(170).start();
    }
    private static void closeMenu(Activity a) {
        if (!menuOpen) return; menuOpen = false; updateBack();
        float d = a.getResources().getDisplayMetrics().density;
        menuPanel.animate().translationX(-300 * d).setDuration(150).withEndAction(new Runnable() { public void run() { if (!menuOpen) menuScrim.setVisibility(View.GONE); } }).start();
    }
    private static void setVersionOpen(boolean on) { versionOpen = on; versionScrim.setVisibility(on ? View.VISIBLE : View.GONE); updateBack(); }

    // ------------------------------------------------------------------ actions
    private static void play(Activity a) {
        if (!AkArcade.hasNand(a)) {
            Toast.makeText(a, "Choose your game file first", Toast.LENGTH_LONG).show();
            a.startActivity(new Intent(a, AkImportActivity.class)); return;
        }
        try {
            if (a instanceof com.virtualapplications.play.MainActivity)
                ((com.virtualapplications.play.MainActivity) a).akLaunch(AkArcade.defFile(a, selectedId(a)).getAbsolutePath());
        } catch (Throwable t) { Toast.makeText(a, "Could not start: " + t.getMessage(), Toast.LENGTH_LONG).show(); }
    }

    private static TextView menuRow(final Activity a, String text, final Runnable action, float d) {
        TextView t = new TextView(a); t.setText(text); t.setTextColor(0xFFFFFFFF); t.setTextSize(15);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding((int) (20 * d), 0, (int) (16 * d), 0);
        t.setMinHeight((int) (54 * d)); t.setClickable(true);
        t.setBackground(box(0x00000000, 0, 0, 0, d));
        t.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { closeMenu(a); action.run(); } });
        return t;
    }

    private static void updateMuteLabel(Context c) { if (muteItem != null) muteItem.setText(AkConfig.muteSong(c) ? "Launcher song: OFF (tap to turn on)" : "Launcher song: ON (tap to mute)"); }

    // ------------------------------------------------------------------ build
    public static void attach(final Activity a) {
        try { build(a); } catch (Throwable t) { android.util.Log.w("AkLauncher", "launcher UI failed", t); }
    }

    private static void build(final Activity a) {
        if (AkDefs.IDS.length == 0) return;
        launcher = a; registerCallbacks(a); tiles.clear(); menuOpen = false; versionOpen = false;
        a.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        try { a.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); } catch (Throwable ignored) { }
        final float d = a.getResources().getDisplayMetrics().density;
        final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

        root = new FrameLayout(a); root.setBackgroundColor(0xFF000000); root.setClickable(true);
        ImageView bg = new ImageView(a); bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bg.setImageResource(com.virtualapplications.play.R.drawable.ak_launcher_bg);
        root.addView(bg, new FrameLayout.LayoutParams(MATCH, MATCH));

        // soft shade at the bottom so the buttons stay readable
        View shade = new View(a);
        GradientDrawable sg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0x00000000, 0xB0000000});
        shade.setBackground(sg);
        root.addView(shade, new FrameLayout.LayoutParams(MATCH, (int) (140 * d), Gravity.BOTTOM));

        // 3-bar menu button (top left)
        FrameLayout burger = new FrameLayout(a); burger.setBackground(box(0xAA000000, 14, 0x66FFFFFF, 1, d)); burger.setClickable(true);
        burger.addView(new Bars(a), new FrameLayout.LayoutParams(MATCH, MATCH));
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams((int) (54 * d), (int) (54 * d), Gravity.TOP | Gravity.START);
        blp.setMargins((int) (20 * d), (int) (16 * d), 0, 0);
        burger.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openMenu(a); } });
        root.addView(burger, blp);

        // bottom right: [version] [PLAY]
        LinearLayout bar = new LinearLayout(a); bar.setOrientation(LinearLayout.HORIZONTAL); bar.setGravity(Gravity.CENTER_VERTICAL);
        versionBtn = new TextView(a); versionBtn.setTextColor(0xFFFFFFFF); versionBtn.setTextSize(17); versionBtn.setTypeface(Typeface.DEFAULT_BOLD);
        versionBtn.setGravity(Gravity.CENTER); versionBtn.setBackground(box(0xCC10171E, 28, 0xFFF2B705, 2, d)); versionBtn.setClickable(true);
        versionBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setVersionOpen(true); } });
        bar.addView(versionBtn, new LinearLayout.LayoutParams((int) (190 * d), (int) (56 * d)));
        TextView playBtn = new TextView(a); playBtn.setText("PLAY  \u25B6"); playBtn.setTextColor(0xFFFFFFFF); playBtn.setTextSize(22); playBtn.setTypeface(Typeface.DEFAULT_BOLD);
        playBtn.setGravity(Gravity.CENTER); playBtn.setClickable(true);
        playBtn.setBackground(box(0xFF2EA043, 28, 0xFFB7F5C0, 2, d));
        playBtn.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { play(a); } });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams((int) (170 * d), (int) (56 * d)); plp.setMargins((int) (14 * d), 0, 0, 0);
        bar.addView(playBtn, plp);
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.END);
        barLp.setMargins(0, 0, (int) (26 * d), (int) (22 * d));
        root.addView(bar, barLp);

        // ---- version picker (grid of versions)
        versionScrim = new FrameLayout(a); versionScrim.setBackgroundColor(0xB0000000); versionScrim.setClickable(true); versionScrim.setVisibility(View.GONE);
        versionScrim.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { setVersionOpen(false); } });
        LinearLayout card = new LinearLayout(a); card.setOrientation(LinearLayout.VERTICAL); card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setBackground(box(0xF0101820, 20, 0x88FFFFFF, 1, d)); card.setPadding((int) (22 * d), (int) (18 * d), (int) (22 * d), (int) (20 * d)); card.setClickable(true);
        TextView title = new TextView(a); title.setText("Select Animal Kaiser Evolution version"); title.setTextColor(0xFFFFFFFF); title.setTextSize(18); title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER); card.addView(title, new LinearLayout.LayoutParams(WRAP, WRAP));
        final int cols = 4; LinearLayout row = null;
        for (int i = 0; i < AkDefs.IDS.length; i++) {
            if (i % cols == 0) { row = new LinearLayout(a); row.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(WRAP, WRAP); rl.setMargins(0, (int) (14 * d), 0, 0); card.addView(row, rl); }
            final String id = AkDefs.IDS[i];
            TextView t = new TextView(a); t.setText("Evolution\n" + numberOf(id)); t.setTag(id); t.setGravity(Gravity.CENTER); t.setTextColor(0xFFFFFFFF); t.setTextSize(16); t.setTypeface(Typeface.DEFAULT_BOLD); t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { AkConfig.put(a, "launch_version", id); refreshVersion(a); setVersionOpen(false); } });
            LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams((int) (104 * d), (int) (74 * d)); tl.setMargins((int) (6 * d), 0, (int) (6 * d), 0);
            row.addView(t, tl); tiles.add(t);
        }
        versionScrim.addView(card, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
        root.addView(versionScrim, new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- side menu
        menuScrim = new FrameLayout(a); menuScrim.setBackgroundColor(0x99000000); menuScrim.setClickable(true); menuScrim.setVisibility(View.GONE);
        menuScrim.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { closeMenu(a); } });
        menuPanel = new LinearLayout(a); menuPanel.setOrientation(LinearLayout.VERTICAL); menuPanel.setBackgroundColor(0xF00B1117); menuPanel.setClickable(true);
        TextView head = new TextView(a); head.setText("AKaiserEvodroid"); head.setTextColor(0xFFF2B705); head.setTextSize(20); head.setTypeface(Typeface.DEFAULT_BOLD);
        head.setPadding((int) (20 * d), (int) (20 * d), (int) (16 * d), (int) (12 * d)); menuPanel.addView(head);
        final com.virtualapplications.play.MainActivity main = (a instanceof com.virtualapplications.play.MainActivity) ? (com.virtualapplications.play.MainActivity) a : null;
        menuPanel.addView(menuRow(a, "Emulator & graphics settings", new Runnable() { public void run() { if (main != null) main.akOpenPlaySettings(); } }, d));
        menuPanel.addView(menuRow(a, "AKaiserEvodroid settings (controls, card server, audio)", new Runnable() { public void run() { a.startActivity(new Intent(a, AkSettingsActivity.class)); } }, d));
        menuPanel.addView(menuRow(a, "Import / replace game file", new Runnable() { public void run() { a.startActivity(new Intent(a, AkImportActivity.class)); } }, d));
        muteItem = menuRow(a, "", new Runnable() { public void run() { AkConfig.put(a, "mute_song", !AkConfig.muteSong(a)); updateMuteLabel(a); startMusic(a); } }, d);
        menuPanel.addView(muteItem); updateMuteLabel(a);
        menuPanel.addView(menuRow(a, "About", new Runnable() { public void run() { if (main != null) main.akOpenAbout(); } }, d));
        menuPanel.addView(menuRow(a, "Join our Discord server", new Runnable() { public void run() { AkArcade.openLink(a, AkArcade.URL_DISCORD); } }, d));
        menuPanel.addView(menuRow(a, "Instagram: zull_bixie", new Runnable() { public void run() { AkArcade.openLink(a, AkArcade.URL_INSTAGRAM); } }, d));
        menuPanel.addView(menuRow(a, "TikTok: bixieredpixiu", new Runnable() { public void run() { AkArcade.openLink(a, AkArcade.URL_TIKTOK); } }, d));
        menuScrim.addView(menuPanel, new FrameLayout.LayoutParams((int) (300 * d), MATCH, Gravity.START));
        root.addView(menuScrim, new FrameLayout.LayoutParams(MATCH, MATCH));

        refreshVersion(a);
        a.addContentView(root, new ViewGroup.LayoutParams(MATCH, MATCH));

        if (a instanceof androidx.appcompat.app.AppCompatActivity) {
            backCb = new androidx.activity.OnBackPressedCallback(false) {
                @Override public void handleOnBackPressed() { if (versionOpen) setVersionOpen(false); else if (menuOpen) closeMenu(a); }
            };
            ((androidx.appcompat.app.AppCompatActivity) a).getOnBackPressedDispatcher().addCallback((androidx.appcompat.app.AppCompatActivity) a, backCb);
        }
        startMusic(a);
    }
}

package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.widget.Toast;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A.24 account link through the Discord bot, with NO website and NO server.
 * The app shows an 8-character code. The player sends it to the Discord bot (/link). The bot answers with an unlock key
 * (AK1.payload.signature) signed with a private key that only the bot owner has. The app checks the signature with the public key
 * built into it (AkDefaults.PUBKEY), checks that the key was made for THIS phone's code and that it has not expired, and unlocks.
 * Everything is checked on the phone, so it works offline. Without the bot's private key nobody can make a valid key.
 */
public final class AkLink {
    public static final int LINKED = 1, NOT_LINKED = 2, OFFLINE = 3, NOT_CONFIGURED = 4;
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final Pattern KEY = Pattern.compile("AK1\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+");

    public static final class Status {
        public int state;
        public String username = "", code = "", message = "";
        public int expiresIn;
        public long keyExpiresMs;       // 0 = the key never expires
    }
    public interface Cb { void done(Status s); }
    public interface Msg { void done(boolean ok, String message); }

    private static SharedPreferences sp(Context c) { return AkConfig.sp(c); }

    /** True when this build contains the bot's public key (the unlock_public_key box of the build workflow). */
    public static boolean configured(Context c) { return AkDefaults.PUBKEY.trim().length() > 40; }

    // ------------------------------------------------------------------ link code made by the app itself
    private static final String CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";   // no 0/O/1/I, same as the bot
    private static final long CODE_TTL_MS = 15L * 60 * 1000;

    /** The 8-character code of this phone (kept 15 min, then replaced; the previous one is still accepted once). */
    public static synchronized String localCode(Context c) {
        long t = System.currentTimeMillis();
        String code = sp(c).getString("dev_code", ""); long exp = sp(c).getLong("dev_code_exp", 0);
        if (code.length() == 8 && exp > t + 30000 && exp <= t + CODE_TTL_MS + 60000) return code;   // still good (and the clock was not moved)
        SecureRandom r = new SecureRandom(); StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) sb.append(CODE_ALPHABET.charAt(r.nextInt(CODE_ALPHABET.length())));
        String fresh = sb.toString();
        sp(c).edit().putString("dev_code_prev", code).putString("dev_code", fresh).putLong("dev_code_exp", t + CODE_TTL_MS).commit();
        return fresh;
    }
    public static String pretty(String code) { return code != null && code.length() == 8 ? code.substring(0, 4) + "-" + code.substring(4) : (code == null ? "" : code); }

    // ------------------------------------------------------------------ unlock key
    private static final class Parsed { boolean sigOk; String code = "", userId = "", name = ""; long expSec; }

    /** Reads and verifies "AK1.payload.signature" found anywhere inside text. Returns null when there is no key in the text. */
    private static Parsed parse(Context c, String text) {
        if (text == null) return null;
        Matcher m = KEY.matcher(text);
        if (!m.find()) return null;
        Parsed p = new Parsed();
        try {
            String[] part = m.group().split("\\.");
            int fl = Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING;
            PublicKey pub = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.decode(AkDefaults.PUBKEY.trim(), Base64.DEFAULT)));
            Signature s = Signature.getInstance("SHA256withECDSA");
            s.initVerify(pub); s.update((part[0] + "." + part[1]).getBytes("UTF-8"));
            p.sigOk = s.verify(Base64.decode(part[2], fl));
            String[] f = new String(Base64.decode(part[1], fl), "UTF-8").split("\\|", 4);
            if (f.length < 4) { p.sigOk = false; return p; }
            p.code = f[0]; p.userId = f[1]; p.expSec = Long.parseLong(f[2]); p.name = f[3];
        } catch (Throwable t) { p.sigOk = false; }
        return p;
    }

    private static boolean expired(Parsed p) { return p.expSec != 0 && System.currentTimeMillis() / 1000 >= p.expSec; }

    /** Player pasted / copied an unlock key. Returns a message for the player; ok is true when the phone is now unlocked. */
    public static void submitKey(Context c0, String text, Msg cb) {
        Context c = c0.getApplicationContext();
        Parsed p = configured(c) ? parse(c, text) : null;
        if (!configured(c)) { cb.done(false, "This build has no bot key. Rebuild the app and fill in unlock_public_key."); return; }
        if (p == null) { cb.done(false, "No unlock key found. Copy the bot's whole message first."); return; }
        if (!p.sigOk) { cb.done(false, "That key is not valid for this app."); return; }
        if (expired(p)) { cb.done(false, "That key has expired. Send the code to the bot again."); return; }
        String cur = sp(c).getString("dev_code", ""), prev = sp(c).getString("dev_code_prev", "");
        if (!p.code.equals(cur) && !p.code.equals(prev)) { cb.done(false, "That key was made for another code. Send the code shown on THIS screen to the bot."); return; }
        sp(c).edit().putString("link_token", text == null ? "" : firstKey(text)).putString("link_code", p.code).putString("link_user", p.name)
            .putLong("link_exp", p.expSec * 1000L).remove("dev_code").remove("dev_code_exp").remove("dev_code_prev").commit();
        cb.done(true, "Unlocked as " + p.name + ".");
    }
    private static String firstKey(String text) { Matcher m = KEY.matcher(text); return m.find() ? m.group() : ""; }

    // ------------------------------------------------------------------ state (all local)
    /** True when a valid, unexpired unlock key made for this phone is stored. Re-checked on every call. */
    public static boolean isUsable(Context c) {
        if (!configured(c)) return false;
        String tok = sp(c).getString("link_token", "");
        if (tok.length() == 0) return false;
        Parsed p = parse(c, tok);
        return p != null && p.sigOk && !expired(p) && p.code.equals(sp(c).getString("link_code", ""));
    }
    public static boolean linkedCached(Context c) { return isUsable(c); }
    public static String username(Context c) { return sp(c).getString("link_user", ""); }

    public static Intent linkIntent(Context c, boolean fromPlay) {
        Intent i = new Intent(c, AkLinkActivity.class);
        i.putExtra(AkLinkActivity.EXTRA_FROM_PLAY, fromPlay);
        return i;
    }

    /** Where this phone stands. Local only; the callback runs on the UI thread. */
    public static void status(Context c0, final Cb cb) {
        final Context c = c0.getApplicationContext();
        final Status s = new Status();
        if (!configured(c)) { s.state = NOT_CONFIGURED; s.message = "This build has no bot key. Rebuild the app and fill in unlock_public_key."; }
        else if (isUsable(c)) { s.state = LINKED; s.username = username(c); s.keyExpiresMs = sp(c).getLong("link_exp", 0); }
        else {
            s.state = NOT_LINKED; s.code = pretty(localCode(c));
            s.expiresIn = (int) Math.max(0, (sp(c).getLong("dev_code_exp", 0) - System.currentTimeMillis()) / 1000);
        }
        UI.post(new Runnable() { public void run() { cb.done(s); } });
    }

    /** Called by PLAY: runs ok when the phone is unlocked, otherwise opens the link screen. */
    public static void requireLinked(final Activity a, final Runnable ok) {
        if (configured(a) && isUsable(a)) { ok.run(); return; }
        if (configured(a) && sp(a).getString("link_token", "").length() > 0) Toast.makeText(a, "Your unlock key has expired. Link again with the Discord bot.", Toast.LENGTH_LONG).show();
        a.startActivity(linkIntent(a, true));
    }

    public static void unlink(Context c0, Msg cb) {
        sp(c0.getApplicationContext()).edit().remove("link_token").remove("link_code").remove("link_user").remove("link_exp").commit();
        cb.done(true, "This device is unlocked no more. The game will ask for a new code next time.");
    }

    /** There is no server any more: play time is simply dropped (200 = "taken", so the queue does not grow). */
    public static int postPlaytime(Context c, String json) { return 200; }
    /** There is no server any more: the card collection stays on the phone. */
    public static String postCollection(Context c, String json) { return null; }
}

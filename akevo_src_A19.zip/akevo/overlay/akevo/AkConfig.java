package com.virtualapplications.play.akevo;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** All AkaiserEvodroid settings + button-layout profiles (stored in SharedPreferences). */
public final class AkConfig {
    public static final String VERSION = "A.19";
    public static boolean editRequested = false;   // set by settings, consumed by overlay on resume

    public static final class Btn {
        public String id, label;
        public float x, y;     // centre, fraction of screen (0..1)
        public float size;     // diameter in dp
        public Btn(String id, String label, float x, float y, float size) {
            this.id = id; this.label = label; this.x = x; this.y = y; this.size = size;
        }
        public Btn copy() { return new Btn(id, label, x, y, size); }
    }

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("akevo", Context.MODE_PRIVATE); }

    // ---------- simple settings ----------
    public static int opacity(Context c) { return sp(c).getInt("opacity", 70); }
    public static int scale(Context c) { return sp(c).getInt("scale", 100); }
    public static boolean haptics(Context c) { return sp(c).getBoolean("haptics", true); }
    public static boolean latchTest(Context c) { return sp(c).getBoolean("latch_test", true); }
    /** "OpenGL" (default, most compatible) or "Vulkan" (optional). */
    public static String rendererMode(Context c) { return sp(c).getString("renderer_mode", "OpenGL"); }
    public static boolean pinBig(Context c) { return sp(c).getBoolean("pin_big", true); }
    public static boolean perfBoost(Context c) { return sp(c).getBoolean("perf_boost", true); }
    public static boolean muteSong(Context c) { return sp(c).getBoolean("mute_song", false); }
    public static String launchVersion(Context c) { return sp(c).getString("launch_version", "akaievo8"); }
    public static boolean twoPlayers(Context c) { return true; }   // the app is always in 2-player button mode
    public static boolean swapP2(Context c) { return sp(c).getBoolean("swap_p2", false); }
    public static boolean ioEnabled(Context c) { return sp(c).getBoolean("io_enabled", true); }
    public static int spuBlocks(Context c) { return sp(c).getInt("spu_blocks", 50); }
    public static boolean showService(Context c) { return sp(c).getBoolean("show_service", false); }
    /** Master game volume in percent (0..150, 100 = normal). */
    public static int volume(Context c) { return sp(c).getInt("volume", 100); }
    public static boolean volVisible(Context c) { return sp(c).getBoolean("vol_visible", true); }
    /** Account website, fixed at build time (the web_url box of the build workflow). Not user-editable on purpose. */
    public static String webUrl(Context c) { return AkDefaults.WEB_URL; }
    public static boolean overlayVisible(Context c) { return sp(c).getBoolean("overlay_visible", true); }
    public static String confirmKey(Context c) { return sp(c).getString("confirm_key", "A"); }
    public static String host(Context c) { return sp(c).getString("host", "127.0.0.1"); }
    public static int port(Context c) { return sp(c).getInt("port", AkDefaults.PORT); }
    public static String path(Context c) { return sp(c).getString("path", AkDefaults.PATH); }
    public static String method(Context c) { return sp(c).getString("method", AkDefaults.METHOD); }
    public static String bodyTemplate(Context c) { return sp(c).getString("body", AkDefaults.BODY); }
    public static void put(Context c, String k, Object v) {
        SharedPreferences.Editor e = sp(c).edit();
        if (v instanceof Integer) e.putInt(k, (Integer) v);
        else if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else e.putString(k, String.valueOf(v));
        e.apply();
    }

    // ---------- layouts ----------
    public static List<Btn> defaultLayout(boolean leftHanded) { return defaultLayout(leftHanded, false); }

    public static List<Btn> defaultLayout(boolean leftHanded, boolean two) {
        List<Btn> l = new ArrayList<Btn>();
        float dx = leftHanded ? 1f : 0f;
        if (!two) {
            // One player: big green (left) and yellow (right) buttons in the black side bars.
            l.add(new Btn("LEFT",  "",      mx(0.10f, dx), 0.74f, 100));
            l.add(new Btn("RIGHT", "",      mx(0.90f, dx), 0.74f, 100));
        } else {
            // Two players: left side = player 1 (green, yellow), right side = player 2 (green, yellow).
            l.add(new Btn("LEFT",  "1",     mx(0.060f, dx), 0.78f, 64));
            l.add(new Btn("RIGHT", "1",     mx(0.150f, dx), 0.78f, 64));
            l.add(new Btn("P2G",   "2",     mx(0.866f, dx), 0.78f, 64));
            l.add(new Btn("P2Y",   "2",     mx(0.955f, dx), 0.78f, 64));
        }
        // Service buttons: only shown while TEST is held / latched (or when switched on in Settings).
        l.add(new Btn("UP",    "\u25B2", mx(0.06f, dx), 0.50f, 44));
        l.add(new Btn("DOWN",  "\u25BC", mx(0.15f, dx), 0.50f, 44));
        l.add(new Btn("OK",    "OK",    mx(0.105f, dx), 0.62f, 48));
        l.add(new Btn("SET",   "\u2699", mx(0.94f, dx), 0.08f, 44));
        l.add(new Btn("SCAN",  "CARD",  mx(0.92f, dx), 0.34f, 56));
        l.add(new Btn("TEST",  "1\nTEST", mx(0.92f, dx), 0.54f, 52));
        l.add(volBtn(dx));
        return l;
    }
    public static Btn volBtn(float dx) { return new Btn("VOL", "VOL", mx(0.92f, dx), 0.20f, 48); }
    private static float mx(float x, float mirror) { return mirror > 0 ? 1f - x : x; }

    private static String key(Context c, String name) { return twoPlayers(c) ? name + "|2P" : name; }

    public static String activeProfile(Context c) { return sp(c).getString("active_profile", "Default"); }
    public static void setActiveProfile(Context c, String n) { put(c, "active_profile", n); }

    private static JSONObject profiles(Context c) {
        try { return new JSONObject(sp(c).getString("profiles", "{}")); } catch (Exception e) { return new JSONObject(); }
    }
    public static List<String> profileNames(Context c) {
        List<String> n = new ArrayList<String>(); n.add("Default"); n.add("Left-handed");
        Iterator<String> it = profiles(c).keys();
        boolean two = twoPlayers(c);
        while (it.hasNext()) {
            String k = it.next(); boolean is2 = k.endsWith("|2P");
            if (is2 != two) continue;
            if (is2) k = k.substring(0, k.length() - 3);
            if (!n.contains(k)) n.add(k);
        }
        return n;
    }
    public static List<Btn> layout(Context c, String name) {
        try {
            JSONArray a = profiles(c).optJSONArray(key(c, name));
            if (a != null) {
                List<Btn> l = new ArrayList<Btn>();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    l.add(new Btn(o.getString("id"), o.getString("label"), (float) o.getDouble("x"), (float) o.getDouble("y"), (float) o.getDouble("size")));
                }
                // A.16: the fast-forward button is gone; the volume button takes its place (same position) in saved layouts.
                Btn ff = null; boolean hasVol = false;
                for (Btn b : l) { if ("FF".equals(b.id)) ff = b; if ("VOL".equals(b.id)) hasVol = true; }
                if (ff != null) l.remove(ff);
                if (!hasVol) {
                    Btn v = volBtn("Left-handed".equals(name) ? 1f : 0f);
                    if (ff != null) { v.x = ff.x; v.y = ff.y; v.size = ff.size; }
                    l.add(v);
                }
                return l;
            }
        } catch (Exception ignored) { }
        return defaultLayout("Left-handed".equals(name), twoPlayers(c));
    }
    public static List<Btn> activeLayout(Context c) { return layout(c, activeProfile(c)); }
    public static void saveLayout(Context c, String name, List<Btn> l) {
        try {
            JSONArray a = new JSONArray();
            for (Btn b : l) {
                JSONObject o = new JSONObject();
                o.put("id", b.id); o.put("label", b.label); o.put("x", b.x); o.put("y", b.y); o.put("size", b.size);
                a.put(o);
            }
            JSONObject all = profiles(c); all.put(key(c, name), a);
            sp(c).edit().putString("profiles", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    public static void deleteProfile(Context c, String name) {
        JSONObject all = profiles(c); all.remove(key(c, name));
        sp(c).edit().putString("profiles", all.toString()).apply();
        if (name.equals(activeProfile(c))) setActiveProfile(c, "Default");
    }
}

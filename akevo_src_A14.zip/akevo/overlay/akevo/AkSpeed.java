package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.util.Log;
import android.widget.Toast;
import java.lang.reflect.Method;

/**
 * Fast forward. Speed steps: 1x (normal), 2x, 3x, 4x, MAX (frame limiter off).
 * Exact multiples are paced by comparing the emulator's frame counter with the wall clock and switching Play!'s
 * frame limiter on/off. If the counter is not available on a build, every step above 1x quietly behaves as MAX.
 */
public final class AkSpeed {
    private static final String TAG = "AkSpeed";
    public static final int MAX = 0;                                  // "multiplier" value meaning: limiter off
    public static final int[] STEPS = {1, 2, 3, 4, MAX};
    private static final double BASE_FPS = 60.0;
    private static final double MAX_LEAD = 3.0;                       // frames of credit we allow before holding back

    private static native void nativeSetLimit(boolean limit);

    private static volatile int target = 1;
    private static volatile int generation = 0;
    private static boolean limiterOn = true;                          // what the emulator is currently set to
    private static Method getFrames;
    private static boolean counterChecked = false, counterWorks = false, warned = false;

    public static String label(int m) { return m == MAX ? "MAX" : m + "x"; }
    public static int current() { return target; }

    /** Next step after m in STEPS (wraps back to 1x). */
    public static int next(int m) {
        for (int i = 0; i < STEPS.length; i++) if (STEPS[i] == m) return STEPS[(i + 1) % STEPS.length];
        return 1;
    }

    /** Parse the stored hold-speed setting ("2x".."MAX"). */
    public static int parse(String s) {
        if (s == null) return MAX;
        for (int m : STEPS) if (label(m).equals(s)) return m;
        return MAX;
    }

    private static synchronized void apply(boolean limit) {
        if (limit == limiterOn) return;
        limiterOn = limit;
        try { nativeSetLimit(limit); } catch (Throwable t) { Log.w(TAG, "nativeSetLimit failed", t); }
    }

    private static int frames() {
        try {
            if (getFrames == null) getFrames = Class.forName("com.virtualapplications.play.StatsManager").getMethod("getFrames");
            return ((Number) getFrames.invoke(null)).intValue();
        } catch (Throwable t) { return -1; }
    }

    /** Set the speed. 1x = normal, 0 = MAX, 2..4 = paced multiples. */
    public static void set(final Activity a, int mult) {
        target = mult;
        final int gen = ++generation;
        if (mult == 1) { apply(true); return; }
        if (mult == MAX) { apply(false); return; }
        if (counterChecked && !counterWorks) { apply(false); return; }
        final int m = mult;
        Thread t = new Thread(new Runnable() { public void run() { pace(a, m, gen); } }, "AkSpeed");
        t.setDaemon(true); t.start();
    }

    /** Back to normal speed (call on pause / exit). */
    public static void reset() { target = 1; generation++; limiterOn = false; apply(true); }   // forced: always ends with the normal limiter on

    private static void pace(Activity a, int m, int gen) {
        long t0 = System.nanoTime(); int f0 = frames(); long start = t0; boolean advanced = false; int last = f0;
        apply(false);
        while (generation == gen) {
            try { Thread.sleep(8); } catch (InterruptedException e) { return; }
            long now = System.nanoTime(); int f = frames();
            if (f < 0) { fallback(a); return; }
            if (f < last) { f0 = f; t0 = now; last = f; continue; }         // counter was reset
            if (f > last) advanced = true;
            last = f;
            if (!advanced) {
                if (!counterChecked && now - start > 2500000000L) { fallback(a); return; }   // counter never moved: not usable
                continue;                                                    // game paused / loading: keep unlimited
            }
            if (!counterChecked) { counterChecked = true; counterWorks = true; }
            double wanted = (now - t0) / 1e9 * BASE_FPS * m;
            double lead = (f - f0) - wanted;
            if (lead > MAX_LEAD) { f0 += (int) (lead - MAX_LEAD); lead = MAX_LEAD; }   // never bank a long pause
            apply(lead >= 0);                                                // ahead of schedule: normal limiter, behind: unlimited
        }
    }

    private static void fallback(final Activity a) {
        counterChecked = true; counterWorks = false; apply(false);
        if (warned || a == null) return;
        warned = true;
        a.runOnUiThread(new Runnable() { public void run() {
            try { Toast.makeText(a, "Exact fast-forward speeds are not available here: 2x/3x/4x run at MAX.", Toast.LENGTH_LONG).show(); } catch (Throwable ignored) { }
        } });
    }
}

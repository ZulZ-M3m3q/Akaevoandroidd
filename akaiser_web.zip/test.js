'use strict';
// End-to-end test: node test.js   (uses a throw-away database)
const os = require('node:os'), fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'akweb-'));
const { server } = require('./server.js');
const assert = require('node:assert/strict');

(async () => {
  await new Promise((r) => server.listen(0, r));
  const base = 'http://127.0.0.1:' + server.address().port;
  const J = { 'Content-Type': 'application/json' };
  let cookie = '';
  const web = async (p, body, method) => {
    const r = await fetch(base + p, { method: method || (body === undefined ? 'GET' : 'POST'), headers: { ...(body === undefined ? {} : J), ...(cookie ? { Cookie: cookie } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
    const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    return { status: r.status, data: await r.json().catch(() => ({})), headers: r.headers };
  };
  const secret = crypto.randomBytes(32).toString('hex');
  const dev = async (p, body, method, sec) => {
    const r = await fetch(base + p, { method: method || 'POST', headers: { ...J, Authorization: 'Device ' + (sec || secret) }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: r.status, data: await r.json().catch(() => ({})) };
  };
  let n = 0; const ok = (m) => console.log('  ok', ++n, m);

  // static page + headers
  let r = await fetch(base + '/'); assert.equal(r.status, 200); assert.ok((await r.text()).includes('AkaiserEvodroid')); assert.ok(r.headers.get('content-security-policy')); ok('index page served with CSP');
  r = await fetch(base + '/..%2fserver.js'); assert.equal(r.status, 404); ok('path traversal blocked');
  r = await fetch(base + '/healthz'); assert.equal(r.status, 200); ok('health check');

  // app asks for a code before anything else
  let s = await dev('/api/device/status', { name: 'Test Phone' });
  assert.equal(s.status, 200); assert.equal(s.data.linked, false); assert.match(s.data.code, /^[A-Z2-9]{4}-[A-Z2-9]{4}$/); assert.ok(s.data.expiresIn > 800);
  const code = s.data.code; ok('app gets a link code ' + code);
  let s2 = await dev('/api/device/status', { name: 'Test Phone' }); assert.equal(s2.data.code, code); ok('polling keeps the same code');
  assert.equal((await dev('/api/device/status', {}, 'POST', 'short')).status, 401); ok('bad device secret rejected');

  // website: sign up validation
  assert.equal((await web('/api/signup', { username: 'a!', password: 'password1' })).status, 400); ok('bad username rejected');
  assert.equal((await web('/api/signup', { username: 'zull', password: 'short' })).status, 400); ok('short password rejected');
  assert.equal((await fetch(base + '/api/signup', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{}' })).status, 415); ok('non-JSON POST rejected (CSRF guard)');
  r = await web('/api/signup', { username: 'Zull', password: 'correct horse' }); assert.equal(r.status, 201); assert.ok(cookie.startsWith('ak_session=')); ok('sign up logs in');
  assert.equal((await web('/api/signup', { username: 'zull', password: 'another pass' })).status, 409); ok('duplicate username (case-insensitive) rejected');
  r = await web('/api/me'); assert.equal(r.data.loggedIn, true); assert.equal(r.data.username, 'Zull'); assert.equal(r.data.devices.length, 0); ok('/api/me');

  // linking
  assert.equal((await web('/api/link', { code: 'ZZZZ-ZZZZ' })).status, 404); ok('wrong code rejected');
  assert.equal((await web('/api/link', { code: 'abc' })).status, 400); ok('malformed code rejected');
  assert.equal((await dev('/api/device/data', undefined, 'GET')).status, 403); ok('unlinked app cannot use the data store');
  r = await web('/api/link', { code: code.toLowerCase().replace('-', ' ') }); assert.equal(r.status, 200); ok('code accepted (lower-case, space instead of dash)');
  s = await dev('/api/device/status', {}); assert.equal(s.data.linked, true); assert.equal(s.data.username, 'Zull'); ok('app now sees linked as Zull');
  assert.equal((await web('/api/link', { code })).status, 404); ok('code cannot be reused');
  r = await web('/api/me'); assert.equal(r.data.devices.length, 1); assert.equal(r.data.devices[0].name, 'Test Phone'); ok('device listed on the website');

  // data store
  assert.equal((await dev('/api/device/data', { data: { layout: [1, 2], volume: 120 } }, 'PUT')).status, 200);
  r = await dev('/api/device/data', undefined, 'GET'); assert.equal(r.data.data.volume, 120); ok('backup saved and restored');
  assert.equal((await dev('/api/device/data', { data: { x: 'a'.repeat(70000) } }, 'PUT')).status, 413); ok('oversize backup rejected');

  // unlink from the website -> app is locked again with a fresh code
  const id = (await web('/api/me')).data.devices[0].id;
  assert.equal((await web('/api/devices/unlink', { id })).status, 200);
  s = await dev('/api/device/status', {}); assert.equal(s.data.linked, false); assert.ok(s.data.code); assert.notEqual(s.data.code, code); ok('unlinking locks the app and issues a new code');

  // relink, then unlink from the app
  assert.equal((await web('/api/link', { code: s.data.code })).status, 200);
  assert.equal((await dev('/api/device/unlink', {})).status, 200);
  s = await dev('/api/device/status', {}); assert.equal(s.data.linked, false); ok('app can unlink itself');

  // a second user cannot steal the first user's code / sees nothing of their devices
  s = await dev('/api/device/status', {});
  await web('/api/logout', {}); assert.equal((await web('/api/me')).data.loggedIn, false); ok('logout');
  assert.equal((await web('/api/link', { code: s.data.code })).status, 401); ok('linking needs a login');
  assert.equal((await web('/api/login', { username: 'zull', password: 'wrong password' })).status, 401); ok('wrong password rejected');
  assert.equal((await web('/api/login', { username: 'nobody', password: 'whatever12' })).status, 401); ok('unknown user rejected the same way');
  assert.equal((await web('/api/login', { username: 'zull', password: 'correct horse' })).status, 200); ok('login');

  // expired code
  const { db } = require('./server.js');
  db.prepare('UPDATE devices SET code_expires_at = ? WHERE code = ?').run(Date.now() - 1000, s.data.code.replace('-', ''));
  assert.equal((await web('/api/link', { code: s.data.code })).status, 404); ok('expired code rejected');
  s = await dev('/api/device/status', {}); assert.notEqual(s.data.code, undefined); ok('expired code is replaced when the app polls');

  // device limit
  // change password + delete
  assert.equal((await web('/api/change-password', { oldPassword: 'nope nope', newPassword: 'new password 1' })).status, 401);
  assert.equal((await web('/api/change-password', { oldPassword: 'correct horse', newPassword: 'new password 1' })).status, 200); ok('password change');
  assert.equal((await web('/api/delete-account', { password: 'bad' })).status, 401);
  assert.equal((await web('/api/delete-account', { password: 'new password 1' })).status, 200); ok('account deleted');
  assert.equal((await web('/api/login', { username: 'zull', password: 'new password 1' })).status, 401); ok('deleted account cannot log in');

  // rate limit on login
  let last; for (let i = 0; i < 12; i++) last = await web('/api/login', { username: 'victim', password: 'guess' + i });
  assert.equal(last.status, 429); ok('login brute force is rate limited');

  console.log('\nALL ' + n + ' CHECKS PASSED');
  server.close(); process.exit(0);
})().catch((e) => { console.error('\nFAILED:', e); process.exit(1); });

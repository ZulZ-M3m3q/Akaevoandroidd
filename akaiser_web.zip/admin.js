'use strict';
// Owner tool (run on the server):
//   node admin.js list
//   node admin.js reset <username> <new-password>
//   node admin.js delete <username>
const path = require('node:path'), crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(path.join(process.env.DATA_DIR || path.join(__dirname, 'data'), 'akaiser.db'));
db.exec('PRAGMA foreign_keys = ON');
const [cmd, user, pw] = process.argv.slice(2);
if (cmd === 'list') {
  for (const u of db.prepare('SELECT u.username, u.created_at, (SELECT COUNT(*) FROM devices d WHERE d.user_id = u.id) AS devices FROM users u ORDER BY u.id').all())
    console.log(u.username.padEnd(22), new Date(u.created_at).toISOString().slice(0, 10), u.devices + ' device(s)');
} else if (cmd === 'reset' && user && pw && pw.length >= 8) {
  const salt = crypto.randomBytes(16), key = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  const r = db.prepare('UPDATE users SET pass_hash = ? WHERE username_lc = ?').run(`s1$${salt.toString('hex')}$${key.toString('hex')}`, user.toLowerCase());
  db.prepare('DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE username_lc = ?)').run(user.toLowerCase());
  console.log(r.changes ? 'Password reset.' : 'No such user.');
} else if (cmd === 'delete' && user) {
  console.log(db.prepare('DELETE FROM users WHERE username_lc = ?').run(user.toLowerCase()).changes ? 'Deleted.' : 'No such user.');
} else console.log('Usage: node admin.js list | reset <user> <new-password (8+)> | delete <user>');

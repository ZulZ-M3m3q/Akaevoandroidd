'use strict';
const view = document.getElementById('view');

function el(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') e.className = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== undefined && v !== null && v !== false) e.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null) e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return e;
}

async function api(path, body, method) {
  const r = await fetch(path, {
    method: method || (body === undefined ? 'GET' : 'POST'),
    headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
    credentials: 'same-origin',
  });
  let data = {};
  try { data = await r.json(); } catch (_) {}
  if (!r.ok) throw new Error(data.error || 'Something went wrong (' + r.status + ').');
  return data;
}

function say(box, text, ok) { box.className = 'msg ' + (ok ? 'ok' : 'err'); box.textContent = text; }
function fmtDate(t) { return t ? new Date(t).toLocaleString() : 'never'; }

// ------------------------------------------------------------ logged-out screen
function showAuth(mode) {
  const signup = mode === 'signup';
  const msg = el('div');
  const user = el('input', { id: 'u', autocomplete: 'username', autocapitalize: 'none', maxlength: '20', placeholder: 'letters, numbers, _' });
  const pass = el('input', { id: 'p', type: 'password', autocomplete: signup ? 'new-password' : 'current-password', placeholder: 'at least 8 characters' });
  const pass2 = signup ? el('input', { id: 'p2', type: 'password', autocomplete: 'new-password' }) : null;
  const go = el('button', { type: 'button' }, signup ? 'Create account' : 'Log in');

  async function submit() {
    if (signup && pass.value !== pass2.value) return say(msg, 'The two passwords do not match.');
    go.disabled = true;
    try {
      await api(signup ? '/api/signup' : '/api/login', { username: user.value.trim(), password: pass.value });
      await render();
    } catch (e) { say(msg, e.message); go.disabled = false; }
  }
  go.addEventListener('click', submit);
  for (const i of [user, pass, pass2]) if (i) i.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') submit(); });

  view.replaceChildren(
    el('div', { class: 'tabs' },
      el('button', { class: signup ? 'on' : '', onclick: () => showAuth('signup') }, 'Sign up'),
      el('button', { class: signup ? '' : 'on', onclick: () => showAuth('login') }, 'Log in')),
    el('div', { class: 'card' },
      el('h2', {}, signup ? 'Create your account' : 'Welcome back'),
      el('label', { for: 'u' }, 'Username'), user,
      el('label', { for: 'p' }, 'Password'), pass,
      signup ? [el('label', { for: 'p2' }, 'Repeat password'), pass2] : null,
      go, msg),
    el('p', { class: 'mute' }, 'After you sign in you will enter the code shown in the app to connect it to your account.'));
}

// ------------------------------------------------------------ logged-in screen
function formatCodeInput(input) {
  let v = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
  if (v.length > 4) v = v.slice(0, 4) + '-' + v.slice(4);
  input.value = v;
}

function showDashboard(me) {
  const linkMsg = el('div');
  const code = el('input', { class: 'codebox', placeholder: 'XXXX-XXXX', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', inputmode: 'text', maxlength: '9' });
  code.addEventListener('input', () => formatCodeInput(code));
  const linkBtn = el('button', { type: 'button' }, 'Link my app');
  async function link() {
    linkBtn.disabled = true;
    try {
      await api('/api/link', { code: code.value });
      code.value = '';
      await render('Linked! Your app will unlock in a few seconds.');
    } catch (e) { say(linkMsg, e.message); linkBtn.disabled = false; }
  }
  linkBtn.addEventListener('click', link);
  code.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') link(); });

  const devs = me.devices.length
    ? me.devices.map((d) => el('div', { class: 'row' },
        el('div', {}, el('div', {}, d.name), el('div', { class: 'mute' }, 'Linked ' + fmtDate(d.linkedAt) + ' · last seen ' + fmtDate(d.lastSeen))),
        el('button', { class: 'ghost small', onclick: async () => {
          if (!confirm('Unlink "' + d.name + '"? The game will ask for a new code on that device.')) return;
          try { await api('/api/devices/unlink', { id: d.id }); await render(); } catch (e) { alert(e.message); }
        } }, 'Unlink')))
    : [el('p', { class: 'mute' }, 'No app linked yet.')];

  // change password
  const pwMsg = el('div');
  const oldPw = el('input', { type: 'password', autocomplete: 'current-password' });
  const newPw = el('input', { type: 'password', autocomplete: 'new-password' });
  const pwBtn = el('button', { type: 'button', class: 'ghost' }, 'Change password');
  pwBtn.addEventListener('click', async () => {
    pwBtn.disabled = true;
    try { await api('/api/change-password', { oldPassword: oldPw.value, newPassword: newPw.value }); oldPw.value = newPw.value = ''; say(pwMsg, 'Password changed.', true); }
    catch (e) { say(pwMsg, e.message); }
    pwBtn.disabled = false;
  });

  // delete account
  const delMsg = el('div');
  const delPw = el('input', { type: 'password', autocomplete: 'current-password' });
  const delBtn = el('button', { type: 'button', class: 'danger' }, 'Delete my account');
  delBtn.addEventListener('click', async () => {
    if (!confirm('Delete your account and cloud backup for good?')) return;
    try { await api('/api/delete-account', { password: delPw.value }); await render(); } catch (e) { say(delMsg, e.message); }
  });

  view.replaceChildren(
    el('div', { class: 'who' },
      el('div', {}, 'Signed in as ', el('b', {}, me.username)),
      el('button', { class: 'ghost small', onclick: async () => { await api('/api/logout', {}); await render(); } }, 'Log out')),
    el('div', { class: 'card' },
      el('h2', {}, 'Link your app'),
      el('p', { class: 'mute' }, 'Open AkaiserEvodroid and tap PLAY. The app shows a code. Type it here.'),
      code, linkBtn, linkMsg),
    el('div', { class: 'card' },
      el('h2', {}, 'Your devices (' + me.devices.length + '/' + me.maxDevices + ')'), devs,
      me.backup ? el('p', { class: 'mute' }, 'Cloud backup of app settings: ' + me.backup.bytes + ' bytes, saved ' + fmtDate(me.backup.updatedAt)) : null),
    el('div', { class: 'card' },
      el('details', {}, el('summary', {}, 'Change password'),
        el('label', {}, 'Current password'), oldPw, el('label', {}, 'New password'), newPw, pwBtn, pwMsg)),
    el('div', { class: 'card' },
      el('details', {}, el('summary', {}, 'Delete account'),
        el('label', {}, 'Type your password to confirm'), delPw, delBtn, delMsg)));
}

async function render(flash) {
  let me;
  try { me = await api('/api/me'); } catch (e) { view.replaceChildren(el('div', { class: 'msg err' }, e.message)); return; }
  if (!me.loggedIn) return showAuth('signup');
  showDashboard(me);
  if (flash) { const b = el('div', { class: 'msg ok' }, flash); view.prepend(b); }
}
render();

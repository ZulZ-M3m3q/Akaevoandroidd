'use strict';
/*
 * AkaiserEvodroid account website - zero dependencies (Node 22.5+, built-in SQLite).
 *
 *  Website (cookie session):  sign up / log in / enter the app's link code / see + unlink devices
 *  App (device secret):       the app asks for a link code, polls until you entered it on the site,
 *                             then verifies on every PLAY and can back up / restore its settings.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const PORT = parseInt(process.env.PORT || '3000', 10);
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const TRUST_PROXY = process.env.TRUST_PROXY === '1';        // set to 1 when behind Render/Railway/nginx/Cloudflare
const SESSION_DAYS = 30;
const CODE_TTL_MS = 15 * 60 * 1000;                          // a link code is valid for 15 minutes
const MAX_DEVICES = parseInt(process.env.MAX_DEVICES || '5', 10);   // devices one account may link
const DATA_LIMIT = 64 * 1024;                                // cloud backup size per account
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';    // no 0/O/1/I
const PUBLIC_DIR = path.join(__dirname, 'public');

fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(path.join(DATA_DIR, 'akaiser.db'));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    username_lc TEXT NOT NULL UNIQUE,
    pass_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    data TEXT NOT NULL DEFAULT '',
    data_updated_at INTEGER
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    secret_hash TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL DEFAULT '',
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    code TEXT UNIQUE,
    code_expires_at INTEGER,
    created_at INTEGER NOT NULL,
    linked_at INTEGER,
    last_seen INTEGER
  );
`);

// ---------------------------------------------------------------- helpers
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const now = () => Date.now();

function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
  return `s1$${salt.toString('hex')}$${key.toString('hex')}`;
}
const DUMMY_HASH = hashPassword('dummy-password-for-timing');
function verifyPassword(pw, stored) {
  try {
    const [v, saltHex, keyHex] = stored.split('$');
    if (v !== 's1') return false;
    const key = crypto.scryptSync(pw, Buffer.from(saltHex, 'hex'), 64, { N: 16384, r: 8, p: 1 });
    return crypto.timingSafeEqual(key, Buffer.from(keyHex, 'hex'));
  } catch { return false; }
}

function newCode() {
  for (let i = 0; i < 20; i++) {
    let c = '';
    const b = crypto.randomBytes(8);
    for (let k = 0; k < 8; k++) c += CODE_ALPHABET[b[k] % CODE_ALPHABET.length];
    if (!db.prepare('SELECT 1 FROM devices WHERE code = ?').get(c)) return c;
  }
  throw new Error('could not make a code');
}
function cleanCode(s) {
  const c = String(s || '').toUpperCase().replace(/[\s-]/g, '');
  return /^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/.test(c) ? c : null;
}

// simple in-memory rate limiter: allow(key, max, windowMs)
const buckets = new Map();
function allow(key, max, windowMs) {
  const t = now();
  let b = buckets.get(key);
  if (!b || b.reset < t) { b = { n: 0, reset: t + windowMs }; buckets.set(key, b); }
  b.n++;
  return b.n <= max;
}
setInterval(() => { const t = now(); for (const [k, b] of buckets) if (b.reset < t) buckets.delete(k); }, 60_000).unref();
setInterval(() => {
  const t = now();
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(t);
  db.prepare('UPDATE devices SET code = NULL, code_expires_at = NULL WHERE user_id IS NULL AND code_expires_at < ?').run(t);
}, 10 * 60_000).unref();

function clientIp(req) {
  if (TRUST_PROXY) {
    const xf = req.headers['x-forwarded-for'];
    if (xf) return String(xf).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'unknown';
}
const isHttps = (req) => req.socket.encrypted || (TRUST_PROXY && req.headers['x-forwarded-proto'] === 'https');

// ---------------------------------------------------------------- http plumbing
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }

function send(res, status, obj, headers = {}) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
  res.end(body);
}

function readJson(req, limit = 100 * 1024) {
  return new Promise((resolve, reject) => {
    const ct = String(req.headers['content-type'] || '');
    if (!ct.toLowerCase().startsWith('application/json')) return reject(new HttpError(415, 'Send JSON (Content-Type: application/json).'));
    let size = 0, dead = false; const chunks = [];
    const tooBig = () => { if (!dead) { dead = true; chunks.length = 0; reject(new HttpError(413, 'Request too large.')); req.resume(); } };
    if (parseInt(req.headers['content-length'] || '0', 10) > limit) return tooBig();
    req.on('data', (c) => {
      if (dead) return;
      size += c.length;
      if (size > limit) return tooBig();
      chunks.push(c);
    });
    req.on('end', () => {
      if (dead) return;
      if (size === 0) return resolve({});
      try { const v = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(v && typeof v === 'object' ? v : {}); }
      catch { reject(new HttpError(400, 'Bad JSON.')); }
    });
    req.on('error', reject);
  });
}

function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function sessionUser(req) {
  const tok = parseCookies(req).ak_session;
  if (!tok || tok.length < 20) return null;
  const row = db.prepare(`SELECT u.id, u.username FROM sessions s JOIN users u ON u.id = s.user_id
                          WHERE s.token_hash = ? AND s.expires_at > ?`).get(sha256(tok), now());
  return row || null;
}
function requireUser(req) {
  const u = sessionUser(req);
  if (!u) throw new HttpError(401, 'Please log in.');
  return u;
}
function startSession(req, res, userId, extra) {
  const tok = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?,?,?)').run(sha256(tok), userId, now() + SESSION_DAYS * 86400_000);
  const cookie = `ak_session=${tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_DAYS * 86400}` + (isHttps(req) ? '; Secure' : '');
  return cookie;
}
const clearCookie = 'ak_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0';

function deviceFromAuth(req) {
  const h = String(req.headers.authorization || '');
  if (!h.startsWith('Device ')) throw new HttpError(401, 'Missing device credentials.');
  const secret = h.slice(7).trim();
  if (secret.length < 32 || secret.length > 200) throw new HttpError(401, 'Bad device credentials.');
  return secret;
}

function validUsername(u) { return typeof u === 'string' && /^[A-Za-z0-9_]{3,20}$/.test(u); }
function validPassword(p) { return typeof p === 'string' && p.length >= 8 && p.length <= 200; }

function deviceView(d) {
  return { id: d.id, name: d.name || 'Android device', linkedAt: d.linked_at, lastSeen: d.last_seen };
}

// ---------------------------------------------------------------- API: website
const routes = {};
const route = (method, p, fn) => { routes[`${method} ${p}`] = fn; };

route('POST', '/api/signup', async (req, res) => {
  const ip = clientIp(req);
  if (!allow('signup:' + ip, 10, 3600_000)) throw new HttpError(429, 'Too many sign-ups from this network. Try again later.');
  const { username, password } = await readJson(req);
  if (!validUsername(username)) throw new HttpError(400, 'Username: 3-20 letters, numbers or underscore.');
  if (!validPassword(password)) throw new HttpError(400, 'Password must be at least 8 characters.');
  if (db.prepare('SELECT 1 FROM users WHERE username_lc = ?').get(username.toLowerCase())) throw new HttpError(409, 'That username is taken.');
  const info = db.prepare('INSERT INTO users (username, username_lc, pass_hash, created_at) VALUES (?,?,?,?)')
    .run(username, username.toLowerCase(), hashPassword(password), now());
  const cookie = startSession(req, res, Number(info.lastInsertRowid));
  send(res, 201, { ok: true, username }, { 'Set-Cookie': cookie });
});

route('POST', '/api/login', async (req, res) => {
  const ip = clientIp(req);
  const { username, password } = await readJson(req);
  const uname = String(username || '').toLowerCase().slice(0, 40);
  if (!allow('login-ip:' + ip, 20, 10 * 60_000) || !allow('login-user:' + uname, 8, 10 * 60_000))
    throw new HttpError(429, 'Too many attempts. Wait 10 minutes and try again.');
  const u = db.prepare('SELECT id, username, pass_hash FROM users WHERE username_lc = ?').get(uname);
  const ok = verifyPassword(String(password || ''), u ? u.pass_hash : DUMMY_HASH);
  if (!u || !ok) throw new HttpError(401, 'Wrong username or password.');
  send(res, 200, { ok: true, username: u.username }, { 'Set-Cookie': startSession(req, res, u.id) });
});

route('POST', '/api/logout', async (req, res) => {
  const tok = parseCookies(req).ak_session;
  if (tok) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(tok));
  send(res, 200, { ok: true }, { 'Set-Cookie': clearCookie });
});

route('GET', '/api/me', async (req, res) => {
  const u = sessionUser(req);
  if (!u) return send(res, 200, { loggedIn: false });
  const devices = db.prepare('SELECT id, name, linked_at, last_seen FROM devices WHERE user_id = ? ORDER BY linked_at DESC').all(u.id).map(deviceView);
  const d = db.prepare('SELECT length(data) AS n, data_updated_at AS t FROM users WHERE id = ?').get(u.id);
  send(res, 200, { loggedIn: true, username: u.username, devices, maxDevices: MAX_DEVICES, backup: d.n > 0 ? { bytes: d.n, updatedAt: d.t } : null });
});

route('POST', '/api/change-password', async (req, res) => {
  const u = requireUser(req);
  const { oldPassword, newPassword } = await readJson(req);
  if (!allow('pw:' + u.id, 8, 10 * 60_000)) throw new HttpError(429, 'Too many attempts. Try again later.');
  const row = db.prepare('SELECT pass_hash FROM users WHERE id = ?').get(u.id);
  if (!verifyPassword(String(oldPassword || ''), row.pass_hash)) throw new HttpError(401, 'Current password is wrong.');
  if (!validPassword(newPassword)) throw new HttpError(400, 'New password must be at least 8 characters.');
  db.prepare('UPDATE users SET pass_hash = ? WHERE id = ?').run(hashPassword(newPassword), u.id);
  // log out every other session
  const tok = parseCookies(req).ak_session;
  db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?').run(u.id, sha256(tok));
  send(res, 200, { ok: true });
});

// The player types the code the app shows. This is the step that connects the web account to the app.
route('POST', '/api/link', async (req, res) => {
  const u = requireUser(req);
  if (!allow('link:' + u.id, 10, 10 * 60_000) || !allow('link-ip:' + clientIp(req), 30, 10 * 60_000))
    throw new HttpError(429, 'Too many wrong codes. Wait 10 minutes and try again.');
  const { code } = await readJson(req);
  const c = cleanCode(code);
  if (!c) throw new HttpError(400, 'The code has 8 letters/numbers, like K7M2-9QXA.');
  const d = db.prepare('SELECT id, user_id, code_expires_at FROM devices WHERE code = ?').get(c);
  if (!d || d.user_id || d.code_expires_at < now()) throw new HttpError(404, 'Code not found or expired. Open the app to get a new code.');
  const count = db.prepare('SELECT COUNT(*) AS n FROM devices WHERE user_id = ?').get(u.id).n;
  if (count >= MAX_DEVICES) throw new HttpError(409, `This account already has ${MAX_DEVICES} linked devices. Unlink one first.`);
  db.prepare('UPDATE devices SET user_id = ?, linked_at = ?, code = NULL, code_expires_at = NULL WHERE id = ?').run(u.id, now(), d.id);
  send(res, 200, { ok: true });
});

route('POST', '/api/devices/unlink', async (req, res) => {
  const u = requireUser(req);
  const { id } = await readJson(req);
  const r = db.prepare('UPDATE devices SET user_id = NULL, linked_at = NULL WHERE id = ? AND user_id = ?').run(Number(id) || 0, u.id);
  if (!r.changes) throw new HttpError(404, 'Device not found.');
  send(res, 200, { ok: true });
});

route('POST', '/api/delete-account', async (req, res) => {
  const u = requireUser(req);
  const { password } = await readJson(req);
  const row = db.prepare('SELECT pass_hash FROM users WHERE id = ?').get(u.id);
  if (!allow('del:' + u.id, 5, 10 * 60_000) || !verifyPassword(String(password || ''), row.pass_hash)) throw new HttpError(401, 'Password is wrong.');
  db.prepare('DELETE FROM users WHERE id = ?').run(u.id);   // sessions cascade, devices become unlinked
  send(res, 200, { ok: true }, { 'Set-Cookie': clearCookie });
});

// ---------------------------------------------------------------- API: the app
// One call does it all: registers the device on first use, hands out / renews the link code while it is
// not linked, and reports "linked" once the player has typed the code on the website.
route('POST', '/api/device/status', async (req, res) => {
  const ip = clientIp(req);
  if (!allow('dev-ip:' + ip, 120, 60_000)) throw new HttpError(429, 'Slow down.');
  const secret = deviceFromAuth(req);
  const body = await readJson(req);
  const name = String(body.name || '').replace(/[^\x20-\x7E]/g, '').slice(0, 40);
  const sh = sha256(secret);
  let d = db.prepare('SELECT * FROM devices WHERE secret_hash = ?').get(sh);
  if (!d) {
    if (!allow('dev-new:' + ip, 10, 3600_000)) throw new HttpError(429, 'Too many new devices from this network.');
    db.prepare('INSERT INTO devices (secret_hash, name, created_at, last_seen) VALUES (?,?,?,?)').run(sh, name, now(), now());
    d = db.prepare('SELECT * FROM devices WHERE secret_hash = ?').get(sh);
  }
  db.prepare('UPDATE devices SET last_seen = ?, name = CASE WHEN ? != \'\' THEN ? ELSE name END WHERE id = ?').run(now(), name, name, d.id);

  if (d.user_id) {
    const u = db.prepare('SELECT username FROM users WHERE id = ?').get(d.user_id);
    return send(res, 200, { linked: true, username: u.username });
  }
  let code = d.code, exp = d.code_expires_at;
  if (!code || !exp || exp < now() + 30_000) {          // missing, expired or about to expire: give a fresh one
    code = newCode(); exp = now() + CODE_TTL_MS;
    db.prepare('UPDATE devices SET code = ?, code_expires_at = ? WHERE id = ?').run(code, exp, d.id);
  }
  send(res, 200, { linked: false, code: code.slice(0, 4) + '-' + code.slice(4), expiresIn: Math.max(0, Math.floor((exp - now()) / 1000)) });
});

route('POST', '/api/device/unlink', async (req, res) => {
  const secret = deviceFromAuth(req);
  db.prepare('UPDATE devices SET user_id = NULL, linked_at = NULL WHERE secret_hash = ?').run(sha256(secret));
  send(res, 200, { ok: true });
});

function linkedDevice(req) {
  const d = db.prepare('SELECT id, user_id FROM devices WHERE secret_hash = ?').get(sha256(deviceFromAuth(req)));
  if (!d || !d.user_id) throw new HttpError(403, 'This device is not linked to an account.');
  return d;
}
route('GET', '/api/device/data', async (req, res) => {
  const d = linkedDevice(req);
  const r = db.prepare('SELECT data, data_updated_at FROM users WHERE id = ?').get(d.user_id);
  send(res, 200, { data: r.data ? JSON.parse(r.data) : null, updatedAt: r.data_updated_at });
});
route('PUT', '/api/device/data', async (req, res) => {
  const d = linkedDevice(req);
  const body = await readJson(req, DATA_LIMIT + 1024);
  const text = JSON.stringify(body.data === undefined ? null : body.data);
  if (Buffer.byteLength(text) > DATA_LIMIT) throw new HttpError(413, 'Backup is too large (max 64 KB).');
  db.prepare('UPDATE users SET data = ?, data_updated_at = ? WHERE id = ?').run(text, now(), d.user_id);
  send(res, 200, { ok: true });
});

// ---------------------------------------------------------------- static files
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const SEC_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'X-Frame-Options': 'DENY',
};
function serveStatic(req, res, pathname) {
  let rel = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return send(res, 404, { error: 'Not found' });
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', ...SEC_HEADERS });
    res.end(buf);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname === '/healthz') return send(res, 200, { ok: true });
    const fn = routes[`${req.method} ${url.pathname}`];
    if (fn) return await fn(req, res);
    if (url.pathname.startsWith('/api/')) throw new HttpError(404, 'Unknown API.');
    if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(req, res, decodeURIComponent(url.pathname));
    throw new HttpError(405, 'Method not allowed.');
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.status, { error: e.message }, e.status === 413 ? { Connection: 'close' } : {});
    console.error(e);
    send(res, 500, { error: 'Server error.' });
  }
});
server.requestTimeout = 15_000;
if (require.main === module) {
  server.listen(PORT, () => console.log(`AkaiserEvodroid account web on http://localhost:${PORT}  (data: ${DATA_DIR})`));
}
module.exports = { server, db };

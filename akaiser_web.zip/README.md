# AkaiserEvodroid account website

Players sign up here, then type the code the app shows to connect their account to the app.

```
App (PLAY)  ->  asks the site for a code (XXXX-XXXX)  ->  shows it on screen
Website     ->  player signs up / logs in, types the code
App         ->  polls, sees "linked", unlocks the game
```

No dependencies, no `npm install`. Needs **Node 22.5 or newer** (uses the built-in SQLite).

## Run it on your PC to try it
```
node server.js          # open http://localhost:3000
node test.js            # 34 automatic checks
```

## Put it online (the phone needs an https:// address)
Pick one. All of them give you https automatically.

**Render.com (easy)** – push this folder to a GitHub repo → New → Web Service → pick the repo → Runtime: *Docker*.
Add a **Disk** mounted at `/data` (1 GB is plenty). Without a disk the database is wiped on every redeploy.
Environment: `TRUST_PROXY=1` (already set in the Dockerfile).

**Railway / Fly.io** – same idea: deploy the Dockerfile, attach a volume at `/data`.

**Your own VPS** – `docker build -t akweb . && docker run -d --restart=always -p 127.0.0.1:3000:3000 -v akdata:/data akweb`, then put Caddy or nginx in front for https.

Then build the app (A.17 workflow) and type your site address in the **web_url** box.

## Settings (environment variables)
| name | default | meaning |
|---|---|---|
| `PORT` | 3000 | listen port |
| `DATA_DIR` | `./data` | where `akaiser.db` lives – keep it on a persistent disk and back it up |
| `TRUST_PROXY` | 0 (1 in Docker) | read the real client IP from `X-Forwarded-For` (needed behind a proxy, or rate limits see everyone as one IP) |
| `MAX_DEVICES` | 5 | phones one account may link |

## Owner tools
```
node admin.js list
node admin.js reset <username> <new password>     # forgotten password (there is no email reset)
node admin.js delete <username>
```
(In Docker: `docker exec -it <container> node admin.js list`.)

## What is stored
Username, a scrypt password hash, the device list (hash of each device secret, phone model name, last seen) and the optional 64 KB settings backup.
No email, no IP addresses. Passwords and device secrets are never stored in plain text.

## API used by the app
`POST /api/device/status` (header `Authorization: Device <secret>`) → `{linked, username}` or `{linked:false, code, expiresIn}`
`POST /api/device/unlink` · `GET/PUT /api/device/data`

## Honest limits
- The app checks the link on every PLAY, and tolerates being offline for 7 days. Someone who edits the APK can remove the check; this keeps casual users honest, it is not DRM.
- Codes are valid 15 minutes, wrong-code and login attempts are rate limited, and every request except GET must be JSON (blocks cross-site form posts).

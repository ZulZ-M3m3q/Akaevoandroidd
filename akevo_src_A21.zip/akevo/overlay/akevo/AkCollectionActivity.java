package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * A.21 "My cards": the cards the player has scanned, in three tabs (Animal / Strong / Miracle).
 * Tap a card = its barcode text is sent to the running game (same as scanning it). Long-press = details.
 */
public class AkCollectionActivity extends Activity {
    private static final String[] KINDS = {AkCards.ANIMAL, AkCards.STRONG, AkCards.MIRACLE};
    private static final String[] TABS = {"Animal", "Strong", "Miracle"};
    private static final int BG = 0xFF0B1117, CARD = 0xFF131C26, TEXT = 0xFFEEF3F8, MUTE = 0xFF8FA3B8, GOLD = 0xFFF2B705;

    private String kind = AkCards.ANIMAL, query = "";
    private boolean showAll = false;
    private TextView[] tabs; private TextView hint;
    private final List<AkCards.Card> shown = new ArrayList<AkCards.Card>();
    private Map<String, long[]> owned;
    private BaseAdapter adapter; private float d;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        d = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setPadding(p(12), p(10), p(12), p(8));

        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("My cards", 20, GOLD, true); top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = tv("Close", 15, TEXT, true); close.setPadding(p(14), p(8), p(14), p(8)); close.setBackgroundColor(CARD);
        close.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { finish(); } });
        top.addView(close); root.addView(top);

        LinearLayout tabRow = new LinearLayout(this); tabRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, -2, 1f); tl.setMargins(0, p(8), p(6), p(6));
        tabs = new TextView[3];
        for (int i = 0; i < 3; i++) {
            final int k = i;
            tabs[i] = tv(TABS[i], 14, TEXT, true); tabs[i].setGravity(Gravity.CENTER); tabs[i].setPadding(p(4), p(9), p(4), p(9));
            tabs[i].setOnClickListener(new View.OnClickListener() { public void onClick(View v) { kind = KINDS[k]; refresh(); } });
            tabRow.addView(tabs[i], tl);
        }
        root.addView(tabRow);

        LinearLayout ctl = new LinearLayout(this); ctl.setOrientation(LinearLayout.HORIZONTAL); ctl.setGravity(Gravity.CENTER_VERTICAL);
        EditText search = new EditText(this); search.setHint("Search name"); search.setSingleLine(true); search.setTextColor(TEXT); search.setHintTextColor(MUTE); search.setTextSize(15);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b2, int c) { }
            public void onTextChanged(CharSequence s, int a, int b2, int c) { }
            public void afterTextChanged(Editable e) { query = e.toString().trim().toLowerCase(); refresh(); } });
        ctl.addView(search, new LinearLayout.LayoutParams(0, -2, 1f));
        CheckBox all = new CheckBox(this); all.setText("Show cards I don't have"); all.setTextColor(MUTE); all.setTextSize(13);
        all.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { public void onCheckedChanged(CompoundButton v, boolean on) { showAll = on; refresh(); } });
        ctl.addView(all); root.addView(ctl);

        hint = tv("", 12, MUTE, false); hint.setPadding(0, p(4), 0, p(4)); root.addView(hint);

        ListView list = new ListView(this); list.setDivider(new android.graphics.drawable.ColorDrawable(0x00000000)); list.setDividerHeight(p(6)); list.setSelector(android.R.color.transparent);
        adapter = new BaseAdapter() {
            public int getCount() { return shown.size(); }
            public Object getItem(int i) { return shown.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View convert, ViewGroup parent) { return row(shown.get(i)); }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() { public void onItemClick(AdapterView<?> a, View v, int i, long id) { choose(shown.get(i)); } });
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() { public boolean onItemLongClick(AdapterView<?> a, View v, int i, long id) { details(shown.get(i)); return true; } });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    private int p(int dp) { return (int) (dp * d); }
    private TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        return t;
    }

    private void refresh() {
        owned = AkCollection.snapshot(this);
        shown.clear();
        for (AkCards.Card c : AkCards.ofKind(kind)) {
            boolean has = owned.containsKey(c.code);
            if (!has && !showAll) continue;
            if (query.length() > 0 && !c.name.toLowerCase().contains(query)) continue;
            shown.add(c);
        }
        for (int i = 0; i < 3; i++) {
            tabs[i].setText(TABS[i] + "\n" + AkCollection.owned(this, KINDS[i]) + "/" + AkCards.total(KINDS[i]));
            tabs[i].setBackgroundColor(KINDS[i].equals(kind) ? 0xFF2EA043 : CARD);
        }
        int have = AkCollection.owned(this, kind);
        hint.setText(have == 0 && !showAll
            ? "No cards here yet. Scan a card (CARD button) and it is added automatically."
            : "Tap a card to send it to the game. Long-press for details.");
        adapter.notifyDataSetChanged();
    }

    private int rarityColor(String r) {
        if (r.contains("Kaiser") || r.contains("Gold")) return GOLD;
        if (r.contains("Ultra")) return 0xFFB388FF;
        if (r.contains("Silver")) return 0xFFCFD8DC;
        if (r.contains("Bronze")) return 0xFFCD7F32;
        return MUTE;
    }

    private View row(AkCards.Card c) {
        long[] o = owned.get(c.code); boolean has = o != null;
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setBackgroundColor(CARD);
        r.setPadding(p(12), p(8), p(12), p(8));
        LinearLayout l1 = new LinearLayout(this); l1.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = tv(c.name, 16, has ? TEXT : MUTE, true); l1.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        if (has && o[1] > 1) l1.addView(tv("\u00D7" + o[1], 15, GOLD, true));
        r.addView(l1);
        r.addView(tv(c.stats(), 12, MUTE, false));
        TextView l3 = tv(c.rarity + "  \u00B7  " + c.game + (has ? "" : "  \u00B7  not scanned yet"), 12, rarityColor(c.rarity), false);
        r.addView(l3);
        r.setAlpha(has ? 1f : 0.45f);
        return r;
    }

    private void choose(final AkCards.Card c) {
        if (!owned.containsKey(c.code)) { Toast.makeText(this, "You do not have this card yet. Scan it once with the CARD button.", Toast.LENGTH_LONG).show(); return; }
        if (AkOverlay.emulatorActivity() == null) { Toast.makeText(this, "Start the game first, then open My cards from the game screen (MY CARDS button).", Toast.LENGTH_LONG).show(); return; }
        AkHttp.send(this, c.code, new AkHttp.Result() { public void done(boolean ok, String message) { if (ok) finish(); } });
    }

    private void details(AkCards.Card c) {
        long[] o = owned.get(c.code);
        String extra = o == null ? "\n\nNot in your collection yet." : "\n\nFirst scanned: " + DateFormat.getDateTimeInstance().format(new Date(o[0])) + "\nScanned " + o[1] + (o[1] == 1 ? " time" : " times");
        new AlertDialog.Builder(this).setTitle(c.name).setMessage(c.details() + extra).setPositiveButton("OK", null).show();
    }
}

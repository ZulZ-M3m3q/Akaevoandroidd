package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.SecureRandom;
import java.util.Iterator;
import java.util.Map;

/**
 * A.17-A.19 account link. The app shows a code, the player types it on the website, the app then unlocks.
 * The device secret never leaves the phone except as the Authorization header to the account site (HTTPS only).
 */
public final class AkLink {
    public static final int LINKED = 1, NOT_LINKED = 2, OFFLINE = 3, NOT_CONFIGURED = 4;
    /** How long the game keeps working without being able to reach the site (days). */
    public static final long GRACE_MS = 7L * 24 * 3600 * 1000;
    private static final long FRESH_MS = 2L * 60 * 1000;   // a check younger than this is not repeated on PLAY
    private static final Handler UI = new Handler(Looper.getMainLooper());

    public static final class Status {
        public int state;
        public String username = "", code = "", message = "";
        public int expiresIn;
    }
    public interface Cb { void done(Status s); }
    public interface Msg { void done(boolean ok, String message); }

    private static final class Resp { int code; String body = ""; boolean net; String err = ""; }

    // ------------------------------------------------------------------ local state
    private static SharedPreferences sp(Context c) { return AkConfig.sp(c); }

    /** Site address chosen when the APK was built (the "web_url" box of the build workflow). */
    public static String baseUrl(Context c) {
        String u = AkConfig.webUrl(c).trim();
        while (u.endsWith("/")) u = u.substring(0, u.length() - 1);
        return u;
    }
    public static boolean configured(Context c) { return baseUrl(c).startsWith("https://"); }

    private static String secret(Context c) {
        String s = sp(c).getString("dev_secret", "");
        if (s.length() < 64) {
            byte[] b = new byte[32]; new SecureRandom().nextBytes(b);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < b.length; i++) sb.append(String.format("%02x", b[i] & 0xff));
            s = sb.toString();
            sp(c).edit().putString("dev_secret", s).commit();
        }
        return s;
    }

    // ------------------------------------------------------------------ link code made by the app itself (A.19)
    private static final String CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";   // no 0/O/1/I, same as the website
    private static final long CODE_TTL_MS = 15L * 60 * 1000;                         // same lifetime as on the website

    /** The 8-character link code of this phone, made here with SecureRandom (kept for 15 min, then replaced). Works with no internet. */
    public static synchronized String localCode(Context c) {
        long t = System.currentTimeMillis();
        String code = sp(c).getString("dev_code", ""); long exp = sp(c).getLong("dev_code_exp", 0);
        if (code.length() == 8 && exp > t + 30000 && exp <= t + CODE_TTL_MS + 60000) return code;   // still good (and the clock was not moved)
        SecureRandom r = new SecureRandom(); StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) sb.append(CODE_ALPHABET.charAt(r.nextInt(CODE_ALPHABET.length())));
        code = sb.toString();
        sp(c).edit().putString("dev_code", code).putLong("dev_code_exp", t + CODE_TTL_MS).commit();
        return code;
    }
    public static String pretty(String code) { return code != null && code.length() == 8 ? code.substring(0, 4) + "-" + code.substring(4) : (code == null ? "" : code); }

    public static boolean linkedCached(Context c) { return sp(c).getBoolean("link_ok", false); }
    public static String username(Context c) { return sp(c).getString("link_user", ""); }

    /** True when the game may start: linked, and verified recently enough (works offline for GRACE_MS). */
    public static boolean isUsable(Context c) {
        if (!linkedCached(c)) return false;
        long age = System.currentTimeMillis() - sp(c).getLong("link_verified", 0);
        return age >= -24L * 3600 * 1000 && age < GRACE_MS;   // negative age beyond a day = clock was set back
    }

    private static void saveState(Context c, boolean linked, String user) {
        SharedPreferences.Editor e = sp(c).edit();
        e.putBoolean("link_ok", linked).putString("link_user", linked ? user : "");
        if (linked) e.putLong("link_verified", System.currentTimeMillis()).remove("dev_code").remove("dev_code_exp");
        e.commit();
    }

    public static Intent linkIntent(Context c, boolean fromPlay) {
        Intent i = new Intent(c, AkLinkActivity.class);
        i.putExtra(AkLinkActivity.EXTRA_FROM_PLAY, fromPlay);
        return i;
    }

    // ------------------------------------------------------------------ http
    private static volatile String lastDiag = "";
    /** What the last request did, e.g. "POST https://x.netlify.app/api/device/status -> HTTP 401 {...}". Shown on the link screen. */
    public static String lastDiag() { return lastDiag; }

    private static String snip(String b) {
        if (b == null) return "";
        String t = b.replaceAll("\\s+", " ").trim();
        return t.length() > 140 ? t.substring(0, 140) + "..." : t;
    }

    private static Resp call(Context c, String method, String path, String json) {
        Resp r = new Resp(); HttpURLConnection h = null;
        String target = baseUrl(c) + path;
        try {
            for (int hop = 0; hop < 4; hop++) {
                h = (HttpURLConnection) new URL(target).openConnection();
                h.setInstanceFollowRedirects(false);            // followed by hand below so POST keeps its body
                h.setConnectTimeout(15000); h.setReadTimeout(30000);   // free hosts can take ~30 s to wake up
                h.setRequestMethod(method);
                h.setRequestProperty("Authorization", "Device " + secret(c));
                h.setRequestProperty("Accept", "application/json");
                h.setRequestProperty("User-Agent", "AkaiserEvodroid/" + AkConfig.VERSION);
                if (json != null) {
                    byte[] b = json.getBytes("UTF-8");
                    h.setDoOutput(true); h.setRequestProperty("Content-Type", "application/json");
                    OutputStream os = h.getOutputStream(); os.write(b); os.close();
                }
                r.code = h.getResponseCode();
                if (r.code >= 300 && r.code < 400) {
                    String loc = h.getHeaderField("Location");
                    h.disconnect();
                    if (loc == null || loc.length() == 0) break;
                    URL next = new URL(new URL(target), loc);
                    if (!"https".equals(next.getProtocol())) { r.net = true; r.err = "redirected to a non-https address: " + next; break; }
                    target = next.toString();
                    continue;
                }
                InputStream is = r.code >= 400 ? h.getErrorStream() : h.getInputStream();
                if (is != null) {
                    ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[4096]; int n;
                    while ((n = is.read(b)) > 0 && o.size() < 200000) o.write(b, 0, n);
                    is.close(); r.body = o.toString("UTF-8");
                }
                break;
            }
        } catch (Exception e) {
            r.net = true; r.err = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
        } finally { if (h != null) h.disconnect(); }
        lastDiag = method + " " + target + " -> " + (r.net ? r.err : "HTTP " + r.code + " " + snip(r.body));
        return r;
    }

    private static String serverError(Resp r) {
        try { String m = new JSONObject(r.body).optString("error", ""); if (m.length() > 0) return m + " (HTTP " + r.code + ")"; } catch (Exception ignored) { }
        if (r.net) return "No connection (" + r.err + ")";
        return "HTTP " + r.code + " - this address is not the account website's API. Reply: " + snip(r.body);
    }

    private static void post(final Runnable r) { UI.post(r); }

    // ------------------------------------------------------------------ status / verify
    /** Asks the site where this phone stands (and gets a fresh link code while it is not linked). Callback runs on the UI thread. */
    public static void status(Context c0, final Cb cb) {
        final Context c = c0.getApplicationContext();
        if (!configured(c)) {
            final Status s = new Status(); s.state = NOT_CONFIGURED;
            s.message = "This build has no account website address. Rebuild the app and fill in web_url.";
            post(new Runnable() { public void run() { cb.done(s); } }); return;
        }
        new Thread(new Runnable() { public void run() {
            final Status s = new Status();
            try {
                Resp r = call(c, "POST", "/api/device/status", new JSONObject().put("name", Build.MODEL == null ? "Android" : Build.MODEL).put("code", localCode(c)).toString());
                if (r.net || r.code != 200) {          // offline, 429, 5xx ... : keep the cached state (grace period applies)
                    s.state = OFFLINE; s.message = serverError(r);
                } else {
                    JSONObject j = new JSONObject(r.body);
                    if (!j.has("linked")) {
                        s.state = OFFLINE; s.message = "Reply is not the account API: " + snip(r.body);
                    } else if (j.optBoolean("linked", false)) {
                        s.state = LINKED; s.username = j.optString("username", "");
                        saveState(c, true, s.username);
                        AkPlayTime.flush(c);                              // A.20: send play time that was waiting for the link
                    } else {
                        s.state = NOT_LINKED; s.code = j.optString("code", ""); s.expiresIn = j.optInt("expiresIn", 0);
                        String plain = s.code.replace("-", "");
                        if (plain.length() == 8 && s.expiresIn > 0)      // the site's code wins if it had to replace ours (clash)
                            sp(c).edit().putString("dev_code", plain).putLong("dev_code_exp", System.currentTimeMillis() + s.expiresIn * 1000L).commit();
                        saveState(c, false, "");     // the site says: not linked (or unlinked from the website)
                    }
                }
            } catch (Exception e) { s.state = OFFLINE; s.message = "Reply is not the account API (" + e.getClass().getSimpleName() + "): " + snip(lastDiag); }
            if (s.state == OFFLINE && !linkedCached(c)) s.code = pretty(localCode(c));   // no answer from the site: still show the code made here
            post(new Runnable() { public void run() { cb.done(s); } });
        } }).start();
    }

    /** Called by PLAY: runs ok when the account is linked, otherwise opens the link screen. */
    public static void requireLinked(final Activity a, final Runnable ok) {
        if (!configured(a)) { a.startActivity(linkIntent(a, true)); return; }
        long age = System.currentTimeMillis() - sp(a).getLong("link_verified", 0);
        if (linkedCached(a) && age >= 0 && age < FRESH_MS) { ok.run(); return; }
        Toast.makeText(a, "Checking your account...", Toast.LENGTH_SHORT).show();
        status(a, new Cb() { public void done(Status s) {
            if (s.state == LINKED) ok.run();
            else if (s.state == OFFLINE && isUsable(a)) ok.run();    // offline but verified within the last 7 days
            else {
                if (s.state == OFFLINE) Toast.makeText(a, "Cannot reach the account website. Connect to the internet once to check your account.", Toast.LENGTH_LONG).show();
                a.startActivity(linkIntent(a, true));
            }
        } });
    }

    /** A.20, used by AkPlayTime: sends finished play sessions. Returns the HTTP code, -1 when there was no connection, -2 when this phone is not linked / has no site. */
    public static int postPlaytime(Context c, String json) {
        if (!configured(c) || !linkedCached(c)) return -2;
        Resp r = call(c, "POST", "/api/device/playtime", json);
        return r.net ? -1 : r.code;
    }

    /** Connection test for the link screen: asks GET /api/ping and reports what happened. */
    public static void ping(Context c0, final Msg cb) {
        final Context c = c0.getApplicationContext();
        if (!configured(c)) { cb.done(false, "This build has no account website address (web_url)."); return; }
        new Thread(new Runnable() { public void run() {
            Resp r = call(c, "GET", "/api/ping", null);
            boolean ok = false;
            try { ok = !r.net && r.code == 200 && new JSONObject(r.body).optBoolean("ok", false); } catch (Exception ignored) { }
            final boolean fok = ok;
            final String msg = ok ? "Connection OK. The account website answers at " + baseUrl(c) : "Test failed: " + lastDiag;
            post(new Runnable() { public void run() { cb.done(fok, msg); } });
        } }).start();
    }

    public static void unlink(Context c0, final Msg cb) {
        final Context c = c0.getApplicationContext();
        if (!configured(c)) { cb.done(false, "No account website in this build."); return; }
        new Thread(new Runnable() { public void run() {
            final Resp r = call(c, "POST", "/api/device/unlink", "{}");
            final boolean ok = !r.net && r.code == 200;
            if (ok) saveState(c, false, "");
            post(new Runnable() { public void run() { cb.done(ok, ok ? "This device is unlinked." : "Could not unlink: " + serverError(r) + ". Unlinking needs internet."); } });
        } }).start();
    }

    // ------------------------------------------------------------------ cloud backup of the app's settings
    private static boolean skipKey(String k) { return k.startsWith("dev_") || k.startsWith("link_"); }

    public static void backup(Context c0, final Msg cb) {
        final Context c = c0.getApplicationContext();
        new Thread(new Runnable() { public void run() {
            boolean ok = false; String msg;
            try {
                JSONObject data = new JSONObject();
                for (Map.Entry<String, ?> e : sp(c).getAll().entrySet()) {
                    Object v = e.getValue();
                    if (skipKey(e.getKey())) continue;
                    if (v instanceof Boolean || v instanceof Integer || v instanceof Long || v instanceof String) data.put(e.getKey(), v);
                }
                Resp r = call(c, "PUT", "/api/device/data", new JSONObject().put("data", data).toString());
                ok = !r.net && r.code == 200;
                msg = ok ? "Settings and button layouts saved to your account." : "Backup failed: " + serverError(r);
            } catch (Exception e) { msg = "Backup failed: " + e.getMessage(); }
            final boolean fok = ok; final String fmsg = msg;
            post(new Runnable() { public void run() { cb.done(fok, fmsg); } });
        } }).start();
    }

    public static void restore(Context c0, final Msg cb) {
        final Context c = c0.getApplicationContext();
        new Thread(new Runnable() { public void run() {
            boolean ok = false; String msg;
            try {
                Resp r = call(c, "GET", "/api/device/data", null);
                if (r.net || r.code != 200) msg = "Restore failed: " + serverError(r);
                else {
                    JSONObject data = new JSONObject(r.body).optJSONObject("data");
                    if (data == null) msg = "No backup saved in your account yet.";
                    else {
                        SharedPreferences.Editor e = sp(c).edit(); int n = 0;
                        Iterator<String> it = data.keys();
                        while (it.hasNext()) {
                            String k = it.next(); Object v = data.get(k);
                            if (skipKey(k)) continue;
                            if (AkCollection.KEY.equals(k) && v instanceof String) { AkCollection.mergeFromBackup(c, (String) v); n++; continue; }   // A.21: keep local cards
                            if (v instanceof Boolean) { e.putBoolean(k, (Boolean) v); n++; }
                            else if (v instanceof Integer) { e.putInt(k, (Integer) v); n++; }
                            else if (v instanceof Long && (Long) v >= Integer.MIN_VALUE && (Long) v <= Integer.MAX_VALUE) { e.putInt(k, (int) (long) (Long) v); n++; }
                            else if (v instanceof String) { e.putString(k, (String) v); n++; }
                        }
                        e.commit(); ok = true; msg = "Restored " + n + " settings. Restart the app to apply everything.";
                    }
                }
            } catch (Exception e) { msg = "Restore failed: " + e.getMessage(); }
            final boolean fok = ok; final String fmsg = msg;
            post(new Runnable() { public void run() { cb.done(fok, fmsg); } });
        } }).start();
    }
}

#!/usr/bin/env python3
"""AkaiserEvodroid A.1 patcher for a fresh checkout of jpd002/Play-.
Every step is verified; ANY problem aborts with a clear message (exit code 1) so the build never continues half-patched."""
import os, re, sys, shutil, glob

PLAY = os.path.abspath(sys.argv[1]); HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
APP_ID, APP_NAME, VERSION = "com.akaiser.evodroid", "AkaiserEvodroid", "A.1"
SKIP = {"build", ".git", "Dependencies", "node_modules", ".gradle", ".cxx", ".idea"}
def log(*a): print("[akevo]", *a, flush=True)
def die(m, extra=None):
    print("[akevo] ERROR:", m, flush=True)
    if extra: print(extra, flush=True)
    sys.exit(1)
def rd(p): return open(p, encoding="utf-8", errors="surrogateescape").read()
def wr(p, s): open(p, "w", encoding="utf-8", errors="surrogateescape").write(s)
def walk(sub, pat):
    for r, d, f in os.walk(os.path.join(PLAY, sub)):
        d[:] = [x for x in d if x not in SKIP]
        for n in f:
            if re.search(pat, n): yield os.path.join(r, n)
def rel(p): return os.path.relpath(p, PLAY)

# ---- 0. project layout report (always printed, helps diagnose future failures) ---------------------
BA = os.path.join(PLAY, "build_android")
if not os.path.isdir(BA): die("build_android/ not found in the Play! checkout", "top level: " + ", ".join(sorted(os.listdir(PLAY))))
log("build_android contents:", ", ".join(sorted(os.listdir(BA))))
log("manifests found:", [rel(p) for p in walk(".", r"^AndroidManifest\.xml$")])
log("gradle files found:", [rel(p) for p in walk("build_android", r"^build\.gradle(\.kts)?$")])

# ---- 1. overlay sources ---------------------------------------------------------------------------------
emu = list(walk("Source", r"^EmulatorActivity\.java$"))
if not emu: die("EmulatorActivity.java not found (Play! layout changed)")
jdir = os.path.dirname(emu[0]); dst = os.path.join(jdir, "akevo"); os.makedirs(dst, exist_ok=True)
need = ["AkConfig", "AkInput", "AkHttp", "AkPadView", "AkOverlay", "AkSettingsActivity", "AkScanActivity"]
for n in need:
    s = os.path.join(ROOT, "overlay", "akevo", n + ".java")
    if not os.path.exists(s): die("overlay source missing: " + s)
    shutil.copy(s, dst)
log("copied", len(need), "overlay classes to", rel(dst))

# ---- 2. card-scan endpoint discovery (informational + defaults) ----------------------------------------
port, path, method, body, detected = 8080, "/", "POST", "{code}", False
src_files = [p for p in walk("Source", r"\.(cpp|h|hpp|java)$") if "/akevo/" not in p.replace(os.sep, "/")]
hits = []
for p in src_files:
    try: s = rd(p)
    except Exception: continue
    if re.search(r"HttpServer", s) and re.search(r"namco|sys147|barcode|arcade", p + s[:4000], re.I): hits.append((p, s))
log("AKEVO endpoint scan: %d candidate file(s) mention an HTTP server" % len(hits))
for p, s in hits:
    log("  file:", rel(p))
    for i, line in enumerate(s.splitlines()):
        if re.search(r"(?i)barcode|HttpServer|http|port\b|\"/[A-Za-z_/]*\"", line) and len(line) < 220:
            print("    %5d: %s" % (i + 1, line.strip()), flush=True)
    m = re.search(r"CHttpServer\s*>?\s*(?:\w+\s*)?[\(\{]\s*(\d{3,5})", s) or re.search(r"(?i)http\w*port\w*\s*[=:\(]\s*(\d{3,5})", s)
    if m: port = int(m.group(1)); detected = True; log("  -> port", port)
    m = re.search(r"\"(/[A-Za-z0-9_/\-]*)\"", s)
    if m and detected: path = m.group(1); log("  -> path", path)
tmpl = rd(os.path.join(ROOT, "overlay", "akevo", "AkDefaults.java.template"))
wr(os.path.join(dst, "AkDefaults.java"), tmpl.replace("@PORT@", str(port)).replace("@PATH@", path).replace("@METHOD@", method).replace("@BODY@", body).replace("@DETECTED@", "true" if detected else "false"))
log("endpoint defaults: %s 127.0.0.1:%d%s detected=%s (Settings -> 'Find endpoint automatically' can correct this)" % (method, port, path, detected))

# ---- 3. hook overlay into EmulatorActivity.onCreate ---------------------------------------------------
HOOK = "com.virtualapplications.play.akevo.AkOverlay.attach(this);"
s = rd(emu[0])
if HOOK not in s:
    m = re.search(r"super\.onCreate\([^;]*\);", s)
    if not m: die("super.onCreate(...) not found in EmulatorActivity.java")
    s = s[:m.end()] + "\n\t\t" + HOOK + s[m.end():]; wr(emu[0], s)
log("hooked", rel(emu[0]))

# ---- 4. manifest ------------------------------------------------------------------------------------------
cands = [os.path.join(BA, "src", "main", "AndroidManifest.xml")] + list(walk("build_android", r"^AndroidManifest\.xml$")) + list(walk("Source", r"^AndroidManifest\.xml$"))
man = next((p for p in cands if os.path.exists(p) and "<application" in rd(p)), None)
if not man: die("no AndroidManifest.xml containing <application> found", "looked at: %s" % [rel(p) for p in cands])
m = rd(man)
if "AkSettingsActivity" not in m:
    acts = ('\n\t\t<activity android:name="com.virtualapplications.play.akevo.AkSettingsActivity" android:exported="false" android:label="%s Settings" android:theme="@android:style/Theme.Material.Light.NoActionBar" />'
            '\n\t\t<activity android:name="com.virtualapplications.play.akevo.AkScanActivity" android:exported="false" android:theme="@style/Theme.AppCompat.NoActionBar" />\n\t' % APP_NAME)
    if "</application>" not in m:                                   # tolerate a self-closing <application ... />
        m, k = re.subn(r"(<application\b[^>]*?)\s*/>", r"\1></application>", m, 1, flags=re.S)
        if not k: die("</application> missing in " + rel(man))
    m = m.replace("</application>", acts + "</application>", 1)
    add = ""
    for pm in ("android.permission.CAMERA", "android.permission.INTERNET", "android.permission.VIBRATE"):
        if pm not in m: add += '\n\t<uses-permission android:name="%s" />' % pm
    if "android.hardware.camera" not in m: add += '\n\t<uses-feature android:name="android.hardware.camera" android:required="false" />'
    m2 = re.sub(r"(<manifest\b[^>]*>)", lambda x: x.group(1) + add, m, 1, flags=re.S)
    if m2 == m and add: die("could not locate <manifest ...> tag to add permissions")
    m = m2
    m = re.sub(r'(<application\b[^>]*?android:label=")[^"]*(")', r"\g<1>%s\2" % APP_NAME, m, 1, flags=re.S)
    wr(man, m)
if "AkScanActivity" not in rd(man): die("manifest patch did not apply")
log("manifest patched:", rel(man))

# ---- 5. app name -------------------------------------------------------------------------------------------
n = 0
for p in walk("build_android", r"\.xml$"):
    if "/res/values" not in p.replace(os.sep, "/"): continue
    t = rd(p)
    if 'name="app_name"' in t:
        wr(p, re.sub(r'(<string\b[^>]*name="app_name"[^>]*>)[^<]*(</string>)', r"\g<1>%s\2" % APP_NAME, t)); n += 1
log("app_name updated in %d resource file(s)" % n)

# ---- 6. Gradle: id, version, ABI, SDK levels, dependencies -------------------------------------------
gcands = [os.path.join(BA, "build.gradle"), os.path.join(BA, "build.gradle.kts")] + list(walk("build_android", r"^build\.gradle(\.kts)?$"))
g = next((p for p in gcands if os.path.exists(p) and "applicationId" in rd(p)), None)
if not g: die("no build.gradle with applicationId found", "looked at: %s" % [rel(p) for p in gcands])
t = rd(g); kts = g.endswith(".kts"); q = lambda v: ('= "%s"' if kts else '"%s"') % v
t, c = re.subn(r"applicationId\s*=?\s*[\"'][^\"']+[\"']", "applicationId " + q(APP_ID), t, 1)
if not c: die("applicationId not replaced")
t = re.sub(r"versionName\s*=?\s*[\"'][^\"']*[\"']", "versionName " + q(VERSION), t, 1)
mc = re.search(r"compileSdk(?:Version)?\s*=?\s*(\d+)", t); csdk = int(mc.group(1)) if mc else 34
mm = re.search(r"minSdk(?:Version)?\s*=?\s*(\d+)", t)
if mm and int(mm.group(1)) < 21: t = t[:mm.start(1)] + "21" + t[mm.end(1):]; log("minSdk raised to 21")
cam = "1.3.4" if csdk >= 34 else "1.2.3"
log("compileSdk=%d -> CameraX %s" % (csdk, cam))
deps = ["androidx.camera:camera-core:" + cam, "androidx.camera:camera-camera2:" + cam, "androidx.camera:camera-lifecycle:" + cam,
        "androidx.camera:camera-view:" + cam, "com.google.mlkit:barcode-scanning:17.3.0"]
def line(d): return ('    implementation("%s")' if kts else "    implementation '%s'") % d
if "mlkit" not in t:
    block = "\n".join(line(d) for d in deps)
    m3 = re.search(r"^dependencies\s*\{", t, re.M)
    t = (t[:m3.end()] + "\n" + block + t[m3.end():]) if m3 else (t + "\n\ndependencies {\n" + block + "\n}\n")
# ABI: arm64 only by default (4x faster build, smaller APK). Set AK_ABIS=all to keep every ABI.
if os.environ.get("AK_ABIS", "arm64").lower() != "all":
    t2, c2 = re.subn(r"abiFilters\b[^\n}]*", ("abiFilters += listOf(\"arm64-v8a\") " if kts else "abiFilters 'arm64-v8a' "), t, 1)
    log("ABI filter -> arm64-v8a only" if c2 else "WARNING: abiFilters not found; building all ABIs (slower)"); t = t2
wr(g, t)
t = rd(g)
for need_s in ("mlkit", APP_ID):
    if need_s not in t: die("Gradle patch verification failed: '%s' missing in %s" % (need_s, rel(g)))
log("gradle patched:", rel(g))

# ---- 7. final verification ---------------------------------------------------------------------------------
for f in need + ["AkDefaults"]:
    if not os.path.exists(os.path.join(dst, f + ".java")): die("verification: missing " + f + ".java")
if HOOK not in rd(emu[0]): die("verification: hook missing")
log("ALL PATCHES VERIFIED - AkaiserEvodroid", VERSION)

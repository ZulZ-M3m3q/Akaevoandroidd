package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.ViewGroup;

/** Hooked into Play!'s EmulatorActivity.onCreate by apply_patches.py. */
public final class AkOverlay {
    private static AkPadView pad;
    private static Activity emu;
    private static boolean registered = false;

    public static void attach(final Activity a) {
        emu = a; pad = null;
        a.getWindow().getDecorView().post(new Runnable() { public void run() {
            try {
                pad = new AkPadView(a);
                a.addContentView(pad, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            } catch (Throwable t) { pad = null; }
        }});
        if (!registered) {
            registered = true;
            a.getApplication().registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                public void onActivityResumed(Activity x) {
                    if (x == emu && pad != null) {
                        pad.reload();
                        if (AkConfig.editRequested) { AkConfig.editRequested = false; pad.setEdit(true); }
                    }
                }
                public void onActivityPaused(Activity x) { if (x == emu) AkInput.releaseAll(x); }
                public void onActivityCreated(Activity x, Bundle b) { }
                public void onActivityStarted(Activity x) { }
                public void onActivityStopped(Activity x) { }
                public void onActivitySaveInstanceState(Activity x, Bundle b) { }
                public void onActivityDestroyed(Activity x) { if (x == emu) { emu = null; pad = null; } }
            });
        }
    }

    /** Used by settings/scan screens to send a card into the running game. */
    public static Activity emulatorActivity() { return emu; }
}

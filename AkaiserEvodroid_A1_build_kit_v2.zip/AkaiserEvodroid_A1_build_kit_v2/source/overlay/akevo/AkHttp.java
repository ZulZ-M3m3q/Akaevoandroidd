package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Sends a card barcode to Play!'s built-in "Arcade I/O HTTP Server" (same device, loopback). */
public final class AkHttp {
    public interface Result { void done(boolean ok, String message); }

    public static void send(final Activity a, final String code, final Result cb) {
        new Thread(new Runnable() { public void run() {
            boolean ok = false; String msg;
            try {
                String path = AkConfig.path(a).replace("{code}", code);
                URL u = new URL("http://" + AkConfig.host(a) + ":" + AkConfig.port(a) + path);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(3000); c.setReadTimeout(3000);
                String method = AkConfig.method(a);
                c.setRequestMethod(method);
                if ("POST".equals(method) || "PUT".equals(method)) {
                    byte[] body = AkConfig.bodyTemplate(a).replace("{code}", code).getBytes("UTF-8");
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "text/plain");
                    OutputStream os = c.getOutputStream(); os.write(body); os.close();
                }
                int rc = c.getResponseCode();
                String text = "";
                try { InputStream is = rc < 400 ? c.getInputStream() : c.getErrorStream();
                      if (is != null) { byte[] b = new byte[512]; int n = is.read(b); if (n > 0) text = new String(b, 0, n, "UTF-8"); } } catch (Exception ignored) { }
                ok = rc >= 200 && rc < 300;
                msg = "HTTP " + rc + (text.length() > 0 ? " " + text.trim() : "") + "  -> " + u;
            } catch (Exception e) {
                msg = "Failed: " + e.getClass().getSimpleName() + " " + e.getMessage()
                    + "\nIs 'Arcade I/O HTTP Server' enabled in Play! settings, and is a game running?";
            }
            final boolean fok = ok; final String fmsg = msg;
            a.runOnUiThread(new Runnable() { public void run() {
                Toast.makeText(a, (fok ? "Card sent: " + code : "Card NOT sent") + "\n" + fmsg, Toast.LENGTH_LONG).show();
                if (cb != null) cb.done(fok, fmsg);
            }});
        }}).start();
    }
    /** Tries common ports/paths on this phone and saves the first one that answers with HTTP 2xx. */
    public static void probe(final Activity a, final Result cb) {
        new Thread(new Runnable() { public void run() {
            int[] ports = {AkConfig.port(a), 8080, 8000, 8888, 8081, 80, 3000, 5000, 9000};
            String[] paths = {AkConfig.path(a), "/", "/barcode", "/scan", "/card", "/api/barcode", "/api/scan", "/io"};
            StringBuilder sb = new StringBuilder(); boolean found = false;
            java.util.HashSet<Integer> done = new java.util.HashSet<Integer>();
            for (int p : ports) {
                if (!done.add(p) || found) continue;
                int first = req(p, paths[0], "POST", "00000000");
                if (first == -1) { sb.append("port ").append(p).append(": closed\n"); continue; }
                sb.append("port ").append(p).append(": OPEN\n");
                for (String m : new String[]{"POST", "GET"}) {
                    for (String path : paths) {
                        int rc = req(p, path, m, "00000000");
                        sb.append("   ").append(m).append(' ').append(path).append(" -> ").append(rc).append('\n');
                        if (rc >= 200 && rc < 300 && !found) {
                            found = true;
                            AkConfig.put(a, "port", p); AkConfig.put(a, "path", path); AkConfig.put(a, "method", m); AkConfig.put(a, "body", "{code}");
                            sb.append("   >>> saved: ").append(m).append(" port ").append(p).append(" path ").append(path).append('\n');
                        }
                    }
                }
            }
            if (!found) sb.append("\nNo working endpoint found. Make sure a game is running and 'Arcade I/O HTTP Server' is ON in Play! settings.");
            final String out = sb.toString(); final boolean ok = found;
            a.runOnUiThread(new Runnable() { public void run() { if (cb != null) cb.done(ok, out); } });
        }}).start();
    }

    /** returns HTTP status, -1 = connection refused, -2 = other failure */
    private static int req(int port, String path, String method, String code) {
        try {
            java.net.URL u = new java.net.URL("http://127.0.0.1:" + port + path.replace("{code}", code));
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setConnectTimeout(600); c.setReadTimeout(900); c.setRequestMethod(method);
            if ("POST".equals(method)) { c.setDoOutput(true); OutputStream os = c.getOutputStream(); os.write(code.getBytes("UTF-8")); os.close(); }
            return c.getResponseCode();
        } catch (java.net.ConnectException e) { return -1;
        } catch (Exception e) { return -2; }
    }
}

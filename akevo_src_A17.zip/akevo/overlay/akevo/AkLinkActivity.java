package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** "Link your account" screen: shows the code, waits until the player has typed it on the website, then closes. */
public class AkLinkActivity extends Activity {
    public static final String EXTRA_FROM_PLAY = "from_play";
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean running, fromPlay;
    private TextView title, codeView, steps, status;
    private Button openBtn, copyBtn, unlinkBtn;
    private String lastCode = "";

    private TextView tv(LinearLayout p, String t, int sp, int color, boolean bold, int topDp) {
        float d = getResources().getDisplayMetrics().density;
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (topDp * d); p.addView(v, lp); return v;
    }
    private Button btn(LinearLayout p, String t, View.OnClickListener l) {
        float d = getResources().getDisplayMetrics().density;
        Button b = new Button(this); b.setText(t); b.setAllCaps(false); b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (8 * d); p.addView(b, lp); return b;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        fromPlay = getIntent().getBooleanExtra(EXTRA_FROM_PLAY, false);
        float d = getResources().getDisplayMetrics().density; int pad = (int) (18 * d);
        ScrollView sv = new ScrollView(this); sv.setBackgroundColor(0xFF0B1117); sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad, pad, pad, pad * 2); root.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
        setTitle("AkaiserEvodroid account");

        title = tv(root, "Link your account", 24, 0xFFF2B705, true, 0);
        codeView = tv(root, "----", 40, 0xFFFFFFFF, true, 14); codeView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); codeView.setLetterSpacing(0.12f);
        steps = tv(root, "", 15, 0xFFDDE6EE, false, 10);
        status = tv(root, "Checking...", 14, 0xFF8FA3B8, false, 10);
        openBtn = btn(root, "Open the website", new View.OnClickListener() { public void onClick(View v) { AkArcade.openLink(AkLinkActivity.this, AkLink.baseUrl(AkLinkActivity.this)); } });
        copyBtn = btn(root, "Copy code", new View.OnClickListener() { public void onClick(View v) {
            if (lastCode.length() == 0) return;
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("link code", lastCode));
            Toast.makeText(AkLinkActivity.this, "Code copied", Toast.LENGTH_SHORT).show(); } });
        unlinkBtn = btn(root, "Unlink this device", new View.OnClickListener() { public void onClick(View v) { confirmUnlink(); } });
        btn(root, "Close", new View.OnClickListener() { public void onClick(View v) { finish(); } });
        unlinkBtn.setVisibility(View.GONE);
    }

    private void confirmUnlink() {
        new AlertDialog.Builder(this).setTitle("Unlink this device?")
            .setMessage("The game will ask for a new code the next time you press PLAY.")
            .setPositiveButton("Unlink", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                AkLink.unlink(AkLinkActivity.this, new AkLink.Msg() { public void done(boolean ok, String message) {
                    Toast.makeText(AkLinkActivity.this, message, Toast.LENGTH_LONG).show();
                    if (ok && running) { h.removeCallbacksAndMessages(null); poll(); } } }); } })
            .setNegativeButton("Cancel", null).show();
    }

    @Override protected void onResume() { super.onResume(); running = true; poll(); }
    @Override protected void onPause() { super.onPause(); running = false; h.removeCallbacksAndMessages(null); }

    private void poll() {
        if (!running) return;
        AkLink.status(this, new AkLink.Cb() { public void done(AkLink.Status s) {
            if (!running) return;
            render(s);
            if (s.state != AkLink.LINKED && s.state != AkLink.NOT_CONFIGURED)
                h.postDelayed(new Runnable() { public void run() { poll(); } }, 3000);
        } });
    }

    private void render(AkLink.Status s) {
        String url = AkLink.baseUrl(this);
        switch (s.state) {
            case AkLink.LINKED:
                if (fromPlay) { Toast.makeText(this, "Account linked as " + s.username + ". Press PLAY!", Toast.LENGTH_LONG).show(); finish(); return; }
                title.setText("Account linked"); codeView.setVisibility(View.GONE); copyBtn.setVisibility(View.GONE); unlinkBtn.setVisibility(View.VISIBLE);
                steps.setText("Linked as " + s.username + ".\nThis phone can play the game."); status.setText("");
                break;
            case AkLink.NOT_LINKED:
                title.setText("Link your account"); unlinkBtn.setVisibility(View.GONE); copyBtn.setVisibility(View.VISIBLE);
                lastCode = s.code; codeView.setText(s.code); codeView.setVisibility(View.VISIBLE);
                steps.setText("1. On any phone or PC open\n" + url + "\n2. Sign up (or log in)\n3. Type this code under \"Link your app\"");
                status.setText("Waiting for you to enter the code on the website... (valid " + Math.max(1, s.expiresIn / 60) + " min)");
                break;
            case AkLink.NOT_CONFIGURED:
                title.setText("Not set up"); codeView.setVisibility(View.GONE); copyBtn.setVisibility(View.GONE); openBtn.setVisibility(View.GONE);
                steps.setText(s.message); status.setText("");
                break;
            default:   // OFFLINE
                status.setText("Cannot reach the account website. Check your internet. Retrying...\n" + s.message);
                if (lastCode.length() == 0) { steps.setText("Needs an internet connection for the first link."); }
        }
    }
}

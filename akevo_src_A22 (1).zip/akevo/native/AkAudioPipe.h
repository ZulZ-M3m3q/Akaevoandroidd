#pragma once
// Jitter buffer between the emulator thread (producer) and the OpenSL callback (consumer).
// Single producer, single consumer, lock-free. Stereo int16 frames.
//
// Why: upstream CSH_OpenSL enqueues the emulator's own m_samples array into OpenSL without copying,
// while the SPU keeps overwriting that same array, and it silently drops whole chunks when the queue
// is full. Both produce crackle. Here the data is copied into a private ring and the device is fed
// from it in small buffers. On underrun the sound fades out, waits for a short pre-buffer, and
// fades back in, instead of clicking.
#include <atomic>
#include <cstdint>
#include <cstring>
#include <vector>

// A.16: master volume in percent (0..150), set from Java through AkAudio.nativeSetVolume. 100 = unchanged.
inline std::atomic<int> g_akVolumePercent{100};

class AkAudioPipe
{
public:
	// capacityFrames must be a power of two. 65536 frames = 1.5 s at 44.1 kHz (max SPU burst is 400*45 = 18000).
	explicit AkAudioPipe(uint32_t capacityFrames = 65536, uint32_t targetFrames = 3528 /* 80 ms */)
	    : m_cap(capacityFrames)
	    , m_mask(capacityFrames - 1)
	    , m_target(targetFrames)
	    , m_buf(size_t(capacityFrames) * 2)
	{
	}

	// ---- producer (emulator thread) ----
	uint32_t Push(const int16_t* in, uint32_t frames)
	{
		uint32_t w = m_w.load(std::memory_order_relaxed);
		uint32_t used = w - m_r.load(std::memory_order_acquire);
		uint32_t space = m_cap - used;
		uint32_t n = frames < space ? frames : space;
		for(uint32_t i = 0; i < n; i++)
		{
			size_t o = size_t((w + i) & m_mask) * 2;
			m_buf[o] = in[i * 2];
			m_buf[o + 1] = in[i * 2 + 1];
		}
		m_w.store(w + n, std::memory_order_release);
		m_burst.store(frames, std::memory_order_relaxed); // the emulator writes in bursts; we need a margin bigger than one burst
		if(n < frames) m_overflows.fetch_add(1, std::memory_order_relaxed);
		return n;
	}

	// Ask the consumer to throw away everything buffered (safe from any thread).
	void RequestClear() { m_clear.store(true, std::memory_order_release); }

	// ---- consumer (audio callback; no locks, no allocation, no logging) ----
	void Pull(int16_t* out, uint32_t frames)
	{
		if(m_clear.exchange(false, std::memory_order_acq_rel))
		{
			m_r.store(m_w.load(std::memory_order_acquire), std::memory_order_release);
			m_starved = true;
		}
		uint32_t avail = m_w.load(std::memory_order_acquire) - m_r.load(std::memory_order_relaxed);

		if(m_starved)
		{
			uint32_t need = m_burst.load(std::memory_order_relaxed) + MARGIN_FRAMES;
			if(need < m_target) need = m_target;
			if(avail < need)
			{
				std::memset(out, 0, size_t(frames) * 4);
				return;
			}
			m_starved = false;
			m_fadeIn = 0;
		}

		uint32_t got = frames < avail ? frames : avail;
		uint32_t r = m_r.load(std::memory_order_relaxed);
		// Master volume: ramp from the previous gain to the new one across this buffer (no clicks when the slider moves).
		const float g0 = m_gain;
		const float g1 = float(g_akVolumePercent.load(std::memory_order_relaxed)) / 100.0f;
		const float dg = (g1 - g0) / float(frames);
		const bool useGain = (g0 != 1.0f) || (g1 != 1.0f);
		m_gain = g1;
		for(uint32_t i = 0; i < got; i++)
		{
			size_t o = size_t((r + i) & m_mask) * 2;
			int32_t l = m_buf[o], rr = m_buf[o + 1];
			if(m_fadeIn < FADE_FRAMES)
			{
				l = l * int32_t(m_fadeIn) / int32_t(FADE_FRAMES);
				rr = rr * int32_t(m_fadeIn) / int32_t(FADE_FRAMES);
				m_fadeIn++;
			}
			if(useGain)
			{
				float g = g0 + dg * float(i + 1);
				l = Clamp16(int32_t(float(l) * g));
				rr = Clamp16(int32_t(float(rr) * g));
			}
			out[i * 2] = int16_t(l);
			out[i * 2 + 1] = int16_t(rr);
		}
		m_r.store(r + got, std::memory_order_release);

		if(got > 0)
		{
			m_lastL = out[(got - 1) * 2];
			m_lastR = out[(got - 1) * 2 + 1];
		}
		if(got < frames)
		{
			// Underrun: fade the last sample to zero, then wait for the pre-buffer to refill.
			uint32_t n = frames - got;
			for(uint32_t i = 0; i < n; i++)
			{
				float g = 1.0f - float(i + 1) / float(n);
				out[(got + i) * 2] = int16_t(float(m_lastL) * g);
				out[(got + i) * 2 + 1] = int16_t(float(m_lastR) * g);
			}
			m_lastL = m_lastR = 0;
			m_starved = true;
			m_underruns.fetch_add(1, std::memory_order_relaxed);
		}
	}

	uint32_t Fill() const { return m_w.load(std::memory_order_acquire) - m_r.load(std::memory_order_acquire); }
	uint32_t Underruns() const { return m_underruns.load(std::memory_order_relaxed); }
	uint32_t Overflows() const { return m_overflows.load(std::memory_order_relaxed); }

private:
	static int32_t Clamp16(int32_t v) { return v > 32767 ? 32767 : (v < -32768 ? -32768 : v); }

	static constexpr uint32_t FADE_FRAMES = 128;
	static constexpr uint32_t MARGIN_FRAMES = 1764; // 40 ms of safety on top of one burst

	uint32_t m_cap, m_mask, m_target;
	std::vector<int16_t> m_buf;
	std::atomic<uint32_t> m_w{0}, m_r{0};
	std::atomic<bool> m_clear{false};
	std::atomic<uint32_t> m_burst{0};
	std::atomic<uint32_t> m_underruns{0}, m_overflows{0};

	// consumer-only state
	bool m_starved = true;
	uint32_t m_fadeIn = 0;
	float m_gain = 1.0f;
	int16_t m_lastL = 0, m_lastR = 0;
};

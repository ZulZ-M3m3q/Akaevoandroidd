#pragma once

#include "sound/SoundHandler.h"
#include "AkAudioPipe.h"
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>

// AkaiserEvodroid A.15: replacement for Play!'s CSH_OpenSL. Same interface; the emulator's sample
// buffer is copied into a private ring and the device is fed from it by the OpenSL callback.
class CSH_OpenSL : public CSoundHandler
{
public:
	CSH_OpenSL();
	virtual ~CSH_OpenSL();

	static CSoundHandler* HandlerFactory();

	void Reset() override;
	void Write(int16*, unsigned int, unsigned int) override;
	bool HasFreeBuffers() override;
	void RecycleBuffers() override;

private:
	enum
	{
		BUFFER_COUNT = 4,
		FRAMES_PER_BUFFER = 441, // 10 ms at 44.1 kHz
	};

	void CreateOutputMix();
	void CreateAudioPlayer();
	void FillAndEnqueue(int index);

	static void QueueCallback(SLAndroidSimpleBufferQueueItf, void*);
	void QueueCallbackImpl();

	SLObjectItf m_engineObject = nullptr;
	SLEngineItf m_engine = nullptr;

	SLObjectItf m_outputMixObject = nullptr;

	SLObjectItf m_playerObject = nullptr;
	SLPlayItf m_playerPlay = nullptr;
	SLAndroidSimpleBufferQueueItf m_playerQueue = nullptr;

	AkAudioPipe m_pipe;
	int16_t m_buffers[BUFFER_COUNT][FRAMES_PER_BUFFER * 2] = {};
	int m_nextBuffer = 0;
	uint32_t m_lastReportedUnderruns = 0;
	uint32_t m_lastReportedOverflows = 0;
};

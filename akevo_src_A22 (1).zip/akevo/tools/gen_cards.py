#!/usr/bin/env python3
"""Turns akevo/data/cards.tsv into overlay/akevo/AkCardData.java. Run after editing the TSV:  python3 akevo/tools/gen_cards.py"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
tsv = os.path.join(ROOT, "data", "cards.tsv"); out = os.path.join(ROOT, "overlay", "akevo", "AkCardData.java")
def jstr(s): return '"' + s.replace("\\", "\\\\").replace('"', '\\"').replace("\t", "\\t") + '"'
rows = [l.rstrip("\n") for l in open(tsv, encoding="utf-8") if l.strip() and not l.startswith("#")]
seen = set()
for r in rows:
    p = r.split("\t")
    if p[0] not in ("animal", "strong", "miracle") or len(p) < 9: sys.exit("bad row: " + r)
    if p[1] in seen: sys.exit("duplicate barcode: " + p[1])
    seen.add(p[1])
src = ("package com.virtualapplications.play.akevo;\n\n/** Generated from akevo/data/cards.tsv by akevo/tools/gen_cards.py - do not edit by hand. */\nfinal class AkCardData {\n"
       "    static final String[] ROWS = {\n" + ",\n".join("        " + jstr(r) for r in rows) + "\n    };\n}\n")
open(out, "w", encoding="utf-8").write(src)
print("wrote", out, len(rows), "cards")

#!/usr/bin/env python3
"""Turns akevo/data/cards.tsv into the website's card list (web/src/cards.mjs).
Usage:  python3 akevo/tools/gen_web_cards.py <path to the web folder>/src/cards.mjs
Run it whenever cards.tsv changes (together with gen_cards.py) and redeploy the website."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
tsv = os.path.join(ROOT, "data", "cards.tsv")
if len(sys.argv) != 2: sys.exit(__doc__)
out = sys.argv[1]
M = "·"
def stats(kind, f):
    f = f + [""] * 6
    if kind == "animal": return f"STR {f[0]} {M} HP {f[1]} {M} {f[2]} {M} {f[3]}"
    if kind == "strong": return f"Guts {f[0]} {M} Tech {f[1]} {M} Power {f[2]} {M} Aura: {f[3]} ({f[4]}) {M} {f[5]}"
    return f"Power {f[0]} {M} {f[1]} {M} {f[2]} {M} STAR% {f[3]} {M} {f[4]}"
cards, seen = [], set()
for l in open(tsv, encoding="utf-8"):
    l = l.rstrip("\n")
    if not l.strip() or l.startswith("#"): continue
    p = l.split("\t")
    if p[0] not in ("animal", "strong", "miracle") or len(p) < 9: sys.exit("bad row: " + l)
    if p[1] in seen: sys.exit("duplicate barcode: " + p[1])
    seen.add(p[1])
    cards.append({"id": p[1], "kind": p[0], "name": p[2], "rarity": p[3], "game": p[4], "stats": stats(p[0], p[5:])})
body = ("// Generated from akevo/data/cards.tsv by akevo/tools/gen_web_cards.py - do not edit by hand.\n"
        "// id = the card's barcode text exactly as the app uses it (case-sensitive).\n"
        "export const CARDS = " + json.dumps(cards, ensure_ascii=False, indent=0).replace("\n", "") + ";\n")
open(out, "w", encoding="utf-8").write(body)
print("wrote", out, len(cards), "cards")

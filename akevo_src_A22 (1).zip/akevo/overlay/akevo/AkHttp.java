package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.widget.Toast;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Talks to Play!'s built-in "Arcade I/O HTTP server" (same phone). Uses plain sockets so Android's cleartext-HTTP rules cannot block it. */
public final class AkHttp {
    public interface Result { void done(boolean ok, String message); }

    public static void send(final Activity a, final String code, final Result cb) {
        run(a, "POST", AkConfig.path(a).replace("{code}", code), AkConfig.bodyTemplate(a).replace("{code}", code), "Card sent: " + code, "Card NOT sent", cb);
    }

    public static void test(final Activity a, final Result cb) {
        run(a, "GET", "/ping", "", "Card server found", "Card server NOT found", cb);
    }

    private static List<String> candidates(Activity a) {
        List<String> l = new ArrayList<String>();
        l.add(AkConfig.host(a)); l.add("127.0.0.1"); l.add("localhost");
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces()))
                for (InetAddress ia : Collections.list(ni.getInetAddresses()))
                    if (ia instanceof Inet4Address && !ia.isLoopbackAddress()) l.add(ia.getHostAddress());
        } catch (Throwable ignored) { }
        List<String> out = new ArrayList<String>();
        for (String h : l) if (h != null && h.length() > 0 && !out.contains(h)) out.add(h);
        return out;
    }

    private static void run(final Activity a, final String method, final String path, final String body, final String okTitle, final String failTitle, final Result cb) {
        new Thread(new Runnable() { public void run() {
            boolean ok = false; StringBuilder msg = new StringBuilder(); StringBuilder errs = new StringBuilder();
            int port = AkConfig.port(a);
            for (String host : candidates(a)) {
                try {
                    Socket s = new Socket();
                    try {
                        s.connect(new InetSocketAddress(host, port), 1500); s.setSoTimeout(2500);
                        byte[] b = body.getBytes("UTF-8");
                        String req = method + " " + path + " HTTP/1.1\r\nHost: " + host + ":" + port + "\r\nContent-Type: text/plain\r\nContent-Length: " + b.length + "\r\nConnection: close\r\n\r\n";
                        OutputStream os = s.getOutputStream(); os.write(req.getBytes("UTF-8")); os.write(b); os.flush();
                        String first = "(no reply, request was sent)";
                        try {
                            InputStream is = s.getInputStream(); StringBuilder line = new StringBuilder(); int c;
                            while ((c = is.read()) >= 0 && c != '\n' && line.length() < 120) if (c != '\r') line.append((char) c);
                            if (line.length() > 0) first = line.toString();
                        } catch (Exception ignored) { }
                        ok = true; msg.append(host).append(':').append(port).append("  ").append(first);
                    } finally { try { s.close(); } catch (Exception ignored) { } }
                    break;
                } catch (Exception e) {
                    errs.append(host).append(':').append(port).append(" -> ").append(e.getClass().getSimpleName()).append(e.getMessage() == null ? "" : " (" + e.getMessage() + ")").append('\n');
                }
            }
            if (!ok) {
                msg.append(errs);
                if (!AkConfig.ioEnabled(a)) msg.append("The card server is switched OFF in settings. Turn it on, then restart the game.\n");
                else msg.append("Start the game first (the card server only runs while the game is running). If it still fails, restart the game after checking Settings > Card server.");
            }
            final boolean fok = ok; final String fmsg = msg.toString().trim();
            a.runOnUiThread(new Runnable() { public void run() {
                Toast.makeText(a, (fok ? okTitle : failTitle) + "\n" + fmsg, Toast.LENGTH_LONG).show();
                if (cb != null) cb.done(fok, fmsg);
            }});
        }}).start();
    }

    /** Last part of the emulator's own card-server log, if it exists. */
    public static String serverLog(Activity a) {
        try {
            File found = find(a.getFilesDir(), "arcade_io_server.log", 4);
            if (found == null) return "No arcade_io_server.log found yet. It appears after the game has started with the card server switched on.";
            java.io.RandomAccessFile f = new java.io.RandomAccessFile(found, "r");
            long len = f.length(); int n = (int) Math.min(len, 2000); byte[] b = new byte[n]; f.seek(len - n); f.readFully(b); f.close();
            String t = new String(b, "UTF-8").trim();
            return t.length() == 0 ? "(log file is empty)" : t;
        } catch (Throwable t) { return "Could not read the log: " + t; }
    }

    private static File find(File dir, String name, int depth) {
        if (dir == null || depth < 0) return null;
        File[] l = dir.listFiles(); if (l == null) return null;
        for (File f : l) if (f.isFile() && f.getName().equals(name)) return f;
        for (File f : l) if (f.isDirectory()) { File r = find(f, name, depth - 1); if (r != null) return r; }
        return null;
    }
}

package com.virtualapplications.play.akevo;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

/**
 * A.20 play time. One session = from the moment the game screen opens until it is closed.
 * Time while the app is in the background (home button, another app) is NOT counted.
 *
 * Safe against the app being killed: the running session is saved every 30 s (keys "dev_pt_*", which are never part of the
 * cloud backup). If the process dies, the saved session is finished the next time the app starts.
 * Finished sessions wait in a queue and are sent to the account site (POST /api/device/playtime) whenever the phone is
 * online and linked. Every session has an id, so the site never counts one twice.
 */
public final class AkPlayTime {
    private static final String K_CUR = "dev_pt_cur", K_QUEUE = "dev_pt_queue";
    private static final long BEAT_MS = 30000;      // how often the running session is saved
    private static final long MIN_MS = 5000;        // shorter sessions (game failed to start, accidental open) are ignored
    private static final int QUEUE_MAX = 300;       // oldest sessions are dropped beyond this (only if the site was unreachable for ages)
    private static final int BATCH = 50;            // the site accepts at most 50 per request
    private static final Handler UI = new Handler(Looper.getMainLooper());

    // the running session (main thread)
    private static boolean active = false;
    private static String id = "", game = "";
    private static long startWall = 0, accumMs = 0, resumedAt = 0;   // resumedAt: SystemClock.elapsedRealtime() while the screen is in front, else 0
    private static String nextGame = "";
    private static boolean flushing = false;

    private static SharedPreferences sp(Context c) { return AkConfig.sp(c); }

    /** AkArcade.boot tells us which game is starting ("akaievo8" from ".../akaievo8.arcadedef"). */
    public static void setGame(String defPath) {
        try {
            String n = defPath == null ? "" : defPath.substring(defPath.lastIndexOf('/') + 1);
            if (n.endsWith(".arcadedef")) n = n.substring(0, n.length() - 10);
            nextGame = n;
        } catch (Throwable ignored) { }
    }

    private static String newId() {
        byte[] b = new byte[8]; new SecureRandom().nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < b.length; i++) sb.append(String.format("%02x", b[i] & 0xff));
        return sb.toString();
    }

    private static long totalMs() { return accumMs + (resumedAt != 0 ? SystemClock.elapsedRealtime() - resumedAt : 0); }

    private static void save(Context c, boolean commit) {
        try {
            JSONObject o = new JSONObject().put("id", id).put("game", game).put("start", startWall).put("ms", totalMs());
            SharedPreferences.Editor e = sp(c).edit().putString(K_CUR, o.toString());
            if (commit) e.commit(); else e.apply();
        } catch (Throwable ignored) { }
    }

    private static final Runnable BEAT = new Runnable() { public void run() {
        if (!active || resumedAt == 0 || beatCtx == null) return;
        save(beatCtx, false);
        UI.postDelayed(this, BEAT_MS);
    } };
    private static Context beatCtx;

    // ------------------------------------------------------------------ called from AkOverlay (main thread)
    /** The game screen was created = the game was launched. */
    public static void start(Context c0) {
        Context c = c0.getApplicationContext();
        if (active) return;                              // the screen was re-created (rotation etc.): same session
        finishStored(c);                                 // a session left over from a killed app
        active = true; id = newId(); startWall = System.currentTimeMillis(); accumMs = 0; resumedAt = SystemClock.elapsedRealtime();
        game = nextGame.length() > 0 ? nextGame : AkConfig.launchVersion(c);
        beatCtx = c; save(c, true);
        UI.removeCallbacks(BEAT); UI.postDelayed(BEAT, BEAT_MS);
    }

    /** The game screen came to the front. */
    public static void resume(Context c0) {
        if (!active) { start(c0); return; }
        if (resumedAt == 0) resumedAt = SystemClock.elapsedRealtime();
        beatCtx = c0.getApplicationContext(); save(beatCtx, false);
        UI.removeCallbacks(BEAT); UI.postDelayed(BEAT, BEAT_MS);
    }

    /** The game screen left the front (home button, another app, screen off). The clock stops. */
    public static void pause(Context c0) {
        if (!active) return;
        if (resumedAt != 0) { accumMs += SystemClock.elapsedRealtime() - resumedAt; resumedAt = 0; }
        UI.removeCallbacks(BEAT);
        save(c0.getApplicationContext(), true);
    }

    /** The game was closed: the session is finished and queued for upload. */
    public static void end(Context c0) {
        if (!active) return;
        Context c = c0.getApplicationContext();
        long ms = totalMs(); String fid = id, fgame = game; long fstart = startWall;
        active = false; resumedAt = 0; accumMs = 0; UI.removeCallbacks(BEAT);
        sp(c).edit().remove(K_CUR).commit();
        enqueue(c, fid, fgame, fstart, ms);
        flush(c);
    }

    // ------------------------------------------------------------------ recovery + upload
    /** Called when the app starts (MainActivity): finishes a session that a killed app left behind, then uploads what is waiting. */
    public static void recoverAndFlush(Context c0) {
        Context c = c0.getApplicationContext();
        if (!active) finishStored(c);
        flush(c);
    }

    private static void finishStored(Context c) {
        String s = sp(c).getString(K_CUR, "");
        if (s.length() == 0) return;
        try {
            JSONObject o = new JSONObject(s);
            enqueue(c, o.getString("id"), o.optString("game", ""), o.optLong("start", 0), o.optLong("ms", 0));
        } catch (Throwable ignored) { }
        sp(c).edit().remove(K_CUR).commit();
    }

    private static synchronized void enqueue(Context c, String sid, String sgame, long start, long ms) {
        if (ms < MIN_MS || start <= 0) return;
        try {
            JSONArray q = readQueue(c);
            q.put(new JSONObject().put("id", sid).put("game", sgame).put("startedAt", start).put("seconds", Math.max(1, Math.round(ms / 1000.0))));
            while (q.length() > QUEUE_MAX) q.remove(0);
            sp(c).edit().putString(K_QUEUE, q.toString()).commit();
        } catch (Throwable ignored) { }
    }

    private static JSONArray readQueue(Context c) {
        try { return new JSONArray(sp(c).getString(K_QUEUE, "[]")); } catch (Throwable t) { return new JSONArray(); }
    }

    /** Sessions waiting for upload (for the settings screen). */
    public static synchronized int pending(Context c) { return readQueue(c.getApplicationContext()).length(); }

    /** Sends the waiting sessions in the background. Stays queued (and is retried next time) when offline, not linked, or the site errs. */
    public static void flush(Context c0) {
        final Context c = c0.getApplicationContext();
        synchronized (AkPlayTime.class) { if (flushing || readQueue(c).length() == 0) return; flushing = true; }
        new Thread(new Runnable() { public void run() {
            try {
                for (int round = 0; round < 8; round++) {
                    JSONArray batch = new JSONArray(); final Set<String> ids = new HashSet<String>();
                    synchronized (AkPlayTime.class) {
                        JSONArray q = readQueue(c);
                        for (int i = 0; i < q.length() && i < BATCH; i++) { batch.put(q.get(i)); ids.add(q.getJSONObject(i).getString("id")); }
                    }
                    if (batch.length() == 0) break;
                    int code = AkLink.postPlaytime(c, new JSONObject().put("sessions", batch).toString());
                    if (code == 200 || code == 400 || code == 413) removeIds(c, ids);   // 400/413: the site will never take these, do not retry forever
                    else break;                                                         // offline (-1), not linked (-2/403), 429, 5xx ...: try again later
                }
            } catch (Throwable ignored) {
            } finally { synchronized (AkPlayTime.class) { flushing = false; } }
        } }).start();
    }

    private static synchronized void removeIds(Context c, Set<String> ids) {
        try {
            JSONArray q = readQueue(c), keep = new JSONArray();
            for (int i = 0; i < q.length(); i++) if (!ids.contains(q.getJSONObject(i).optString("id"))) keep.put(q.get(i));
            sp(c).edit().putString(K_QUEUE, keep.toString()).commit();
        } catch (Throwable ignored) { }
    }
}

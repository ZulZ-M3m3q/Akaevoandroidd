package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.os.Process;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Small, safe performance helpers for the game screen (no emulator internals are touched). */
public final class AkPerf {
    private static final String TAG = "AkPerf";
    private static Activity boostedFor = null;

    private static native int nativePinThread(int tid, long mask);

    public static void boost(final Activity a) {
        if (a == boostedFor) return;            // once per game screen
        boostedFor = a;
        final boolean prio = AkConfig.perfBoost(a), pin = AkConfig.pinBig(a);
        if (prio) {
            // Steady 60 Hz screen: avoids uneven frame pacing on 90/120 Hz phones and saves heat.
            try {
                Window w = a.getWindow(); WindowManager.LayoutParams lp = w.getAttributes();
                lp.preferredRefreshRate = 60f; w.setAttributes(lp);
                w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } catch (Throwable ignored) { }
        }
        if (!prio && !pin) return;
        new Thread(new Runnable() { public void run() {
            try { Thread.sleep(2500); } catch (InterruptedException ignored) { }
            if (prio) boostThreads();
            if (pin) pinBusiestThreads();
        } }).start();
    }

    // ------------------------------------------------------------------ priority
    private static void boostThreads() {
        try {
            File[] tasks = new File("/proc/self/task").listFiles();
            if (tasks == null) return;
            int main = Process.myPid();
            for (File f : tasks) {
                try {
                    int tid = Integer.parseInt(f.getName());
                    if (tid == main) continue;
                    if (Process.getThreadPriority(tid) >= 0) Process.setThreadPriority(tid, Process.THREAD_PRIORITY_URGENT_DISPLAY);
                } catch (Throwable ignored) { }
            }
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ pin the busiest threads to the fastest cores
    private static int rank(int part) {
        switch (part) {
            case 0xd03: return 10; case 0xd04: return 9; case 0xd05: return 12; case 0xd46: return 14; case 0xd80: return 15;   // little: A53 A35 A55 A510 A520
            case 0xd07: return 30; case 0xd08: return 32; case 0xd09: return 34; case 0xd0a: return 36; case 0xd0b: return 40;    // big: A57 A72 A73 A75 A76
            case 0xd0d: return 44; case 0xd41: return 48; case 0xd47: return 50; case 0xd4d: return 52; case 0xd81: return 54;    // A77 A78 A710 A715 A720
            case 0xd44: return 60; case 0xd48: return 62; case 0xd4e: return 64; case 0xd82: return 66;                          // X1 X2 X3 X4
            default: return 20;
        }
    }

    /** Bit mask of the fastest CPU cores, or 0 when the phone has only one kind of core. */
    private static long bigCoreMask() {
        try {
            Map<Integer, Integer> part = new HashMap<Integer, Integer>(); int cpu = -1;
            BufferedReader r = new BufferedReader(new FileReader("/proc/cpuinfo")); String line;
            while ((line = r.readLine()) != null) {
                line = line.trim(); int c = line.indexOf(':'); if (c < 0) continue;
                if (line.startsWith("processor")) cpu = Integer.parseInt(line.substring(c + 1).trim());
                else if (line.startsWith("CPU part") && cpu >= 0) part.put(cpu, Integer.decode(line.substring(c + 1).trim()));
            }
            r.close();
            int best = -1, worst = 1000;
            for (int p : part.values()) { int k = rank(p); if (k > best) best = k; if (k < worst) worst = k; }
            if (best == worst) return 0;
            long mask = 0;
            for (Map.Entry<Integer, Integer> e : part.entrySet()) if (rank(e.getValue()) == best && e.getKey() < 63) mask |= 1L << e.getKey();
            return mask;
        } catch (Throwable t) { return 0; }
    }

    private static Map<Integer, Long> cpuTicks() {
        Map<Integer, Long> m = new HashMap<Integer, Long>();
        File[] tasks = new File("/proc/self/task").listFiles(); if (tasks == null) return m;
        for (File f : tasks) {
            try {
                int tid = Integer.parseInt(f.getName());
                BufferedReader r = new BufferedReader(new FileReader(new File(f, "stat"))); String s = r.readLine(); r.close();
                String[] x = s.substring(s.lastIndexOf(')') + 2).split(" ");      // fields after the thread name
                m.put(tid, Long.parseLong(x[11]) + Long.parseLong(x[12]));       // user + system time
            } catch (Throwable ignored) { }
        }
        return m;
    }

    private static void pinBusiestThreads() {
        try {
            long mask = bigCoreMask();
            if (mask == 0) { Log.i(TAG, "pin: no big/little split, nothing to do"); return; }
            try { Thread.sleep(4000); } catch (InterruptedException ignored) { }         // let the game settle
            Map<Integer, Long> t0 = cpuTicks(); try { Thread.sleep(3000); } catch (InterruptedException ignored) { } Map<Integer, Long> t1 = cpuTicks();
            List<int[]> busy = new ArrayList<int[]>();
            for (Map.Entry<Integer, Long> e : t1.entrySet()) {
                Long a = t0.get(e.getKey()); if (a == null) continue;
                long d = e.getValue() - a; if (d >= 60) busy.add(new int[]{e.getKey(), (int) d});   // >= ~20% of a core
            }
            java.util.Collections.sort(busy, new java.util.Comparator<int[]>() { public int compare(int[] p, int[] q) { return q[1] - p[1]; } });
            int n = Math.min(2, busy.size());
            for (int i = 0; i < n; i++) {
                int rc = nativePinThread(busy.get(i)[0], mask);
                Log.i(TAG, "pinned thread " + busy.get(i)[0] + " (" + busy.get(i)[1] + " ticks) to mask 0x" + Long.toHexString(mask) + " rc=" + rc);
            }
        } catch (Throwable t) { Log.w(TAG, "pin failed", t); }
    }
}

package com.virtualapplications.play.akevo;

import android.content.Context;
import android.util.Log;

/** Master game volume (0..150 %, 100 = unchanged). The gain is applied inside the emulator's audio pipe (SH_OpenSL.cpp). */
public final class AkAudio {
    private static final String TAG = "AkAudio";
    public static final int MIN = 0, MAX = 150;

    private static native void nativeSetVolume(int percent);

    public static int clamp(int p) { return Math.max(MIN, Math.min(MAX, p)); }

    /** Set + remember the volume. */
    public static void set(Context c, int percent) {
        percent = clamp(percent);
        AkConfig.put(c, "volume", percent);
        push(percent);
    }

    /** Send the saved volume to the native audio code (call when a game starts). */
    public static void apply(Context c) { push(AkConfig.volume(c)); }

    private static void push(int percent) {
        try { nativeSetVolume(percent); } catch (Throwable t) { Log.w(TAG, "nativeSetVolume failed", t); }
    }
}

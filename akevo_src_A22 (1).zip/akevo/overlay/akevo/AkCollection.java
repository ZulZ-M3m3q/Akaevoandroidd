package com.virtualapplications.play.akevo;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * A.21: the player's card collection. A card is added when its barcode is scanned (camera or typed) and it is in the card list.
 * Stored in the app settings under "ak_collection" as {"barcode":[firstScannedMillis,timesScanned], ...}, so it is part of the
 * account cloud backup and comes back with Restore (restore merges, it never removes cards).
 */
public final class AkCollection {
    public static final String KEY = "ak_collection";
    private AkCollection() { }

    private static JSONObject read(Context c) {
        try { return new JSONObject(AkConfig.sp(c).getString(KEY, "{}")); } catch (Throwable t) { return new JSONObject(); }
    }

    /** Adds the scanned barcode when it is a known card. Returns that card, or null when the barcode is not in the list. */
    public static synchronized AkCards.Card add(Context c, String barcode) {
        AkCards.Card card = AkCards.byCode(barcode);
        if (card == null) return null;
        try {
            JSONObject o = read(c); JSONArray a = o.optJSONArray(card.code);
            long first = a != null ? a.optLong(0, System.currentTimeMillis()) : System.currentTimeMillis();
            long n = a != null ? a.optLong(1, 0) : 0;
            o.put(card.code, new JSONArray().put(first).put(n + 1));
            AkConfig.sp(c).edit().putString(KEY, o.toString()).commit();
        } catch (Throwable ignored) { }
        sync(c, null);                                  // A.22: send the new card to the website (does nothing when not linked / offline)
        return card;
    }

    /** barcode -> {firstScanned, timesScanned} for every card owned. */
    public static synchronized Map<String, long[]> snapshot(Context c) {
        Map<String, long[]> m = new HashMap<String, long[]>();
        JSONObject o = read(c); Iterator<String> it = o.keys();
        while (it.hasNext()) {
            String k = it.next(); JSONArray a = o.optJSONArray(k);
            if (a != null && AkCards.byCode(k) != null) m.put(k, new long[]{a.optLong(0, 0), Math.max(1, a.optLong(1, 1))});
        }
        return m;
    }

    public static int owned(Context c, String kind) {
        int n = 0; Map<String, long[]> m = snapshot(c);
        for (AkCards.Card k : AkCards.ofKind(kind)) if (m.containsKey(k.code)) n++;
        return n;
    }

    /** Used by the cloud restore: keeps every local card and adds the saved ones (earliest date, highest count). */
    public static synchronized void mergeFromBackup(Context c, String remoteJson) {
        try {
            JSONObject mine = read(c), theirs = new JSONObject(remoteJson); Iterator<String> it = theirs.keys();
            while (it.hasNext()) {
                String k = it.next(); JSONArray b = theirs.optJSONArray(k); if (b == null) continue;
                JSONArray a = mine.optJSONArray(k);
                if (a == null) mine.put(k, b);
                else mine.put(k, new JSONArray().put(Math.min(a.optLong(0), b.optLong(0))).put(Math.max(a.optLong(1), b.optLong(1))));
            }
            AkConfig.sp(c).edit().putString(KEY, mine.toString()).commit();
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ A.22: sync with the account website
    /** Called (on the UI thread) after a sync brought cards from the website that this phone did not have. */
    public interface Changed { void run(); }
    private static boolean syncing = false, syncAgain = false;

    /**
     * Sends the collection to the website and merges what comes back (cards from the website's daily gacha). Runs in the background.
     * Does nothing when the phone is not linked or the build has no website. Offline: nothing is lost, the whole collection is
     * sent again at the next sync (app start, new card, opening My cards, linking).
     */
    public static void sync(Context c0, final Changed changed) {
        final Context c = c0.getApplicationContext();
        if (!AkLink.configured(c) || !AkLink.linkedCached(c)) return;
        synchronized (AkCollection.class) { if (syncing) { syncAgain = true; return; } syncing = true; }
        new Thread(new Runnable() { public void run() {
            boolean differs = false;
            try {
                while (true) {
                    String before;
                    synchronized (AkCollection.class) { syncAgain = false; before = read(c).toString(); }
                    String reply = AkLink.postCollection(c, new JSONObject().put("cards", new JSONObject(before)).toString());
                    if (reply != null) { mergeFromWeb(c, reply); synchronized (AkCollection.class) { if (!read(c).toString().equals(before)) differs = true; } }
                    synchronized (AkCollection.class) { if (!syncAgain) { syncing = false; break; } }
                }
            } catch (Throwable t) { synchronized (AkCollection.class) { syncing = false; } }
            if (differs && changed != null) new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() { public void run() { changed.run(); } });
        } }).start();
    }

    /** The website answered {"cards":{"<barcode>":firstOwnedMillis,...}}: add the ones we do not have. Never removes anything. */
    private static void mergeFromWeb(Context c, String body) {
        try {
            JSONObject cards = new JSONObject(body).optJSONObject("cards"); if (cards == null) return;
            JSONObject remote = new JSONObject(); Iterator<String> it = cards.keys();
            while (it.hasNext()) {
                String k = it.next(); AkCards.Card card = AkCards.byCode(k);
                if (card == null || !card.code.equals(k)) continue;
                long first = cards.optLong(k, 0); if (first <= 0) first = System.currentTimeMillis();
                remote.put(k, new JSONArray().put(first).put(1));
            }
            mergeFromBackup(c, remote.toString());
        } catch (Throwable ignored) { }
    }
}

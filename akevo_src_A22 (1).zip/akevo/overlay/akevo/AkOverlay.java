package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.ViewGroup;

/** Hooked into Play!'s EmulatorActivity.onCreate by apply_patches.py. */
public final class AkOverlay {
    private static AkPadView pad;
    private static Activity emu;
    private static boolean registered = false;

    public static void attach(final Activity a) {
        emu = a; pad = null;
        AkPlayTime.start(a);                       // A.20: play time starts when the game is launched
        AkAudio.apply(a);
        try { a.setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC); } catch (Throwable ignored) { }   // phone volume keys control the game sound
        hidePs2Pad(a);
        a.getWindow().getDecorView().post(new Runnable() { public void run() {
            try {
                pad = new AkPadView(a);
                a.addContentView(pad, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            } catch (Throwable t) { pad = null; }
        }});
        if (!registered) {
            registered = true;
            a.getApplication().registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                public void onActivityResumed(Activity x) {
                    if (x == emu) { hidePs2Pad(x); AkPerf.boost(x); AkAudio.apply(x); }
                    if (x == emu) AkPlayTime.resume(x);
                    if (x == emu && pad != null) {
                        pad.reload();
                        if (AkConfig.editRequested) { AkConfig.editRequested = false; pad.setEdit(true); }
                    }
                }
                public void onActivityPaused(Activity x) {
                    if (x == emu) {
                        AkInput.releaseAll(x);
                        AkPlayTime.pause(x);
                        if (x.isFinishing()) AkPlayTime.end(x);          // closed with the back button: the app may exit right after, so finish the session now
                    }
                }
                public void onActivityCreated(Activity x, Bundle b) { }
                public void onActivityStarted(Activity x) { }
                public void onActivityStopped(Activity x) { }
                public void onActivitySaveInstanceState(Activity x, Bundle b) { }
                public void onActivityDestroyed(Activity x) { if (x == emu) { if (x.isFinishing()) AkPlayTime.end(x); emu = null; pad = null; } }
            });
        }
    }

    /** Hides Play!'s built-in PS2 virtual pad (L1/R1/dpad/triangle/...): the arcade game only needs our buttons. */
    private static void hidePs2Pad(final Activity a) {
        a.getWindow().getDecorView().post(new Runnable() { public void run() {
            try {
                android.view.View v = a.findViewById(com.virtualapplications.play.R.id.emulator_virtualpad);
                if (v != null) v.setVisibility(android.view.View.GONE);
            } catch (Throwable ignored) { }
        }});
    }

    /** Used by settings/scan screens to send a card into the running game. */
    public static Activity emulatorActivity() { return emu; }
}

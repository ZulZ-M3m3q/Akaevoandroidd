package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.Handler;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.View;
import java.util.List;

/** Touch overlay: custom button layout, multitouch, TEST (hold "1") button, edit mode. */
public class AkPadView extends View {
    private final Activity act;
    private List<AkConfig.Btn> btns;
    private boolean[] down;
    private final SparseIntArray pointerBtn = new SparseIntArray();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private float scale = 1f; private int alpha = 180;
    private boolean edit = false; private int selected = -1;
    private boolean testLatched = false;
    private final Handler handler = new Handler();
    // In-game volume slider (opened with the VOL button, closes by itself after 3 s without touching it)
    private boolean volOpen = false; private int volPointer = -1; private int volPct = 100;
    private final Runnable volHide = new Runnable() { public void run() { volOpen = false; volPointer = -1; invalidate(); } };
    private static final String[] BAR = {"−", "+", "RESET", "SAVE"};

    public AkPadView(Activity a) {
        super(a); act = a; dp = a.getResources().getDisplayMetrics().density;
        txt.setTextAlign(Paint.Align.CENTER); txt.setColor(0xFFFFFFFF); txt.setFakeBoldText(true);
        line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(2 * dp);
        reload();
    }

    public void reload() {
        btns = AkConfig.activeLayout(act);
        down = new boolean[btns.size()];
        scale = AkConfig.scale(act) / 100f;
        volPct = AkConfig.volume(act);
        alpha = Math.max(25, AkConfig.opacity(act) * 255 / 100);
        setVisibility(AkConfig.overlayVisible(act) || edit ? VISIBLE : INVISIBLE);
        invalidate();
    }

    public void setEdit(boolean e) {
        if (e) { AkInput.releaseAll(act); testLatched = false; closeVol(); }
        edit = e; selected = -1; reload();
    }

    private float radius(AkConfig.Btn b) { return b.size * dp * scale / 2f; }

    private boolean testHeld() {
        if (testLatched) return true;
        for (int i = 0; i < btns.size(); i++) if ("TEST".equals(btns.get(i).id) && down[i]) return true;
        return false;
    }

    /** UP / DOWN / OK are service-menu buttons: hidden during play, shown while TEST is held or latched. */
    private boolean shown(AkConfig.Btn b) {
        if ("VOL".equals(b.id)) return edit || AkConfig.volVisible(act);
        if ("FF".equals(b.id)) return false;                                                      // fast forward was removed in A.16
        if ("COIN".equals(b.id) || "START".equals(b.id) || "SPEED".equals(b.id)) return false;   // removed buttons (also hides ones saved in older layouts)   // free play: coin / start are not needed
        if (!"UP".equals(b.id) && !"DOWN".equals(b.id) && !"OK".equals(b.id)) return true;
        return edit || AkConfig.showService(act) || testHeld();
    }

    private int hit(float x, float y) {
        for (int i = btns.size() - 1; i >= 0; i--) {
            AkConfig.Btn b = btns.get(i);
            if (!shown(b)) continue;
            float dx = x - b.x * getWidth(), dy = y - b.y * getHeight(), r = radius(b) * 1.15f;
            if (dx * dx + dy * dy <= r * r) return i;
        }
        return -1;
    }

    private RectF barRect(int i) {
        float w = 92 * dp, h = 44 * dp, gap = 8 * dp, total = BAR.length * w + (BAR.length - 1) * gap;
        float left = (getWidth() - total) / 2f + i * (w + gap), top = getHeight() - h - 12 * dp;
        return new RectF(left, top, left + w, top + h);
    }

    private int barHit(float x, float y) {
        if (!edit) return -1;
        for (int i = 0; i < BAR.length; i++) if (barRect(i).contains(x, y)) return i;
        return -1;
    }

    private void buzz() {
        if (!AkConfig.haptics(act)) return;
        try {
            Vibrator v = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null) return;
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(12, VibrationEffect.DEFAULT_AMPLITUDE));
            else v.vibrate(12);
        } catch (Throwable ignored) { }
    }

    private void press(int i, boolean isDown) {
        AkConfig.Btn b = btns.get(i);
        if (isDown) buzz();
        if ("SCAN".equals(b.id) || "SET".equals(b.id) || "BOX".equals(b.id)) {
            down[i] = isDown;
            if (!isDown) {
                Class<?> c = "SCAN".equals(b.id) ? AkScanActivity.class : "BOX".equals(b.id) ? AkCollectionActivity.class : AkSettingsActivity.class;
                act.startActivity(new Intent(act, c));
            }
            return;
        }
        if ("VOL".equals(b.id)) {     // tap = open / close the volume slider
            down[i] = isDown;
            if (!isDown) { if (volOpen) closeVol(); else openVol(); }
            return;
        }
        if ("TEST".equals(b.id) && AkConfig.latchTest(act)) {       // tap = hold, tap again = release
            if (isDown) { testLatched = !testLatched; down[i] = testLatched; AkInput.set(act, "TEST", testLatched); }
            return;
        }
        down[i] = isDown;
        AkInput.set(act, b.id, isDown);
    }

    // ---------- in-game volume slider ----------
    private RectF volRect() {
        float w = Math.min(getWidth() * 0.6f, 420 * dp), h = 64 * dp;
        float left = (getWidth() - w) / 2f, top = 12 * dp;
        return new RectF(left, top, left + w, top + h);
    }
    private void openVol() { volPct = AkConfig.volume(act); volOpen = true; bumpVol(); invalidate(); }
    private void closeVol() { handler.removeCallbacks(volHide); volOpen = false; volPointer = -1; invalidate(); }
    private void bumpVol() { handler.removeCallbacks(volHide); handler.postDelayed(volHide, 3000); }
    private void setVolFromX(float x) {
        RectF r = volRect(); float l = r.left + 18 * dp, rt = r.right - 18 * dp;
        float f = Math.max(0f, Math.min(1f, (x - l) / (rt - l)));
        int pct = Math.round(f * AkAudio.MAX);
        if (Math.abs(pct - 100) <= 3) pct = 100;                       // snaps to "normal"
        if (pct != volPct) { volPct = pct; AkAudio.set(act, pct); }
        bumpVol(); invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked(), idx = e.getActionIndex(), pid = e.getPointerId(idx);
        switch (a) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                float x = e.getX(idx), y = e.getY(idx);
                if (volOpen && !edit && volRect().contains(x, y)) { volPointer = pid; setVolFromX(x); return true; }
                int bar = barHit(x, y);
                if (bar >= 0) { barAction(bar); return true; }
                int h = hit(x, y);
                if (volOpen && !(h >= 0 && "VOL".equals(btns.get(h).id))) closeVol();   // touching anything else closes the slider
                if (h < 0) return a != MotionEvent.ACTION_DOWN ? true : false;   // let the emulator see other touches
                pointerBtn.put(pid, h);
                if (edit) { selected = h; invalidate(); } else { press(h, true); invalidate(); }
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (volPointer >= 0) {
                    for (int k = 0; k < e.getPointerCount(); k++) if (e.getPointerId(k) == volPointer) setVolFromX(e.getX(k));
                }
                if (edit && selected >= 0) {
                    for (int k = 0; k < e.getPointerCount(); k++) {
                        if (pointerBtn.get(e.getPointerId(k), -1) == selected) {
                            AkConfig.Btn b = btns.get(selected);
                            b.x = Math.max(0.02f, Math.min(0.98f, e.getX(k) / getWidth()));
                            b.y = Math.max(0.03f, Math.min(0.97f, e.getY(k) / getHeight()));
                            invalidate();
                        }
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (pid == volPointer) { volPointer = -1; return true; }
                int h = pointerBtn.get(pid, -1);
                pointerBtn.delete(pid);
                if (h >= 0 && !edit) {
                    if (a == MotionEvent.ACTION_CANCEL && ("SCAN".equals(btns.get(h).id) || "SET".equals(btns.get(h).id) || "BOX".equals(btns.get(h).id))) down[h] = false;
                    else press(h, false);
                    invalidate();
                }
                return true;
            }
        }
        return true;
    }

    private void barAction(int i) {
        if (i == 0 && selected >= 0) btns.get(selected).size = Math.max(28, btns.get(selected).size - 6);
        else if (i == 1 && selected >= 0) btns.get(selected).size = Math.min(140, btns.get(selected).size + 6);
        else if (i == 2) { String p = AkConfig.activeProfile(act); btns = AkConfig.defaultLayout("Left-handed".equals(p), AkConfig.twoPlayers(act)); down = new boolean[btns.size()]; selected = -1; }
        else if (i == 3) {
            String p = AkConfig.activeProfile(act);
            if ("Default".equals(p) || "Left-handed".equals(p)) { p = p + " (custom)"; AkConfig.setActiveProfile(act, p); }
            AkConfig.saveLayout(act, p, btns); setEdit(false); return;
        }
        invalidate();
    }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (edit) { fill.setColor(0x66000000); fill.setStyle(Paint.Style.FILL); c.drawRect(0, 0, w, h, fill); }
        for (int i = 0; i < btns.size(); i++) {
            AkConfig.Btn b = btns.get(i);
            if (!shown(b)) continue;
            float cx = b.x * w, cy = b.y * h, r = radius(b);
            boolean test = "TEST".equals(b.id);
            boolean green = "LEFT".equals(b.id) || "P2G".equals(b.id), yellow = "RIGHT".equals(b.id) || "P2Y".equals(b.id);
            int base = test ? 0xFFB5651D : green ? 0xFF2EA043 : yellow ? 0xFFF2B705 : ("OK".equals(b.id) ? 0xFF2E7D32 : 0xFF37474F);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(down[i] ? 0xFFFFFFFF : base); fill.setAlpha(down[i] ? Math.min(255, alpha + 60) : alpha);
            c.drawCircle(cx, cy, r, fill);
            line.setColor(edit && i == selected ? 0xFFFFEB3B : 0xFFFFFFFF); line.setAlpha(edit && i == selected ? 255 : alpha);
            c.drawCircle(cx, cy, r, line);
            txt.setColor(down[i] || yellow ? 0xFF000000 : 0xFFFFFFFF); txt.setAlpha(Math.min(255, alpha + 50));
            String lab = b.label;
            if ("VOL".equals(b.id)) { lab = volPct == 0 ? "VOL\nMUTE" : "VOL\n" + volPct; if (volPct == 0 && !down[i]) { fill.setColor(0xFFB71C1C); fill.setAlpha(alpha); c.drawCircle(cx, cy, r, fill); } }
            String[] parts = lab.split("\n");
            txt.setTextSize(Math.min(r * (parts.length > 1 ? 0.55f : 0.70f), 22 * dp));
            float lh = txt.getTextSize() * 1.05f, y0 = cy - (parts.length - 1) * lh / 2f + txt.getTextSize() * 0.35f;
            for (int k = 0; k < parts.length; k++) c.drawText(parts[k], cx, y0 + k * lh, txt);
            if (test && AkConfig.latchTest(act) && testLatched) { line.setColor(0xFFFFEB3B); line.setAlpha(255); c.drawCircle(cx, cy, r + 4 * dp, line); }
        }
        if (volOpen && !edit) drawVolPanel(c);
        if (edit) {
            for (int i = 0; i < BAR.length; i++) {
                RectF r = barRect(i);
                fill.setColor(0xFF263238); fill.setAlpha(240); c.drawRoundRect(r, 10 * dp, 10 * dp, fill);
                txt.setColor(0xFFFFFFFF); txt.setAlpha(255); txt.setTextSize(16 * dp);
                c.drawText(BAR[i], r.centerX(), r.centerY() + 6 * dp, txt);
            }
            txt.setTextSize(14 * dp); txt.setAlpha(255);
            c.drawText("EDIT: drag buttons · tap to select · − / + resize · SAVE", w / 2f, 28 * dp, txt);
        }
    }

    private void drawVolPanel(Canvas c) {
        RectF r = volRect();
        fill.setStyle(Paint.Style.FILL); fill.setColor(0xFF1B252B); fill.setAlpha(235);
        c.drawRoundRect(r, 14 * dp, 14 * dp, fill);
        txt.setColor(0xFFFFFFFF); txt.setAlpha(255); txt.setTextSize(15 * dp);
        c.drawText(volPct == 0 ? "Volume: MUTE" : "Volume: " + volPct + "%", r.centerX(), r.top + 24 * dp, txt);
        float l = r.left + 18 * dp, rt = r.right - 18 * dp, y = r.top + 46 * dp, f = volPct / (float) AkAudio.MAX;
        line.setStyle(Paint.Style.STROKE); line.setStrokeCap(Paint.Cap.ROUND); line.setStrokeWidth(6 * dp);
        line.setColor(0xFF607D8B); line.setAlpha(255); c.drawLine(l, y, rt, y, line);
        line.setColor(volPct > 100 ? 0xFFF2B705 : 0xFF2EA043); c.drawLine(l, y, l + (rt - l) * f, y, line);
        float tick = l + (rt - l) * (100f / AkAudio.MAX);                    // marks 100% (normal)
        line.setStrokeWidth(2 * dp); line.setColor(0xFFFFFFFF); c.drawLine(tick, y - 9 * dp, tick, y + 9 * dp, line);
        fill.setColor(0xFFFFFFFF); fill.setAlpha(255); c.drawCircle(l + (rt - l) * f, y, 10 * dp, fill);
        line.setStrokeCap(Paint.Cap.BUTT); line.setStrokeWidth(2 * dp);       // restore defaults used elsewhere
    }
}

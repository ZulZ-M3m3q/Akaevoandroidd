package com.virtualapplications.play.akevo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A.21: the card list (animal / strong / miracle cards) built from AkCardData, looked up by barcode text. */
public final class AkCards {
    public static final String ANIMAL = "animal", STRONG = "strong", MIRACLE = "miracle";

    public static final class Card {
        public final String kind, code, name, rarity, game;
        private final String[] f;     // the kind-specific columns
        Card(String[] p) {
            kind = p[0]; code = p[1]; name = p[2]; rarity = p[3]; game = p[4];
            f = new String[p.length - 5]; System.arraycopy(p, 5, f, 0, f.length);
        }
        private String v(int i) { return i < f.length ? f[i] : ""; }

        /** One short line with the card's numbers, e.g. "STR 7000 | HP 8000 | Guts | Heavy". */
        public String stats() {
            if (ANIMAL.equals(kind)) return "STR " + v(0) + "  \u00B7  HP " + v(1) + "  \u00B7  " + v(2) + "  \u00B7  " + v(3);
            if (STRONG.equals(kind)) return "Guts " + v(0) + "  \u00B7  Tech " + v(1) + "  \u00B7  Power " + v(2) + "  \u00B7  Aura: " + v(3) + " (" + v(4) + ")  \u00B7  " + v(5);
            return "Power " + v(0) + "  \u00B7  " + v(1) + "  \u00B7  " + v(2) + "  \u00B7  STAR% " + v(3) + "  \u00B7  " + v(4);
        }
        /** Longer text for the details window. */
        public String details() {
            return name + "\n" + rarity + "  \u00B7  playable from " + game + "\n\n" + stats() + "\n\nBarcode: " + code;
        }
    }

    private static final List<Card> ALL = new ArrayList<Card>();
    private static final Map<String, Card> BY_CODE = new HashMap<String, Card>();
    static {
        for (String row : AkCardData.ROWS) {
            String[] p = row.split("\t", -1);
            if (p.length < 9) continue;
            Card c = new Card(p); ALL.add(c); BY_CODE.put(c.code, c);
        }
    }

    public static List<Card> all() { return ALL; }

    public static List<Card> ofKind(String kind) {
        List<Card> l = new ArrayList<Card>();
        for (Card c : ALL) if (c.kind.equals(kind)) l.add(c);
        return l;
    }

    public static int total(String kind) { int n = 0; for (Card c : ALL) if (c.kind.equals(kind)) n++; return n; }

    /** The card for this barcode text, or null. Exact match first; a unique match that only differs in upper/lower case is accepted too. */
    public static Card byCode(String raw) {
        if (raw == null) return null;
        String s = raw.trim();
        Card c = BY_CODE.get(s);
        if (c != null) return c;
        Card hit = null;
        for (Card k : ALL) if (k.code.equalsIgnoreCase(s)) { if (hit != null) return null; hit = k; }
        return hit;
    }
}

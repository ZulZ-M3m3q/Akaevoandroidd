package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Toast;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.FileOutputStream;

/** Lets the user pick the NAND dump once; copies it into app storage where Play!'s arcade loader can read it. */
public class AkImportActivity extends Activity {
    private static final int REQ = 7001;
    private ProgressDialog pd;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        try { startActivityForResult(i, REQ); } catch (Exception e) { Toast.makeText(this, "No file picker available", Toast.LENGTH_LONG).show(); finish(); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ || res != RESULT_OK || data == null || data.getData() == null) { finish(); return; }
        copy(data.getData());
    }

    private long sizeOf(Uri u) {
        try (Cursor c = getContentResolver().query(u, null, null, null, null)) {
            if (c != null && c.moveToFirst()) { int i = c.getColumnIndex(OpenableColumns.SIZE); if (i >= 0 && !c.isNull(i)) return c.getLong(i); }
        } catch (Exception ignored) { }
        return -1;
    }

    private void copy(final Uri uri) {
        final long total = sizeOf(uri);
        final File dir = AkArcade.romDir(this); dir.mkdirs();
        if (total > 0 && dir.getUsableSpace() < total + 64L * 1024 * 1024) {
            new AlertDialog.Builder(this).setTitle("Not enough space")
                .setMessage("The file is " + (total / 1048576) + " MB but only " + (dir.getUsableSpace() / 1048576) + " MB is free. Free up space and try again.")
                .setPositiveButton(android.R.string.ok, (d, w) -> finish()).setOnCancelListener(d -> finish()).show();
            return;
        }
        pd = new ProgressDialog(this); pd.setTitle("Copying game file"); pd.setMessage("Please keep the app open...");
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL); pd.setMax(100); pd.setCancelable(false); pd.show();
        new Thread(() -> {
            String err = null;
            File tmp = new File(dir, AkArcade.NAND_NAME + ".part");
            try (InputStream in = getContentResolver().openInputStream(uri); OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[1 << 20]; long done = 0; int n, last = -1;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n); done += n;
                    if (total > 0) { final int pct = (int) (done * 100 / total); if (pct != last) { last = pct; runOnUiThread(() -> pd.setProgress(pct)); } }
                }
                out.flush();
                if (done < 1024 * 1024) throw new Exception("That file is too small to be the game file.");
                File dst = AkArcade.nandFile(this); if (dst.exists()) dst.delete();
                if (!tmp.renameTo(dst)) throw new Exception("Could not save the file.");
            } catch (Exception e) { err = e.getMessage() == null ? e.toString() : e.getMessage(); tmp.delete(); }
            final String fe = err;
            runOnUiThread(() -> {
                try { pd.dismiss(); } catch (Exception ignored) { }
                new AlertDialog.Builder(this).setTitle(fe == null ? "Done" : "Copy failed")
                    .setMessage(fe == null ? "Game file imported. Open Animal Kaiser Evolution from the list." : fe)
                    .setPositiveButton(android.R.string.ok, (d, w) -> finish()).setOnCancelListener(d -> finish()).show();
            });
        }).start();
    }
}

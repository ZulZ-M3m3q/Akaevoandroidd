package com.virtualapplications.play.akevo;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Camera barcode scanner: point at an Animal Kaiser card barcode, it is sent to the running game. */
public class AkScanActivity extends AppCompatActivity {
    private PreviewView preview;
    private TextView status;
    private ExecutorService exec;
    private BarcodeScanner scanner;
    private volatile boolean sent = false;
    private final java.util.HashSet<String> recorded = new java.util.HashSet<String>();   // A.21: a retry must not count the same scan twice

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout f = new FrameLayout(this);
        preview = new PreviewView(this); f.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        status = new TextView(this); status.setTextSize(18); status.setTextColor(0xFFFFFFFF); status.setBackgroundColor(0x99000000);
        status.setText("Point the camera at the card barcode…"); status.setPadding(24, 24, 24, 24);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM); f.addView(status, lp);
        setContentView(f);
        exec = Executors.newSingleThreadExecutor();
        scanner = BarcodeScanning.getClient();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start();
        else ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, 7);
    }

    @Override public void onRequestPermissionsResult(int rc, @NonNull String[] p, @NonNull int[] r) {
        super.onRequestPermissionsResult(rc, p, r);
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) start();
        else { Toast.makeText(this, "Camera permission is needed to scan cards", Toast.LENGTH_LONG).show(); finish(); }
    }

    private void start() {
        final ListenableFuture<ProcessCameraProvider> fut = ProcessCameraProvider.getInstance(this);
        fut.addListener(new Runnable() { public void run() {
            try {
                ProcessCameraProvider prov = fut.get();
                Preview pv = new Preview.Builder().build(); pv.setSurfaceProvider(preview.getSurfaceProvider());
                ImageAnalysis ia = new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build();
                ia.setAnalyzer(exec, new ImageAnalysis.Analyzer() {
                    @ExperimentalGetImage @Override public void analyze(@NonNull final ImageProxy proxy) {
                        if (sent || proxy.getImage() == null) { proxy.close(); return; }
                        InputImage img = InputImage.fromMediaImage(proxy.getImage(), proxy.getImageInfo().getRotationDegrees());
                        scanner.process(img).addOnSuccessListener(new com.google.android.gms.tasks.OnSuccessListener<List<Barcode>>() {
                            public void onSuccess(List<Barcode> codes) {
                                for (Barcode c : codes) {
                                    String v = c.getRawValue();
                                    if (v != null && v.length() > 0 && !sent) { sent = true; deliver(v.trim()); break; }
                                }
                            }
                        }).addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<List<Barcode>>() {
                            public void onComplete(@NonNull com.google.android.gms.tasks.Task<List<Barcode>> t) { proxy.close(); }
                        });
                    }
                });
                prov.unbindAll();
                prov.bindToLifecycle(AkScanActivity.this, CameraSelector.DEFAULT_BACK_CAMERA, pv, ia);
            } catch (Exception e) { status.setText("Camera error: " + e.getMessage()); }
        }}, ContextCompat.getMainExecutor(this));
    }

    private void deliver(final String code) {
        runOnUiThread(new Runnable() { public void run() {
            AkCards.Card card = null;
            if (recorded.add(code)) card = AkCollection.add(AkScanActivity.this, code);      // A.21: known card -> into the collection
            else card = AkCards.byCode(code);
            status.setText("Scanned: " + code + (card != null ? "\n" + card.name + "  (in your collection)"
                : (code.length() != 8 ? "  (note: expected 8 characters; this barcode is not in the card list)" : "  (not in the card list)")));
            AkHttp.send(AkScanActivity.this, code, new AkHttp.Result() { public void done(boolean ok, String m) {
                if (ok) finish(); else sent = false; } });
        }});
    }

    @Override protected void onDestroy() { super.onDestroy(); if (exec != null) exec.shutdown(); if (scanner != null) scanner.close(); }
}

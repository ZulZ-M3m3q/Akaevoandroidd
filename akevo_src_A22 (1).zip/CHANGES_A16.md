# A.16 changes (on top of A.15)

## Removed
- Fast forward: `AkSpeed.java`, the ▶▶ overlay button, its settings section/options and the native `nativeSetLimit` hook.
  Layouts saved with the old FF button are migrated: the button is dropped and the new VOL button takes its place.
  (Boot still forces Play!'s normal frame limiter ON, so a phone left at "unlimited" by A.14 is back to normal speed.)

## Added: game volume
- Master volume 0-150 % (100 = normal) applied in the audio pipe (`AkAudioPipe.h`), ramped per 10 ms buffer so there are no clicks,
  clamped to 16-bit so boosting cannot wrap around. JNI entry `AkAudio.nativeSetVolume` lives in `SH_OpenSL.cpp`.
- Settings > Audio: "Game volume" slider (live) and a switch to show/hide the VOL button.
- In game: new **VOL** overlay button (shows the current %). Tap it: a slider panel appears at the top of the screen,
  drag to set, snaps to 100 %, closes by itself after 3 s or when you touch anything else. The button can be moved/resized in Edit layout.
- The phone's hardware volume keys now control the game's audio stream while the game is open.
- Volume is saved and re-applied every time a game starts / resumes.

## Tested
- Gain/ramp/clamp logic compiled and exercised on a host PC (see build notes), Java sources syntax-checked.
- NOT tested: the full Android build and listening on a phone.

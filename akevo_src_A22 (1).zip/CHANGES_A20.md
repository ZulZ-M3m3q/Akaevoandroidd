# A.20 changes (on top of A.19)

## Play time history
- New `AkPlayTime.java`. One session = from the moment the game screen opens (PLAY) until the game is closed.
  Time while the app is in the background (home button, other app, screen off) is not counted.
- The running session is saved every 30 s. If the app is killed (swiped away, crash, battery), the session is finished
  with the last saved time the next time the app starts, so at most ~30 s are lost.
- Finished sessions wait in a queue on the phone and are uploaded to the website (`POST /api/device/playtime`) when the
  phone is online and linked: after a session ends, when the app starts, and after linking. Each session has an id, so a
  resend is never counted twice. Sessions shorter than 5 s are ignored.
- The queue and the running session use keys starting with `dev_`, so they are never part of the cloud backup/restore.
- Hooks: `AkOverlay` (start / resume / pause / end), `AkArcade.boot` (which game), `AkArcade.register` (recover + upload),
  `AkLink.status` (upload after linking), new `AkLink.postPlaytime`.

## Website (Netlify package)
- `POST /api/device/playtime` (device must be linked): up to 50 sessions per request, bad ones rejected, duplicates ignored,
  one session counts at most 24 h. Stored per account in Blobs key `p:<username>`: total seconds, session count,
  last played, newest 200 sessions in detail.
- `GET /api/me` now also returns `playtime` (total, count, last played, 30 recent sessions, last 14 days).
- Dashboard: new "Play time" card (total, last 7 days, sessions, 14-day bars, recent sessions list).
- Deleting the account deletes its play time.
- Needs the new web package deployed BEFORE players update the app (an old site answers 404; the app then simply keeps
  the sessions queued and sends them once the site is updated).

## Tested
- Web: `node test.mjs` -> 68 checks pass (new: not-linked refusal, accept/reject, resend not double counted, 24 h cap,
  totals past the 200-session detail limit, relink keeps the time, account delete wipes it).
- NOT tested: the Java code was not compiled here (no javac available) and the full Android build / a phone talking to
  your real site were not run. The first workflow run will show any compile error in "Build error summary".
- Time reported by the app can be edited by someone who modifies the APK; treat it as a statistic, not as proof.

# A.15 changes (on top of A.14)

## Audio crackle: root cause and fix
Upstream `CSH_OpenSL` (Source/ui_android/SH_OpenSL.cpp):
1. `Write()` enqueued the emulator's own `m_samples` array straight into OpenSL (no copy). The SPU
   starts overwriting that array immediately, while OpenSL is still reading it -> corrupted audio.
2. When the OpenSL queue was full, `Write()` silently threw the whole chunk away (up to 200 ms at
   200 SPU blocks) -> gaps.
3. Nothing absorbed timing jitter between the emulator thread and the sound device.

A.15 replaces SH_OpenSL.cpp/.h with a version that copies samples into a private lock-free ring
(`AkAudioPipe.h`), feeds the device from it in 10 ms buffers, and on underrun fades out, waits for a
pre-buffer (one burst + 40 ms, at least 80 ms) and fades back in.

## Other
- Version A.15. Default SPU block count 50 (was 200): lower audio delay now that the buffer handles jitter.
- Low-end preset uses 100 blocks (was 250). Settings text updated.
- `apply_patches.py` step 9 does the replacement and fails loudly if upstream's file is not the expected one.

## Tested
- `AkAudioPipe` on a host PC: bursts of 450 / 2250 / 9000 frames with jitter, 40 ms stalls: 0 underruns, 0 clicks.
  A 250 ms stall gives 1 underrun, handled with fades, 0 clicks.
- `SH_OpenSL.cpp` syntax-checked against stand-in OpenSL headers; patch step dry-run against the real upstream files.
- NOT tested: the full Android build, and listening on a phone.

## Not changed
Frame rate. If the phone cannot run the game at full speed, audio is produced too slowly and will still
stutter; that needs CPU/GPU speed, not audio changes. Logcat tag `akaudio` prints underruns/overflows.

# A.22 changes (on top of A.21)

## App
- Card collection is synced with the account website (`AkCollection.sync`): at app start, after a new card is scanned/typed, when "My cards" opens, after linking and after a cloud Restore. Needs a linked phone + internet; offline nothing is lost (the whole collection is re-sent next time).
- Cards the player gets from the website's daily gacha are added to "My cards" in the app (two-way merge, never removes cards; they count as 1).
- Version A.22. Deploy the new website BEFORE players update (old site: 404, the app just skips the sync).

## Website (separate package, see its README)
- New Cards tab: daily gacha + collection view, no counter. `/api/collection`, `/api/gacha`, `/api/device/collection`, `/api/cards`.

## Tools
- `akevo/tools/gen_web_cards.py` makes the website's card list from `cards.tsv` (run it, together with `gen_cards.py`, after editing the TSV).

## Tested
- Web: `node test.mjs` 95 checks (sync, no duplicates over 160 daily draws, same-moment double draw, reset time zone, account delete) and the pages in a real browser (no CSP errors).
- App: AkCollection sync/merge compiled and run on a JVM with stubs (offline, unknown cards, burst of syncs, UI callback). Other changed files only syntax-checked.
- NOT tested: the full Android build and a phone talking to your real site.

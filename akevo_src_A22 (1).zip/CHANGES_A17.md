# A.17 changes (on top of A.16)

## Added: web account + app link
The game only starts when this phone is linked to a web account.

1. Player presses PLAY. The app asks the account website for a one-time code and shows it (e.g. `K7M2-9QXA`).
2. Player signs up / logs in on the website and types the code under "Link your app".
3. The app notices within ~3 s, closes the link screen and the game can start.

- `AkLink.java` (logic + HTTPS), `AkLinkActivity.java` (the code screen). Account address comes from the build workflow input **web_url** (https only).
- PLAY checks the link first (`AkLink.requireLinked`). A check younger than 2 minutes is not repeated.
  If the site is unreachable the game still starts when the last successful check is under **7 days** old.
  If the site says the phone is unlinked (player pressed Unlink on the website) the game locks again and a new code is shown.
- `AkArcade.boot()` refuses to boot without a valid link too, so starting from Play!'s own game list does not bypass it.
- Launcher side menu: "Account: linked as <name> / not linked (tap to link)". Settings > Account: link/check, back up and restore.
- Cloud backup: button layouts, volume and all other app settings (not the link itself) saved to the account (max 64 KB) and restored on another phone.
- The website address is fixed at build time on purpose (a user-editable address could be pointed at a fake server).
- `apply_patches.py`: reads `AK_WEB_URL`, validates it, writes it into `AkDefaults.java`, registers `AkLinkActivity`. Version A.17.

## Tested
- Web server: 34 automatic checks (sign up, login, code issue/expiry/reuse, link, unlink from both sides, backup, rate limits, CSRF guard).
- `AkLink.java` / `AkLinkActivity.java` type-checked with javac against stand-in Android classes.
- `apply_patches.py` early steps dry-run on a fake tree (defaults file, manifest entry, bad-URL rejection).
- NOT tested: the full Android build, and the app talking to a real hosted site on a phone.

## Limits (honest)
Anyone who edits the APK can remove the check. This keeps normal players linked to accounts; it is not copy protection.

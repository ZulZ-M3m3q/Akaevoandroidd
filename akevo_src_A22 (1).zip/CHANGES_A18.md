# A.18 changes (on top of A.17)

Goal: when the phone cannot get a link code, the app now says exactly why instead of a bare "Server answered 401".

- **Bug fixed:** `AkLink.call` used streaming mode for the request body. With that, Android/Java throws away the body of
  error replies such as 401, so the real reason was never shown. Streaming mode is removed.
- **Link screen** now always shows, in small text: the website address built into the app and the last request with its
  result (HTTP code + first 140 characters of the reply). Long-press to copy it.
- **"Test connection" button** on the link screen: calls `GET /api/ping` on your site and says OK or why not.
- **Clear message when the address is wrong:** if the reply is a web page (or anything that is not the account API),
  the app says "this address is not the account website's API" and shows what came back.
- **Redirects** (301/302/307/308, https only) are followed by hand and POST keeps its body.
- **Timeouts** raised to 15 s connect / 30 s read so a sleeping free host can wake up.
- **web_url** is cleaned in the build: quotes/spaces/trailing slash removed, `site.netlify.app` becomes `https://site.netlify.app`,
  and the hosting dashboard address (app.netlify.com, dashboard.render.com) is refused with a clear error.
- Workflow: if the repo contains several `apply_patches.py` (old folders), the one with the newest version is used.
- Needs the Netlify web package (it adds `GET /api/ping`); older sites still work, only "Test connection" will fail.

## Tested
- `AkLink.java` / `AkLinkActivity.java` compiled with javac against stand-in Android classes.
- The real `AkLink.call` HTTP code run against a local copy of the new web API: code issued, redirect handling,
  HTML-instead-of-API reply, 401 with body, connection refused.
- NOT tested: the full Android build and a phone talking to your real Netlify site.

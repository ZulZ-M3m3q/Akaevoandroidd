# A.19 changes (on top of A.18)

## The app now makes its own link code
- `AkLink.localCode()` makes the 8-character code on the phone (SecureRandom, same alphabet as the website, valid 15 min)
  and keeps it, so the code on screen no longer depends on the website answering.
- The app sends that code to the site with every status check (`POST /api/device/status`, field `code`). The site registers it.
  If another phone already holds the same code (very unlikely) the site answers with a different one and the app shows that.
- If the site cannot be reached, the link screen still shows the code and says that the site does not know it yet.
  Linking works as soon as one request gets through (the screen retries every 3 seconds).
- After linking, the code is erased from the phone. Backups never include it (keys starting with `dev_` are skipped).
- Needs the new Netlify web package (accepts the app's code). Sites that do not know the new field simply answer with their own code, which the app also shows.

## Tested
- `AkLink.java` / `AkLinkActivity.java` compiled with javac against stand-in Android classes; `localCode` run on a JVM
  (format, alphabet, kept until it expires, replaced after expiry).
- Web side: new checks for accepting the app's code, clashes, expiry and linking with an app-made code.
- NOT tested: the full Android build and a phone talking to your real Netlify site.

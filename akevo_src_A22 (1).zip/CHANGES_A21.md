# A.21 changes (on top of A.20)

## Card collection ("My cards")
- **Card list built in:** all 160 cards from `Tested_and_sorted.pdf` (114 animal, 21 strong, 25 miracle) are in
  `akevo/data/cards.tsv`; `akevo/tools/gen_cards.py` turns that file into `overlay/akevo/AkCardData.java`
  (already generated and included). To fix or add a card: edit the TSV, run `python3 akevo/tools/gen_cards.py`, commit both.
- **Automatic adding:** when a card barcode is scanned with the camera (or typed in Settings) and the text matches a barcode
  in the list, the card is added to the collection. The scan screen shows the card name when it matches, or says the barcode
  is not in the list. Matching is exact (case-sensitive); a case-only difference is accepted only if it points to one card.
  Scanning the same card again only raises its counter.
- **Choosing from the collection:** new screen `AkCollectionActivity` with tabs Animal / Strong / Miracle (owned/total on each
  tab), a name search, and a "Show cards I don't have" switch (unowned cards are greyed out).
  Tap a card = its barcode text is sent to the running game, exactly like a scan, and the screen closes so you are back in the game.
  Long-press = details (all stats, barcode, first scanned, times scanned).
- **Where to open it:** new on-screen button **MY CARDS** (top corner opposite the gear; layouts saved before A.21 get it
  automatically; it can be moved in "Edit layout"), Settings > Card scanner > "My cards", and the launcher side menu.
  From the launcher the game is not running, so tapping a card there tells you to start the game first.
- **Saved with the account:** the collection is stored under the settings key `ak_collection`, so "Back up" saves it and
  "Restore" merges it (keeps local cards, adds saved ones, highest counter wins). It is never removed by a restore.

## Notes
- Two barcodes in the sheet have 9 characters instead of 8 (European Bison `bn4pzZYWH`, King Cobra `bn-K1S>jv`). I checked
  them against the PDF image; they are kept exactly as written. If the game rejects them, the sheet has a typo: fix the TSV.
- The PDF layout split one row in two lines (Courageous Brown Long-eared Bat); it was added by hand.
- All of A.20 (play time) is included.

## Tested
- `AkCards` + `AkCardData` compiled with javac and run on a JVM: 160 cards, every barcode found again, trimming, case fallback,
  unknown / null barcode, the backslash and 9-character barcodes.
- Every overlay `.java` file parsed by javac: no syntax errors, and no missing symbol of our own
  (only Android classes and the two files generated at build time are unresolved there, as expected).
- NOT tested: the full Android build, the collection screen on a real phone, and a real scan.

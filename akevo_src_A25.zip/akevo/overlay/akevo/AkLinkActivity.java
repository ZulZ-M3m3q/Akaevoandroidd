package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Date;

/**
 * A.24 "Link your account" screen. Shows the code; the player sends it to the Discord bot (/link); the bot answers with an unlock key;
 * the player copies the bot's message and comes back here: the key is picked up from the clipboard by itself (or with the paste button).
 */
public class AkLinkActivity extends Activity {
    public static final String EXTRA_FROM_PLAY = "from_play";
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean running, fromPlay, done;
    private TextView title, codeView, steps, status;
    private Button openBtn, copyBtn, pasteBtn, unlinkBtn;
    private String lastCode = "";

    private TextView tv(LinearLayout p, String t, int sp, int color, boolean bold, int topDp) {
        float d = getResources().getDisplayMetrics().density;
        TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (topDp * d); p.addView(v, lp); return v;
    }
    private Button btn(LinearLayout p, String t, View.OnClickListener l) {
        float d = getResources().getDisplayMetrics().density;
        Button b = new Button(this); b.setText(t); b.setAllCaps(false); b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = (int) (8 * d); p.addView(b, lp); return b;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        fromPlay = getIntent().getBooleanExtra(EXTRA_FROM_PLAY, false);
        float d = getResources().getDisplayMetrics().density; int pad = (int) (18 * d);
        ScrollView sv = new ScrollView(this); sv.setBackgroundColor(0xFF0B1117); sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad, pad, pad, pad * 2); root.setGravity(Gravity.CENTER_HORIZONTAL);
        sv.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
        setTitle("AkaiserEvodroid account");

        title = tv(root, "Link your account", 24, 0xFFF2B705, true, 0);
        codeView = tv(root, "----", 40, 0xFFFFFFFF, true, 14); codeView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); codeView.setLetterSpacing(0.12f);
        steps = tv(root, "", 15, 0xFFDDE6EE, false, 10);
        status = tv(root, "", 14, 0xFF8FA3B8, false, 10);
        copyBtn = btn(root, "1. Copy code", new View.OnClickListener() { public void onClick(View v) {
            if (lastCode.length() == 0) return;
            ((ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("link code", lastCode));
            Toast.makeText(AkLinkActivity.this, "Code copied. Now send it to the Discord bot with /link", Toast.LENGTH_LONG).show(); } });
        openBtn = btn(root, "2. Open Discord", new View.OnClickListener() { public void onClick(View v) { AkArcade.openLink(AkLinkActivity.this, AkConfig.discordUrl(AkLinkActivity.this)); } });
        pasteBtn = btn(root, "3. Paste the bot's unlock key", new View.OnClickListener() { public void onClick(View v) { tryClipboard(true); } });
        unlinkBtn = btn(root, "Unlink this device", new View.OnClickListener() { public void onClick(View v) { confirmUnlink(); } });
        btn(root, "Close", new View.OnClickListener() { public void onClick(View v) { finish(); } });
        unlinkBtn.setVisibility(View.GONE);
    }

    private void confirmUnlink() {
        new AlertDialog.Builder(this).setTitle("Unlink this device?")
            .setMessage("The game will ask for a new code the next time you press PLAY.")
            .setPositiveButton("Unlink", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                AkLink.unlink(AkLinkActivity.this, new AkLink.Msg() { public void done(boolean ok, String message) {
                    Toast.makeText(AkLinkActivity.this, message, Toast.LENGTH_LONG).show(); done = false; refresh(); } }); } })
            .setNegativeButton("Cancel", null).show();
    }

    @Override protected void onResume() { super.onResume(); running = true; refresh(); }
    @Override protected void onPause() { super.onPause(); running = false; h.removeCallbacksAndMessages(null); }

    /** Back from Discord: if the clipboard holds the bot's message, use it without any tap. (Android only lets the app read it while it is in front.) */
    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && !done && AkLink.configured(this) && !AkLink.isUsable(this)) tryClipboard(false);
    }

    private void tryClipboard(final boolean manual) {
        String text = "";
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData cd = cm.getPrimaryClip();
            if (cd != null && cd.getItemCount() > 0 && cd.getItemAt(0).getText() != null) text = cd.getItemAt(0).getText().toString();
        } catch (Throwable ignored) { }
        if (!manual && text.indexOf("AK1.") < 0) return;         // automatic check: stay quiet unless a key is there
        AkLink.submitKey(this, text, new AkLink.Msg() { public void done(boolean ok, String message) {
            if (ok) AkCollection.sync(AkLinkActivity.this, null);      // A.25: give the bot this phone's cards right away (for /profile)
            if (ok || manual) Toast.makeText(AkLinkActivity.this, message, Toast.LENGTH_LONG).show();
            else status.setText(message);
            refresh(); } });
    }

    private void refresh() {
        if (!running) return;
        AkLink.status(this, new AkLink.Cb() { public void done(AkLink.Status s) {
            if (!running) return;
            render(s);
            if (s.state == AkLink.NOT_LINKED) h.postDelayed(new Runnable() { public void run() { refresh(); } }, 5000);
        } });
    }

    private void render(AkLink.Status s) {
        switch (s.state) {
            case AkLink.LINKED:
                done = true;
                if (fromPlay) { Toast.makeText(this, "Unlocked as " + s.username + ". Press PLAY!", Toast.LENGTH_LONG).show(); finish(); return; }
                title.setText("Account linked"); codeView.setVisibility(View.GONE);
                copyBtn.setVisibility(View.GONE); openBtn.setVisibility(View.GONE); pasteBtn.setVisibility(View.GONE); unlinkBtn.setVisibility(View.VISIBLE);
                steps.setText("Linked as " + s.username + ".\nThis phone can play the game.");
                status.setText(s.keyExpiresMs > 0 ? "Unlock key valid until " + DateFormat.getMediumDateFormat(this).format(new Date(s.keyExpiresMs)) + ". Then link again with /link." : "");
                break;
            case AkLink.NOT_LINKED:
                done = false;
                title.setText("Link your account"); unlinkBtn.setVisibility(View.GONE);
                copyBtn.setVisibility(View.VISIBLE); openBtn.setVisibility(View.VISIBLE); pasteBtn.setVisibility(View.VISIBLE);
                lastCode = s.code.replace("-", ""); codeView.setText(s.code); codeView.setVisibility(View.VISIBLE);
                steps.setText("1. Copy the code\n2. In the Discord server type /link and paste the code\n3. The bot answers with an unlock key: long-press the message > Copy text\n4. Come back here. It unlocks by itself (or tap the paste button)");
                if (status.getText().length() == 0 || status.getText().toString().startsWith("Code valid")) status.setText("Code valid " + Math.max(1, s.expiresIn / 60) + " more min");
                break;
            default:   // NOT_CONFIGURED
                title.setText("Not set up"); codeView.setVisibility(View.GONE);
                copyBtn.setVisibility(View.GONE); openBtn.setVisibility(View.GONE); pasteBtn.setVisibility(View.GONE);
                steps.setText(s.message); status.setText("");
        }
    }
}

# A.24 changes (on top of A.23)

## Link by Discord bot, no website, no server
- The player copies the app's code and sends `/link code:` to the Discord bot. The bot replies privately with an unlock key (`AK1.<payload>.<signature>`, ECDSA P-256 signed). The app picks the key up from the clipboard when the player comes back (or with the "Paste the bot's unlock key" button) and unlocks.
- The app checks the key offline with the public key built into it (`AkDefaults.PUBKEY`): valid signature, made for this phone's current (or previous) code, not expired. Re-checked on every PLAY. No network, no website, no Cloudflare. The private key and the bot token live only on the bot's computer.
- The bot is `link-worker/worker.js`: ONE Cloudflare Worker pasted in the dashboard (no terminal, no database, no static site). Discord interactions, Ed25519 request check, ECDSA signing (converted to DER for Java). Helper pages: `/keygen` (makes the key pair), `/pubkey` (the line for the app build), `/register` (registers /link). Keys expire after `KEY_DAYS` (default 30; 0 = never); optional `GUILD_ID` / `ROLE_ID`. No per-person key limit (needs state).
- Build workflow: input `web_url` is gone; new required input `unlock_public_key`; optional `discord_url` (default: the invite already in the app). `apply_patches.py` refuses a missing/garbled key.
- `AkLink.java` rewritten (local only); `AkLinkActivity.java` rewritten (copy code / open Discord / paste key). The cloud Back up / Restore buttons are removed from Settings.
- Removed because they need a server: website (Cloudflare Worker + D1), cloud backup, daily gacha, play-time statistics, card sync across phones. The card collection stays on the phone.
- Version A.24, workflow `akaiserevodroid_A24.yml`.

## Tested
- Worker: 18 checks (`node test.mjs`) with real Ed25519 Discord signatures: keygen -> pubkey, ping, bad/old signature, key made and verified with the DER signature (40 keys in a row), expiry, KEY_DAYS=0, server/DM/role gating, junk code, not-set-up message, /register, home page.
- A key signed by the bot code verified (and a tampered one rejected) with real Java `SHA256withECDSA` + X.509 public key, the same calls the app uses.
- `apply_patches.py` key validation (good key accepted; empty and garbage rejected).
- NOT tested: a real Discord server (`worker.js` was only run in Node, not on Cloudflare), the Android build (changed Java files only syntax-checked: no errors other than missing Android/generated classes), the clipboard pick-up on a real phone.

# A.25 changes (on top of A.24)

## Discord bot: profile, daily gacha, cards
- New commands: `/profile [user] [public]` (collection %, card types, animal rarities, rarest card, today's daily gacha card, draws, last sync), `/gacha` (one free card per day, never a duplicate), `/cards [kind]`. `/link` unchanged.
- The Worker now stores player data in a Cloudflare KV namespace bound as `KV` (`p:<discordId>` profile, `k:<discordId>` cards + gacha). `/link` works without KV; the other commands explain when KV is missing.
- New app route `POST /api/collection` (Authorization: Bearer <unlock key>): the Worker verifies the key's signature itself (public key derived from `PRIVATE_KEY`), checks expiry, merges the phone's cards (earliest first-scan date wins, unknown card ids ignored) and returns the merged collection, so a `/gacha` card travels back to the phone. Same JSON contract the A.22 app code already used.
- Setting `GACHA_UTC_OFFSET_MIN` (daily reset, default UTC). Gacha card data reused from the A.23 website.

## App
- `AkLink.postCollection` sends the collection to `<bot_url>/api/collection` (HttpURLConnection, https, 8 s / 12 s timeouts, no card data without an unlocked key). Syncs already ran at app start, on a new card and when My cards opens; A.25 adds one right after linking.
- New optional workflow input `bot_url` (validated: https, host only). Empty = cards stay on the phone, as in A.24.
- Version A.25, workflow `akaiserevodroid_A25.yml`.

## Tested
- Worker: 33 checks (`node test.mjs`, fake KV, real Ed25519 and ECDSA signatures): link, sync merge + earliest date + unknown ids, sync without key / garbage / tampered / expired / no KV, /cards, /gacha once a day and never a duplicate, /profile (self, other member, public), gacha card back to the app, complete collection, no-KV messages.
- `bot_url` validation in `apply_patches.py` (trailing slash removed, https added, path/http rejected).
- NOT tested: Cloudflare KV itself, a real Discord server, the Android build (Java only syntax-checked: only Android and generated classes unresolved), a phone. The two A.24 caveats still apply.

## Build workflow: Play! version
- The build always downloads the newest Play! (emulator) from GitHub, so a new run = the latest Play! with the unchanged AkaiserEvodroid UI and features.
- New optional input `play_ref` (tag / branch / commit; empty = latest) to pick another Play! version, e.g. an older one if the newest breaks the patches. The exact Play! commit used is printed in the log and in the run summary. The clone retries 3 times.
- Not tested against the real Play! repository (no network here): if the newest Play! changed the code our patches look for, the "Apply patches" step stops with a message; use `play_ref` to build an older version meanwhile.

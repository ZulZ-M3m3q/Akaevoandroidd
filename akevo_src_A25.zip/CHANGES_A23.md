# A.23 changes (on top of A.22)

## App
- No feature change. The app only talks to the address given as `web_url` when the APK is built, so it works with Cloudflare as it did with Netlify (https, same `/api/...` paths, same JSON, same `Authorization: Device ...` header, redirects still followed).
- Build workflow: `web_url` example is now a Cloudflare address (`https://akaiser-accounts.your-name.workers.dev`); the build refuses the Cloudflare dashboard address (`dash.cloudflare.com`) by mistake, like it already did for Netlify/Render dashboards.
- Version A.23.

## Website
- New package `AkaiserWeb_Cloudflare_A23.zip` (Workers + Assets + D1). Netlify files removed. See its README.
- Old Netlify accounts are not moved: players sign up again, then link the phone with the code as before.

## Tested
- Web: `node test.mjs` 95 checks (whole API) + `node test-d1.mjs` 25 checks (real Worker entry + D1 storage code on SQLite; same-moment double sign-up; daily clean-up; missing database message).
- App: URL validation of `apply_patches.py` for workers.dev / dashboard addresses; Python syntax. NOT tested: the full Android build, `wrangler deploy` on a real Cloudflare account, and a phone talking to the real site.

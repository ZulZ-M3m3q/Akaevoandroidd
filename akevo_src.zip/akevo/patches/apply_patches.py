#!/usr/bin/env python3
"""Turns a fresh checkout of jpd002/Play- into AkaiserEvodroid A.1. Fails LOUDLY if an anchor is not found."""
import os, re, sys, shutil, glob

PLAY = os.path.abspath(sys.argv[1]); HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
APP_ID = "com.akaiser.evodroid"; APP_NAME = "AkaiserEvodroid"; VERSION = "A.1"
def log(*a): print("[akevo]", *a, flush=True)
def die(m): print("[akevo] ERROR:", m); sys.exit(1)
def rd(p): return open(p, encoding="utf-8", errors="surrogateescape").read()
def wr(p, s): open(p, "w", encoding="utf-8", errors="surrogateescape").write(s)
def walk(sub, pat):
    for r, d, f in os.walk(os.path.join(PLAY, sub)):
        d[:] = [x for x in d if x not in ("build", ".git", "Dependencies", "node_modules", ".gradle")]
        for n in f:
            if re.search(pat, n): yield os.path.join(r, n)

# 1. copy overlay sources next to Play!'s Android Java sources -------------------------------------
emu = [p for p in walk("Source", r"^EmulatorActivity\.java$")]
if not emu: die("EmulatorActivity.java not found - Play! source layout changed")
jdir = os.path.dirname(emu[0]); dst = os.path.join(jdir, "akevo"); os.makedirs(dst, exist_ok=True)
for f in glob.glob(os.path.join(ROOT, "overlay", "akevo", "*.java")): shutil.copy(f, dst)
log("copied overlay to", dst)

# 2. endpoint auto-detection (Play!'s Arcade I/O HTTP server) --------------------------------------
port, path, method, body, detected = 8080, "/", "POST", "{code}", False
cands = []
for p in list(walk("Source", r"\.(cpp|h|hpp|mm|java)$")):
    try: s = rd(p)
    except Exception: continue
    if "/akevo/" in p.replace(os.sep, "/"): continue          # skip our own files
    if re.search(r"barcode", s, re.I) and re.search(r"http", s, re.I):
        cands.append((p, s))
log("AKEVO endpoint scan: %d candidate files" % len(cands))
for p, s in cands:
    log("  candidate:", os.path.relpath(p, PLAY))
    for m in re.finditer(r"(?:\.|->)(Get|Post|Put)\(\s*(?:R?\"([^\"]*)\")", s):
        log("    route:", m.group(1), m.group(2))
        if not detected:
            method = m.group(1).upper(); path = m.group(2) if m.group(2).startswith("/") else "/" + m.group(2)
            path = re.sub(r"\(\.\*\)|\(\[\^/\]\+\)|\{[a-z_]+\}|:[a-z_]+", "{code}", path); detected = True
    for m in re.finditer(r"(?:listen|bind_to_port)\([^,]*,\s*(\d{3,5})", s):
        log("    port:", m.group(1)); port = int(m.group(1))
    for m in re.finditer(r"(?i)(\w*port\w*)\s*[=:(]\s*(\d{4,5})", s):
        if "http" in m.group(0).lower() or "server" in m.group(1).lower(): log("    port?:", m.group(0))
tmpl = rd(os.path.join(ROOT, "overlay", "akevo", "AkDefaults.java.template"))
wr(os.path.join(dst, "AkDefaults.java"), tmpl.replace("@PORT@", str(port)).replace("@PATH@", path).replace("@METHOD@", method).replace("@BODY@", body).replace("@DETECTED@", "true" if detected else "false"))
os.remove(os.path.join(dst, "AkDefaults.java.template")) if os.path.exists(os.path.join(dst, "AkDefaults.java.template")) else None
log("endpoint defaults: %s http://127.0.0.1:%d%s detected=%s" % (method, port, path, detected))

# 3. hook the overlay into EmulatorActivity.onCreate ----------------------------------------------
s = rd(emu[0]); HOOK = "com.virtualapplications.play.akevo.AkOverlay.attach(this);"
if HOOK not in s:
    m = re.search(r"super\.onCreate\([^;]*\);", s)
    if not m: die("super.onCreate(...) not found in EmulatorActivity.java")
    s = s[:m.end()] + "\n\t\t" + HOOK + s[m.end():]; wr(emu[0], s)
log("hooked EmulatorActivity")

# 4. manifest ----------------------------------------------------------------------------------------
mans = [p for p in walk(".", r"^AndroidManifest\.xml$") if ("EmulatorActivity" in rd(p) or "virtualapplications" in rd(p))]
if not mans: die("AndroidManifest.xml not found")
man = mans[0]; m = rd(man)
if "AkSettingsActivity" not in m:
    add = ('\n\t<activity android:name="com.virtualapplications.play.akevo.AkSettingsActivity" android:exported="false" android:label="AkaiserEvodroid Settings" android:theme="@android:style/Theme.Material.Light.NoActionBar"/>'
           '\n\t<activity android:name="com.virtualapplications.play.akevo.AkScanActivity" android:exported="false" android:theme="@style/Theme.AppCompat.NoActionBar"/>\n')
    if "</application>" not in m: die("</application> not in manifest")
    m = m.replace("</application>", add + "</application>", 1)
    perms = ""
    for pm in ("android.permission.CAMERA", "android.permission.INTERNET", "android.permission.VIBRATE"):
        if pm not in m: perms += '\n\t<uses-permission android:name="%s"/>' % pm
    m = re.sub(r"(<manifest[^>]*>)", lambda x: x.group(1) + perms, m, 1)
    m = re.sub(r'(<application[^>]*?android:label=")[^"]*(")', r"\g<1>%s\2" % APP_NAME, m, 1)
    wr(man, m)
log("patched manifest", os.path.relpath(man, PLAY))

# 5. app name / id / version / dependencies -------------------------------------------------------------
for p in walk(".", r"^strings\.xml$"):
    if "/deps/" in p.replace(os.sep, "/"): continue
    t = rd(p)
    if 'name="app_name"' in t:
        wr(p, re.sub(r'(<string name="app_name"[^>]*>)[^<]*(</string>)', r"\g<1>%s\2" % APP_NAME, t)); log("app_name in", os.path.relpath(p, PLAY))
allg = [p for p in walk("build_android", r"^build\.gradle(\.kts)?$") if "/Dependencies/" not in p.replace(os.sep, "/")]
log("gradle files under build_android:", [os.path.relpath(x, PLAY) for x in allg])
deps = ["androidx.camera:camera-core:1.3.4", "androidx.camera:camera-camera2:1.3.4", "androidx.camera:camera-lifecycle:1.3.4",
        "androidx.camera:camera-view:1.3.4", "com.google.mlkit:barcode-scanning:17.3.0"]
id_done = False
for g in allg:
    t = rd(g); kts = g.endswith(".kts"); orig = t
    idline = ('applicationId = "%s"' if kts else 'applicationId "%s"') % APP_ID
    if re.search(r"applicationId\s*=?\s*[\"']", t):
        t = re.sub(r"applicationId\s*=?\s*[\"'][^\"']+[\"']", idline, t, 1); id_done = True
    else:
        m3 = re.search(r"defaultConfig\s*\{", t)
        if m3 and "android" in t:
            t = t[:m3.end()] + "\n        " + idline + t[m3.end():]; id_done = True
            log("inserted applicationId into", os.path.relpath(g, PLAY))
    if re.search(r"versionName\s*=?\s*[\"']", t):
        t = re.sub(r"versionName\s*=?\s*[\"'][^\"']*[\"']", ('versionName = "%s"' if kts else 'versionName "%s"') % VERSION, t, 1)
    if t != orig: wr(g, t); log("patched", os.path.relpath(g, PLAY))
if not id_done: log("WARNING: could not set applicationId - app keeps Play!'s package name")
# make sure no hard-coded provider authorities collide with the original Play! app
for mf in walk("build_android", r"^AndroidManifest\.xml$"):
    t = rd(mf)
    if "com.virtualapplications.play." in t and "authorities" in t:
        log("NOTE manifest has fixed authorities:", os.path.relpath(mf, PLAY), re.findall(r'authorities="([^"]+)"', t))
log("DONE - AkaiserEvodroid", VERSION)

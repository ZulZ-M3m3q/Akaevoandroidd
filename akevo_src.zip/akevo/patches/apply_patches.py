#!/usr/bin/env python3
"""Turns a fresh checkout of jpd002/Play- into AkaiserEvodroid A.1. Fails LOUDLY if an anchor is not found."""
import os, re, sys, shutil, glob

PLAY = os.path.abspath(sys.argv[1]); HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
APP_ID = "com.akaiser.evodroid"; APP_NAME = "AKaiserEvodroid"; VERSION = "A.11"
def log(*a): print("[akevo]", *a, flush=True)
def die(m): print("[akevo] ERROR:", m); sys.exit(1)
def rd(p): return open(p, encoding="utf-8", errors="surrogateescape").read()
def wr(p, s): open(p, "w", encoding="utf-8", errors="surrogateescape").write(s)
def walk(sub, pat):
    for r, d, f in os.walk(os.path.join(PLAY, sub)):
        d[:] = [x for x in d if x not in ("build", ".git", "Dependencies", "node_modules", ".gradle")]
        for n in f:
            if re.search(pat, n): yield os.path.join(r, n)

# 1. copy overlay sources next to Play!'s Android Java sources -------------------------------------
emu = [p for p in walk("Source", r"^EmulatorActivity\.java$")]
if not emu: die("EmulatorActivity.java not found - Play! source layout changed")
jdir = os.path.dirname(emu[0]); dst = os.path.join(jdir, "akevo"); os.makedirs(dst, exist_ok=True)
for f in glob.glob(os.path.join(ROOT, "overlay", "akevo", "*.java")): shutil.copy(f, dst)
log("copied overlay to", dst)

# 2. endpoint auto-detection (Play!'s Arcade I/O HTTP server) --------------------------------------
port, path, method, body, detected = 8080, "/", "POST", "{code}", False
cands = []
for p in list(walk("Source", r"\.(cpp|h|hpp|mm|java)$")):
    try: s = rd(p)
    except Exception: continue
    if "/akevo/" in p.replace(os.sep, "/"): continue          # skip our own files
    if re.search(r"barcode", s, re.I) and re.search(r"http", s, re.I):
        cands.append((p, s))
log("AKEVO endpoint scan: %d candidate files" % len(cands))
for p, s in cands:
    log("  candidate:", os.path.relpath(p, PLAY))
    for m in re.finditer(r"(?:\.|->)(Get|Post|Put)\(\s*(?:R?\"([^\"]*)\")", s):
        log("    route:", m.group(1), m.group(2))
        if not detected:
            method = m.group(1).upper(); path = m.group(2) if m.group(2).startswith("/") else "/" + m.group(2)
            path = re.sub(r"\(\.\*\)|\(\[\^/\]\+\)|\{[a-z_]+\}|:[a-z_]+", "{code}", path); detected = True
    for m in re.finditer(r"(?:listen|bind_to_port)\([^,]*,\s*(\d{3,5})", s):
        log("    port:", m.group(1)); port = int(m.group(1))
    for m in re.finditer(r"(?i)(\w*port\w*)\s*[=:(]\s*(\d{4,5})", s):
        if "http" in m.group(0).lower() or "server" in m.group(1).lower(): log("    port?:", m.group(0))
# Known from Play! source (CSys147::HandleIoServerRequest): POST /sys147/barcode with the 8-char code as body.
port, path, method, body, detected = 8080, "/sys147/barcode", "POST", "{code}", True
tmpl = rd(os.path.join(ROOT, "overlay", "akevo", "AkDefaults.java.template"))
wr(os.path.join(dst, "AkDefaults.java"), tmpl.replace("@PORT@", str(port)).replace("@PATH@", path).replace("@METHOD@", method).replace("@BODY@", body).replace("@DETECTED@", "true" if detected else "false"))
os.remove(os.path.join(dst, "AkDefaults.java.template")) if os.path.exists(os.path.join(dst, "AkDefaults.java.template")) else None
log("endpoint defaults: %s http://127.0.0.1:%d%s detected=%s" % (method, port, path, detected))

# 3. hook the overlay into EmulatorActivity.onCreate ----------------------------------------------
s = rd(emu[0]); HOOK = "com.virtualapplications.play.akevo.AkOverlay.attach(this);"
if HOOK not in s:
    m = re.search(r"super\.onCreate\([^;]*\);", s)
    if not m: die("super.onCreate(...) not found in EmulatorActivity.java")
    s = s[:m.end()] + "\n\t\t" + HOOK + s[m.end():]; wr(emu[0], s)
log("hooked EmulatorActivity")
t = rd(emu[0]); needle = "virtualPadView.setVisibility(SettingsManager.getPreferenceBoolean(PREF_EMU_GENERAL_SHOWVIRTUALPAD) ? View.VISIBLE : View.GONE);"
if needle in t:
    wr(emu[0], t.replace(needle, "virtualPadView.setVisibility(View.GONE);")); log("PS2 virtual pad hidden in EmulatorActivity")
else:
    log("WARNING: virtual pad visibility line not found - relying on the overlay to hide the PS2 pad")


# 4. manifest ----------------------------------------------------------------------------------------
mans = [p for p in walk(".", r"^AndroidManifest\.xml$") if ("EmulatorActivity" in rd(p) or "virtualapplications" in rd(p))]
if not mans: die("AndroidManifest.xml not found")
man = mans[0]; m = rd(man)
if "AkImportActivity" not in m:
    add = ('\n\t<activity android:name="com.virtualapplications.play.akevo.AkSettingsActivity" android:exported="false" android:label="AKaiserEvodroid Settings" android:theme="@android:style/Theme.Material.Light.NoActionBar"/>'
           '\n\t<activity android:name="com.virtualapplications.play.akevo.AkImportActivity" android:exported="false" android:theme="@android:style/Theme.Material.Light.NoActionBar"/>'
           '\n\t<activity android:name="com.virtualapplications.play.akevo.AkScanActivity" android:exported="false" android:screenOrientation="locked" android:configChanges="orientation|screenSize|keyboardHidden" android:theme="@style/Theme.AppCompat.NoActionBar"/>\n')
    if "</application>" not in m: die("</application> not in manifest")
    m = m.replace("</application>", add + "</application>", 1)
    perms = ""
    for pm in ("android.permission.CAMERA", "android.permission.INTERNET", "android.permission.VIBRATE"):
        if pm not in m: perms += '\n\t<uses-permission android:name="%s"/>' % pm
    m = re.sub(r"(<manifest[^>]*>)", lambda x: x.group(1) + perms, m, 1)
    m = re.sub(r'(<application[^>]*?android:label=")[^"]*(")', r"\g<1>%s\2" % APP_NAME, m, 1)
    wr(man, m)
log("patched manifest", os.path.relpath(man, PLAY))

# 5. app name / id / version / dependencies -------------------------------------------------------------
for p in walk(".", r"^strings\.xml$"):
    if "/deps/" in p.replace(os.sep, "/"): continue
    t = rd(p)
    if 'name="app_name"' in t:
        wr(p, re.sub(r'(<string name="app_name"[^>]*>)[^<]*(</string>)', r"\g<1>%s\2" % APP_NAME, t)); log("app_name in", os.path.relpath(p, PLAY))
allg = [p for p in walk("build_android", r"^build\.gradle(\.kts)?$") if "/Dependencies/" not in p.replace(os.sep, "/")]
log("gradle files under build_android:", [os.path.relpath(x, PLAY) for x in allg])
deps = ["androidx.camera:camera-core:1.3.4", "androidx.camera:camera-camera2:1.3.4", "androidx.camera:camera-lifecycle:1.3.4",
        "androidx.camera:camera-view:1.3.4", "com.google.mlkit:barcode-scanning:17.3.0"]
id_done = False
for g in allg:
    t = rd(g); kts = g.endswith(".kts"); orig = t
    idline = ('applicationId = "%s"' if kts else 'applicationId "%s"') % APP_ID
    if re.search(r"applicationId\s*=?\s*[\"']", t):
        t = re.sub(r"applicationId\s*=?\s*[\"'][^\"']+[\"']", idline, t, 1); id_done = True
    else:
        m3 = re.search(r"defaultConfig\s*\{", t)
        if m3 and "android" in t:
            t = t[:m3.end()] + "\n        " + idline + t[m3.end():]; id_done = True
            log("inserted applicationId into", os.path.relpath(g, PLAY))
    if re.search(r"versionName\s*=?\s*[\"']", t):
        t = re.sub(r"versionName\s*=?\s*[\"'][^\"']*[\"']", ('versionName = "%s"' if kts else 'versionName "%s"') % VERSION, t, 1)
    if t != orig: wr(g, t); log("patched", os.path.relpath(g, PLAY))
if not id_done: log("WARNING: could not set applicationId - app keeps Play!'s package name")
# make sure no hard-coded provider authorities collide with the original Play! app
for mf in walk("build_android", r"^AndroidManifest\.xml$"):
    t = rd(mf)
    if "com.virtualapplications.play." in t and "authorities" in t:
        log("NOTE manifest has fixed authorities:", os.path.relpath(mf, PLAY), re.findall(r'authorities="([^"]+)"', t))
# 7. arcade support: boot *.arcadedef through Play!'s own ArcadeUtils ------------------------------------------
NATIVE_CODE = r'''
// ===== AkaiserEvodroid arcade support (appended by apply_patches.py) =====
#include <android/log.h>

extern "C" JNIEXPORT void JNICALL Java_com_virtualapplications_play_akevo_AkArcade_nativeRegister(JNIEnv* env, jclass clazz, jstring defPathJ, jstring titleJ)
{
	try
	{
		auto defPath = fs::path(GetStringFromJstring(env, defPathJ));
		auto title = GetStringFromJstring(env, titleJ);
		BootablesDb::CClient::GetInstance().RegisterBootable(defPath, "", "", BootableUtils::PS2_ARCADE);
		BootablesDb::CClient::GetInstance().SetTitle(defPath, title.c_str());
	}
	catch(const std::exception& exception)
	{
		__android_log_print(ANDROID_LOG_WARN, "AkArcade", "nativeRegister failed: %s", exception.what());
	}
}

static void AkLogStep(const std::string& text, bool truncate = false)
{
	try
	{
		auto path = Framework::PathUtils::GetPersonalDataPath() / "akevo_boot.log";
		FILE* f = fopen(path.string().c_str(), truncate ? "w" : "a");
		if(!f) return;
		fprintf(f, "%s\n", text.c_str());
		fclose(f);
	}
	catch(...)
	{
	}
}

extern "C" JNIEXPORT void JNICALL Java_com_virtualapplications_play_akevo_AkArcade_nativeBoot(JNIEnv* env, jclass clazz, jstring defPathJ, jstring romsDirJ, jint port, jboolean ioEnabled, jint spuBlocks)
{
	assert(g_virtualMachine != nullptr);
	try
	{
		AkLogStep("1 nativeBoot start", true);
		auto defPath = fs::path(GetStringFromJstring(env, defPathJ));
		auto romsDir = fs::path(GetStringFromJstring(env, romsDirJ));
		AkLogStep("   def=" + defPath.string() + " roms=" + romsDir.string());
		auto& config = CAppConfig::GetInstance();
		try { config.SetPreferencePath(PREF_PS2_ARCADEROMS_DIRECTORY, romsDir); } catch(...) { AkLogStep("   WARN could not set arcade roms dir"); }
		try { config.SetPreferenceBoolean(PREF_PS2_ARCADE_IO_SERVER_ENABLED, ioEnabled == JNI_TRUE); } catch(...) { AkLogStep("   WARN could not enable io server"); }
		try { config.SetPreferenceInteger(PREF_PS2_ARCADE_IO_SERVER_PORT, port); } catch(...) { AkLogStep("   WARN could not set io server port"); }
		if(spuBlocks > 0) { try { config.SetPreferenceInteger(PREF_AUDIO_SPUBLOCKCOUNT, spuBlocks); } catch(...) { AkLogStep("   WARN could not set audio buffer"); } }
		AkLogStep("2 preferences set");
		g_virtualMachine->Pause();
		g_virtualMachine->ReloadSpuBlockCount();
		try { config.SetPreferenceBoolean(PREF_PS2_LIMIT_FRAMERATE, true); } catch(...) { }   // normal frame limiter (undoes any earlier speed experiments)
		g_virtualMachine->ReloadFrameRateLimit();
		SetupSoundHandler();
		AkLogStep("3 calling BootArcadeMachine");
		ArcadeUtils::BootArcadeMachine(g_virtualMachine, defPath);
		AkLogStep("4 BootArcadeMachine returned");
		g_virtualMachine->Pause();
		AkLogStep("5 DONE (machine paused, waiting for the screen)");
	}
	catch(const std::exception& exception)
	{
		AkLogStep(std::string("EXCEPTION: ") + exception.what());
		jclass exceptionClass = env->FindClass("java/lang/Exception");
		env->ThrowNew(exceptionClass, exception.what());
	}
}

extern "C" JNIEXPORT jint JNICALL Java_com_virtualapplications_play_akevo_AkArcade_nativeGetSpuBlocks(JNIEnv* env, jclass clazz)
{
	try { return CAppConfig::GetInstance().GetPreferenceInteger(PREF_AUDIO_SPUBLOCKCOUNT); } catch(...) { return -1; }
}

extern "C" JNIEXPORT void JNICALL Java_com_virtualapplications_play_akevo_AkArcade_nativeSetSpuBlocks(JNIEnv* env, jclass clazz, jint blocks)
{
	try
	{
		CAppConfig::GetInstance().SetPreferenceInteger(PREF_AUDIO_SPUBLOCKCOUNT, blocks);
		if(g_virtualMachine != nullptr) g_virtualMachine->ReloadSpuBlockCount();
	}
	catch(...)
	{
	}
}
'''
ni = list(walk("Source", r"^NativeInterop\.cpp$"))
if not ni: die("NativeInterop.cpp not found")
t = rd(ni[0])
if "AkArcade" not in t:
    inc = '#include "ui_shared/StatsManager.h"'
    if inc not in t: die("anchor include not found in NativeInterop.cpp")
    t = t.replace(inc, inc + '\n#include "ui_shared/ArcadeUtils.h"\n#include "ui_shared/BootablesDbClient.h"\n#include "ui_shared/BootableUtils.h"', 1)
    t = t.rstrip() + "\n" + NATIVE_CODE
    wr(ni[0], t)
log("native arcade functions added to", os.path.relpath(ni[0], PLAY))

au = list(walk("Source", r"^ArcadeUtils\.cpp$"))
if not au: die("ArcadeUtils.cpp not found")
t = rd(au[0]); needle = 'Framework::PathUtils::GetAppResourcesPath() / "arcadedefs"'
if needle not in t: die("arcadedefs path anchor not found in ArcadeUtils.cpp")
t = t.replace(needle, 'fs::path("/")')   # arcadedef is passed as an absolute path; "/" / "/abs/path" == "/abs/path"
if "#ifndef DEBUGGER_INCLUDED" not in t: die("DEBUGGER_INCLUDED anchor not found in ArcadeUtils.cpp")
t = t.replace("#ifndef DEBUGGER_INCLUDED", "#if !defined(DEBUGGER_INCLUDED) && !defined(__ANDROID__)")   # Android resumes the VM itself once the screen exists
pn = 'arcadeDefsPath / (def.parent + ".arcadedef")'
if pn not in t: die("parent arcadedef anchor not found in ArcadeUtils.cpp")
t = t.replace(pn, 'arcadeDefFilename.parent_path() / (def.parent + ".arcadedef")')   # parent lives next to the child definition
wr(au[0], t); log("ArcadeUtils.cpp: arcadedefs now resolved from absolute path")

vm = list(walk("Source", r"^VirtualMachineManager\.java$"))
if not vm: die("VirtualMachineManager.java not found")
t = rd(vm[0]); needle = "if(BootablesInterop.IsBootableExecutablePath(_bootablePath))"
if needle not in t: die("launch anchor not found in VirtualMachineManager.java")
if "AkArcade" not in t:
    t = t.replace(needle, 'if(_bootablePath.endsWith(".arcadedef"))\n\t\t\t\t{\n\t\t\t\t\tcom.virtualapplications.play.akevo.AkArcade.boot(_ctx, _bootablePath);\n\t\t\t\t}\n\t\t\t\telse ' + needle, 1)
    wr(vm[0], t)
log("hooked VirtualMachineManager (arcade launch)")

ma = list(walk("Source", r"^MainActivity\.java$"))
if not ma: die("MainActivity.java not found")
t = rd(ma[0]); needle = "NativeInterop.setContentResolver(getApplicationContext().getContentResolver());"
if needle not in t: die("setContentResolver anchor not found in MainActivity.java")
if "AkArcade" not in t:
    t = t.replace(needle, needle + "\n\t\ttry { com.virtualapplications.play.akevo.AkArcade.register(this); } catch(Throwable akT) { }", 1)
    wr(ma[0], t)
log("hooked MainActivity (arcade registration + import prompt)")
t = rd(ma[0])
if "AkArcade.openLink" not in t:
    m2 = re.search(r"case 2:\s*displayAboutDialog\(\);\s*break;", t)
    if not m2: die("drawer 'About' case not found in MainActivity.java")
    AKP = "com.virtualapplications.play.akevo.AkArcade"
    cases = ("\n\t\tcase 3:\n\t\t\tstartActivity(new Intent(this, com.virtualapplications.play.akevo.AkSettingsActivity.class));\n\t\t\tbreak;"
             "\n\t\tcase 4:\n\t\t\t" + AKP + ".openLink(this, " + AKP + ".URL_DISCORD);\n\t\t\tbreak;"
             "\n\t\tcase 5:\n\t\t\t" + AKP + ".openLink(this, " + AKP + ".URL_INSTAGRAM);\n\t\t\tbreak;"
             "\n\t\tcase 6:\n\t\t\t" + AKP + ".openLink(this, " + AKP + ".URL_TIKTOK);\n\t\t\tbreak;")
    t = t.replace(m2.group(0), m2.group(0) + cases, 1)
    needle = "displaySimpleMessage(getString(R.string.about_play), aboutMessage);"
    if needle not in t: die("About dialog anchor not found in MainActivity.java")
    t = t.replace(needle, 'displaySimpleMessage("About AKaiserEvodroid", ' + AKP + '.aboutText() + "\\n\\n" + aboutMessage);', 1)
    wr(ma[0], t)
log("side menu: settings + Discord / Instagram / TikTok entries, About dialog text")
t = rd(ma[0])
if "akLaunch" not in t:
    m3 = re.search(r"(protected void onCreate\(Bundle savedInstanceState\)\s*\{\s*super\.onCreate\(savedInstanceState\);)", t)
    if not m3: die("onCreate anchor not found in MainActivity.java")
    t = t.replace(m3.group(1), m3.group(1) + "\n\t\tsetRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);", 1)
    helpers = ("public void akOpenPlaySettings() { displaySettingsActivity(); }\n\tpublic void akOpenAbout() { displayAboutDialog(); }\n\t"
               "public void akLaunch(String path) { VirtualMachineManager.launchGame(this, path, null); }\n\n\t")
    if "public void restoreActionBar()" not in t: die("restoreActionBar anchor not found")
    t = t.replace("public void restoreActionBar()", helpers + "public void restoreActionBar()", 1)
    wr(ma[0], t)
log("launcher: MainActivity is landscape and exposes settings / about / launch to the new launcher screen")


nd = list(walk("Source", r"^NavigationDrawerFragment\.java$"))
if not nd: die("NavigationDrawerFragment.java not found")
t = rd(nd[0]); pat = "getString(R.string.main_menu_about),"
if pat not in t: die("drawer list anchor not found")
if "Discord" not in t:
    t = t.replace(pat, pat + '\n\t\t\t\t\t\t"AKaiserEvodroid Settings",\n\t\t\t\t\t\t"Join our Discord server",\n\t\t\t\t\t\t"Instagram: zull_bixie",\n\t\t\t\t\t\t"TikTok: bixieredpixiu",', 1)
    wr(nd[0], t)


# 7b. generate AkDefs.java: every Animal Kaiser Evolution definition shipped with this Play! checkout (versions 1-8) -------
import json
defs = {}
for f in sorted(os.listdir(os.path.join(PLAY, "arcadedefs"))):
    mm = re.match(r"^(akaievo\d*)\.arcadedef$", f)
    if mm: defs[mm.group(1)] = json.loads(rd(os.path.join(PLAY, "arcadedefs", f)))
if "akaievo" not in defs: die("arcadedefs/akaievo.arcadedef not found in this Play! checkout")
# Android feeds one controller (pad 0). Player 2's two buttons are therefore remapped from pad 1 to pad 0's CIRCLE (118 = green) / SQUARE (119 = yellow).
P2MAP = {"1:dpad_left": "0:square", "1:dpad_right": "0:circle"}
for did, dd in defs.items():
    if isinstance(dd.get("buttons"), dict):
        for code, sel in list(dd["buttons"].items()):
            if sel in P2MAP: dd["buttons"][code] = P2MAP[sel]; log("player 2 input", did, code, sel, "->", P2MAP[sel])
ids = sorted(defs, key=lambda k: int(k[7:] or "1"))
log("arcade definitions found:", ids)
def jstr(d):
    return json.dumps(d, separators=(",", ":"), ensure_ascii=True).replace("\\", "\\\\").replace('"', '\\"')
src = "package com.virtualapplications.play.akevo;\n\n/** Generated by apply_patches.py from Play!'s own arcadedefs folder. */\nfinal class AkDefs {\n    static final String[] IDS = {" + ", ".join('"%s"' % i for i in ids) + "};\n    static final String[] JSON = {\n" + ",\n".join('        "%s"' % jstr(defs[i]) for i in ids) + "\n    };\n}\n"
ak = [p for p in walk(".", r"^AkArcade\.java$")]
if not ak: die("AkArcade.java not found (overlay not copied?)")
wr(os.path.join(os.path.dirname(ak[0]), "AkDefs.java"), src)
log("AkDefs.java written next to", os.path.relpath(ak[0], PLAY))

# 8. app icon (Animal Kaiser logo) ------------------------------------------------------------------------------
lay = [p for p in walk(".", r"^emulator\.xml$") if os.path.basename(os.path.dirname(p)) == "layout" and "/deps/" not in p.replace(os.sep, "/")]
if not lay:
    log("WARNING: Play!'s res folder not found - app icon not changed")
else:
    resroot = os.path.dirname(os.path.dirname(lay[0]))
    shutil.copytree(os.path.join(ROOT, "icon", "res"), resroot, dirs_exist_ok=True)
    shutil.copytree(os.path.join(ROOT, "launcher_res"), resroot, dirs_exist_ok=True)   # wallpaper + launcher song
    log("launcher wallpaper + song copied")
    mt = rd(man)
    mt = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ak_launcher"', mt)
    mt = re.sub(r'android:roundIcon="[^"]*"', 'android:roundIcon="@mipmap/ak_launcher"', mt)
    if "android:icon=" not in mt: mt = mt.replace("<application", '<application android:icon="@mipmap/ak_launcher"', 1)
    if "android:roundIcon=" not in mt: mt = mt.replace("<application", '<application android:roundIcon="@mipmap/ak_launcher"', 1)
    wr(man, mt)
    log("app icon installed into", os.path.relpath(resroot, PLAY))
    for dp, dn, fns in os.walk(resroot):
        for fn in fns:
            if not fn.endswith(".xml") or fn.startswith("ak_"): continue
            fp = os.path.join(dp, fn); tx = rd(fp); nx = tx
            nx = re.sub(r'(<string name="app_name"[^>]*>)[^<]*(</string>)', r"\g<1>%s\2" % APP_NAME, nx)
            nx = nx.replace(">Play!<", ">%s<" % APP_NAME).replace('="Play!"', '="%s"' % APP_NAME)
            if nx != tx: wr(fp, nx); log("renamed Play! -> app name in", os.path.relpath(fp, PLAY))
    mt = rd(man); mt = re.sub(r'android:label="(@string/app_name|Play!?)"', 'android:label="%s"' % APP_NAME, mt); wr(man, mt)
    log("manifest labels renamed")

log("DONE - AkaiserEvodroid", VERSION)

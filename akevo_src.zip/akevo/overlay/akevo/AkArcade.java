package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;

/** Arcade support glue: embeds the Animal Kaiser Evolution definition, keeps the game file in app storage, boots through Play!'s ArcadeUtils. */
public final class AkArcade {
    public static final String GAME_ID = "akaievo";
    public static final String NAND_NAME = "kp012b_k9k8g08u0b.ic31";
    public static final String URL_DISCORD = "https://discord.gg/HaW3Gx6kG";
    public static final String URL_INSTAGRAM = "https://www.instagram.com/zull_bixie";
    public static final String URL_TIKTOK = "https://www.tiktok.com/@bixieredpixiu";

    public static String aboutText() {
        return "AKaiserEvodroid " + AkConfig.VERSION + "\n\n"
            + "An unofficial Android port of the arcade game Animal Kaiser, made by: zull.\n\n"
            + "Animal Kaiser and everything in the game (characters, artwork, music, name and logo) belong to Namco (now Bandai Namco), the original creator of the game. All rights reserved by their owners. This app is a fan-made port and is not affiliated with, sponsored or endorsed by Namco or Bandai Namco.\n\n"
            + "This app contains no game data. You must supply your own legally obtained game file.\n\n"
            + "Built on the open-source Play! PlayStation 2 emulator by Jean-Philip Desjardins and contributors.\n\n"
            + "Copyright of the port code (c) zull. Not for sale.";
    }

    public static void openLink(Context c, String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) { android.widget.Toast.makeText(c, "Could not open the link", android.widget.Toast.LENGTH_LONG).show(); }
    }

    private static boolean promptShown = false;
    private static boolean reported = false;


    private static native void nativeRegister(String defPath, String title);
    private static native void nativeBoot(String defPath, String romsDir, int port, boolean ioEnabled, int spuBlocks);
    private static native void nativeSetSpeed(int percent, boolean limiter);
    private static native int nativeGetSpuBlocks();
    private static native void nativeSetSpuBlocks(int blocks);

    /** Applies the saved game speed (EE clock scale, in percent) and frame-limiter setting. */
    public static void applySpeed(Context c) {
        try { nativeSetSpeed(AkConfig.speedPercent(c), AkConfig.limiter(c)); } catch (Throwable ignored) { }
    }

    /** Renderer: Auto = Vulkan when the phone supports it, otherwise OpenGL. Never forced; change it in Settings > Graphics. */
    public static void applyRenderer(Context c) {
        try {
            String mode = AkConfig.rendererMode(c); int r;
            if ("Vulkan".equals(mode)) r = 1;
            else if ("OpenGL".equals(mode)) r = 0;
            else {
                boolean vk = false;
                try { vk = c.getPackageManager().hasSystemFeature(android.content.pm.PackageManager.FEATURE_VULKAN_HARDWARE_VERSION, 0x400003); } catch (Throwable ignored) { }
                r = vk ? 1 : 0;
            }
            com.virtualapplications.play.SettingsManager.setPreferenceInteger("video.gshandler", r);
        } catch (Throwable t) { android.util.Log.w("AkArcade", "renderer not applied", t); }
    }

    public static int getSpuBlocks() { try { return nativeGetSpuBlocks(); } catch (Throwable t) { return -1; } }
    public static void setSpuBlocks(int blocks) { try { nativeSetSpuBlocks(blocks); } catch (Throwable ignored) { } }

    /** Small settings button on the game list, so the card server and audio options are reachable before a game starts. */
    private static void addGear(final Activity a) {
        try {
            android.widget.TextView g = new android.widget.TextView(a);
            g.setText("\u2699"); g.setTextSize(22); g.setTextColor(0xFFFFFFFF); g.setGravity(android.view.Gravity.CENTER);
            android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
            bg.setShape(android.graphics.drawable.GradientDrawable.OVAL); bg.setColor(0xCC37474F); g.setBackground(bg);
            float d = a.getResources().getDisplayMetrics().density; int sz = (int) (48 * d);
            android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(sz, sz, android.view.Gravity.BOTTOM | android.view.Gravity.START);
            lp.setMargins((int) (16 * d), 0, 0, (int) (16 * d));
            g.setOnClickListener(new android.view.View.OnClickListener() { public void onClick(android.view.View v) { a.startActivity(new Intent(a, AkSettingsActivity.class)); } });
            a.addContentView(g, lp);
        } catch (Throwable ignored) { }
    }


    private static File logFile(Context c) { return new File(c.getFilesDir(), "akevo_boot.log"); }
    private static File crashFile(Context c) { return new File(c.getFilesDir(), "akevo_crash.txt"); }

    private static String readFile(File f, int max) {
        try (FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[4096]; int n;
            while ((n = in.read(b)) > 0 && o.size() < max) o.write(b, 0, n);
            return o.toString("UTF-8");
        } catch (Exception e) { return ""; }
    }

    private static void installCrashLogger(final Context c) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() { public void uncaughtException(Thread t, Throwable e) {
            try { FileOutputStream o = new FileOutputStream(crashFile(c)); o.write(android.util.Log.getStackTraceString(e).getBytes("UTF-8")); o.close(); } catch (Throwable ignored) { }
            if (prev != null) prev.uncaughtException(t, e);
        } });
    }

    private static String lastExitInfo(Context c) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 30) return "";
            android.app.ActivityManager am = (android.app.ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
            java.util.List<android.app.ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(c.getPackageName(), 0, 1);
            if (l == null || l.isEmpty()) return "";
            android.app.ApplicationExitInfo e = l.get(0);
            int r = e.getReason();
            if (r != android.app.ApplicationExitInfo.REASON_CRASH && r != android.app.ApplicationExitInfo.REASON_CRASH_NATIVE
                && r != android.app.ApplicationExitInfo.REASON_ANR && r != android.app.ApplicationExitInfo.REASON_SIGNALED) return "";
            StringBuilder sb = new StringBuilder("Last exit: reason=" + r + " status=" + e.getStatus() + " " + e.getDescription() + "\n");
            try (java.io.InputStream in = e.getTraceInputStream()) {
                if (in != null) {
                    ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] b = new byte[8192]; int n;
                    while ((n = in.read(b)) > 0 && o.size() < 400000) o.write(b, 0, n);
                    byte[] d = o.toByteArray(); StringBuilder run = new StringBuilder(); int kept = 0;
                    for (int i = 0; i <= d.length && kept < 3500; i++) {
                        int ch = i < d.length ? (d[i] & 0xff) : 0;
                        if (ch >= 32 && ch < 127) run.append((char) ch);
                        else { String sRun = run.toString(); run.setLength(0);
                            if (sRun.length() >= 8 && (sRun.contains("lib") || sRun.contains("signal") || sRun.contains("Abort") || sRun.contains("SIG") || sRun.contains("fault"))) { sb.append(sRun).append('\n'); kept += sRun.length(); } }
                    }
                }
            } catch (Throwable ignored) { }
            return sb.toString();
        } catch (Throwable t) { return ""; }
    }

    private static void showLastProblem(final Activity a) {
        if (reported) return; reported = true;
        String crash = readFile(crashFile(a), 6000), boot = readFile(logFile(a), 3000), exit = lastExitInfo(a);
        boolean bootIncomplete = boot.length() > 0 && !boot.contains("DONE");
        if (crash.length() == 0 && exit.length() == 0 && !bootIncomplete) return;
        final StringBuilder sb = new StringBuilder("The app stopped last time. Please send this text to get it fixed.\n\n");
        if (exit.length() > 0) sb.append(exit).append('\n');
        if (boot.length() > 0) sb.append("--- boot steps ---\n").append(boot).append('\n');
        if (crash.length() > 0) sb.append("--- Java crash ---\n").append(crash).append('\n');
        crashFile(a).delete(); logFile(a).delete();
        try {
            new AlertDialog.Builder(a).setTitle("Crash report").setMessage(sb.toString())
                .setPositiveButton("Copy", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("crash report", sb.toString()));
                    android.widget.Toast.makeText(a, "Copied", android.widget.Toast.LENGTH_SHORT).show(); } })
                .setNegativeButton("Close", null).show();
        } catch (Throwable ignored) { }
    }

    private static File defsDir(Context c) { return new File(c.getFilesDir(), "arcadedefs"); }
    public static File defFile(Context c, String id) { return new File(defsDir(c), id + ".arcadedef"); }

    /** "akaievo" -> 1, "akaievo5" -> 5 */
    public static String titleOf(String id) { String n = id.substring(GAME_ID.length()); return "Animal Kaiser Evolution " + (n.length() == 0 ? "1" : n); }
    public static File romsRoot(Context c) { return new File(c.getFilesDir(), "arcaderoms"); }
    public static File romDir(Context c) { return new File(romsRoot(c), GAME_ID); }
    public static File nandFile(Context c) { return new File(romDir(c), NAND_NAME); }
    public static boolean hasNand(Context c) { File f = nandFile(c); return f.isFile() && f.length() > 1024 * 1024; }

    private static void writeText(File f, String text) throws Exception {
        f.getParentFile().mkdirs();
        FileOutputStream o = new FileOutputStream(f); o.write(text.getBytes("UTF-8")); o.close();
    }

    private static void writeDef(Context c) throws Exception {
        for (int i = 0; i < AkDefs.IDS.length; i++) writeText(defFile(c, AkDefs.IDS[i]), AkDefs.JSON[i]);   // children find their parent definition in this same folder
        romDir(c).mkdirs();
    }

    /** Called from MainActivity.onCreate: puts the game in the list, and asks for the game file if it is missing. */
    public static void register(final Activity a) {
        installCrashLogger(a);
        showLastProblem(a);
        try {
            writeDef(a);
            for (String id : AkDefs.IDS) nativeRegister(defFile(a, id).getAbsolutePath(), titleOf(id));
        } catch (Throwable t) { android.util.Log.w("AkArcade", "register failed", t); return; }
        AkLauncher.attach(a);
        if (!hasNand(a) && !promptShown) {
            promptShown = true;
            try {
                new AlertDialog.Builder(a).setTitle("Animal Kaiser Evolution")
                    .setMessage("Choose your game file (" + NAND_NAME + ") once. The app copies it into its own storage (about 1 GB), so keep some free space.")
                    .setPositiveButton("Choose file", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                        a.startActivity(new Intent(a, AkImportActivity.class)); } })
                    .setNegativeButton("Later", null).show();
            } catch (Throwable ignored) { }
        }
    }

    /** Called from VirtualMachineManager for *.arcadedef bootables. Throws with a readable message on failure. */
    public static void boot(Context c, String defPath) throws Exception {
        writeDef(c);
        if (!hasNand(c))
            throw new Exception("The game file " + NAND_NAME + " has not been imported yet. Restart the app and choose 'Choose file', or use Settings > Import.");
        applyRenderer(c);
        nativeBoot(defPath, romsRoot(c).getAbsolutePath(), AkConfig.port(c), AkConfig.ioEnabled(c), AkConfig.spuBlocks(c));
        applySpeed(c);
    }
}

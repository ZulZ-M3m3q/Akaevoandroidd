package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.os.Process;
import android.view.Window;
import android.view.WindowManager;
import java.io.File;

/** Small, safe performance helpers for the game screen (no emulator internals are touched). */
public final class AkPerf {
    private static boolean threadsBoosted = false;

    public static void boost(final Activity a) {
        if (!AkConfig.perfBoost(a)) return;
        // 1. Ask for a steady 60 Hz screen: on 90/120 Hz phones this avoids uneven frame pacing and saves heat.
        try {
            Window w = a.getWindow(); WindowManager.LayoutParams lp = w.getAttributes();
            lp.preferredRefreshRate = 60f; w.setAttributes(lp);
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) { }
        // 2. Give the emulator's worker threads a higher scheduling priority than ordinary background work.
        if (!threadsBoosted) {
            threadsBoosted = true;
            new Thread(new Runnable() { public void run() {
                try { Thread.sleep(2500); } catch (InterruptedException ignored) { }
                boostThreads();
            } }).start();
        }
    }

    private static void boostThreads() {
        try {
            File[] tasks = new File("/proc/self/task").listFiles();
            if (tasks == null) return;
            int main = Process.myPid();
            for (File f : tasks) {
                try {
                    int tid = Integer.parseInt(f.getName());
                    if (tid == main) continue;
                    if (Process.getThreadPriority(tid) >= 0) Process.setThreadPriority(tid, Process.THREAD_PRIORITY_URGENT_DISPLAY);
                } catch (Throwable ignored) { }
            }
        } catch (Throwable ignored) { }
    }

    /** Called when the game screen closes, so the next game starts fresh. */
    public static void reset() { threadsBoosted = false; }
}

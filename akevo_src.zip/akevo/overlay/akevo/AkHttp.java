package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Sends a card barcode to Play!'s built-in "Arcade I/O HTTP Server" (same device, loopback). */
public final class AkHttp {
    public interface Result { void done(boolean ok, String message); }

    public static void send(final Activity a, final String code, final Result cb) {
        new Thread(new Runnable() { public void run() {
            boolean ok = false; String msg;
            try {
                String path = AkConfig.path(a).replace("{code}", code);
                URL u = new URL("http://" + AkConfig.host(a) + ":" + AkConfig.port(a) + path);
                HttpURLConnection c = (HttpURLConnection) u.openConnection();
                c.setConnectTimeout(3000); c.setReadTimeout(3000);
                String method = AkConfig.method(a);
                c.setRequestMethod(method);
                if ("POST".equals(method) || "PUT".equals(method)) {
                    byte[] body = AkConfig.bodyTemplate(a).replace("{code}", code).getBytes("UTF-8");
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "text/plain");
                    OutputStream os = c.getOutputStream(); os.write(body); os.close();
                }
                int rc = c.getResponseCode();
                String text = "";
                try { InputStream is = rc < 400 ? c.getInputStream() : c.getErrorStream();
                      if (is != null) { byte[] b = new byte[512]; int n = is.read(b); if (n > 0) text = new String(b, 0, n, "UTF-8"); } } catch (Exception ignored) { }
                ok = rc >= 200 && rc < 300;
                msg = "HTTP " + rc + (text.length() > 0 ? " " + text.trim() : "") + "  -> " + u;
            } catch (Exception e) {
                msg = "Failed: " + e.getClass().getSimpleName() + " " + e.getMessage()
                    + "\nIs 'Arcade I/O HTTP Server' enabled in Play! settings, and is a game running?";
            }
            final boolean fok = ok; final String fmsg = msg;
            a.runOnUiThread(new Runnable() { public void run() {
                Toast.makeText(a, (fok ? "Card sent: " + code : "Card NOT sent") + "\n" + fmsg, Toast.LENGTH_LONG).show();
                if (cb != null) cb.done(fok, fmsg);
            }});
        }}).start();
    }
}

package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.List;

/** AkaiserEvodroid settings - replaces the arcade staff menu for day-to-day options. */
public class AkSettingsActivity extends Activity {
    private LinearLayout root;
    private int pad;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pad = (int) (14 * getResources().getDisplayMetrics().density);
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad, pad, pad, pad * 3);
        sv.addView(root);
        setContentView(sv);
        setTitle("AkaiserEvodroid " + AkConfig.VERSION + " – Settings");
        build();
    }

    private void build() {
        root.removeAllViews();
        head("AkaiserEvodroid " + AkConfig.VERSION);
        note("Settings menu (replaces the arcade staff menu). Close with Back to return to the game.");

        head("Game file");
        note(AkArcade.hasNand(this) ? "Game file imported." : "Game file NOT imported yet.");
        btn("Import game file (NAND)", new View.OnClickListener() { public void onClick(View v) {
            startActivity(new Intent(AkSettingsActivity.this, AkImportActivity.class)); } });

        head("Staff / service menu");
        note("The game's own staff menu is opened with the orange TEST (1) button on the touch overlay: hold it (or turn on Latch below) and use ▲ ▼ and OK. "
           + "One-time setup: Coin Options → Free Play = ON, Game Options → Card Dispenser = OFF.");
        sw("Latch TEST (tap once = hold, tap again = release)", AkConfig.latchTest(this), "latch_test");
        spin("OK button sends", new String[]{"A", "B", "X", "Y"}, AkConfig.confirmKey(this), "confirm_key");

        head("Touch controls");
        sw("Show on-screen buttons", AkConfig.overlayVisible(this), "overlay_visible");
        sw("Swap player 2 green / yellow (if the colours feel reversed in game)", AkConfig.swapP2(this), "swap_p2");
        sw("Always show \u25B2 \u25BC OK buttons (normally only while TEST is held)", AkConfig.showService(this), "show_service");
        sw("Vibrate on press", AkConfig.haptics(this), "haptics");
        seek("Opacity", AkConfig.opacity(this), 10, 100, "opacity");
        seek("Button size %", AkConfig.scale(this), 50, 200, "scale");
        profileRow();
        btn("Edit layout (drag buttons)", new View.OnClickListener() { public void onClick(View v) {
            AkConfig.editRequested = true; finish(); } });

        head("Card scanner");
        btn("Scan card with camera", new View.OnClickListener() { public void onClick(View v) {
            startActivity(new Intent(AkSettingsActivity.this, AkScanActivity.class)); } });
        final EditText code = new EditText(this); code.setHint("Type 8-character barcode"); code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        root.addView(code);
        btn("Send typed barcode", new View.OnClickListener() { public void onClick(View v) {
            String s = code.getText().toString().trim(); if (s.length() > 0) AkHttp.send(AkSettingsActivity.this, s, null); } });

        head("Card server (Arcade I/O)");
        note("The game receives scanned cards through a small built-in server. Keep it ON. Changes apply the next time you start a game.");
        sw("Arcade I/O HTTP server", AkConfig.ioEnabled(this), "io_enabled");
        field("Server port", String.valueOf(AkConfig.port(this)), "port", true);
        btn("Test card server (game must be running)", new View.OnClickListener() { public void onClick(View v) {
            AkHttp.test(AkSettingsActivity.this, null); } });
        btn("Show server log", new View.OnClickListener() { public void onClick(View v) {
            new AlertDialog.Builder(AkSettingsActivity.this).setTitle("Card server log").setMessage(AkHttp.serverLog(AkSettingsActivity.this)).setPositiveButton(android.R.string.ok, null).show(); } });

        head("Graphics");
        note("Renderer: OpenGL is the most compatible. Vulkan can remove the thin lines some phones show, but needs a stronger phone and may not work on every device. If the game does not start, set this back to OpenGL. Applies the next time you start the game.");
        spin("Renderer", new String[]{"OpenGL", "Vulkan"}, AkConfig.rendererMode(this), "renderer_mode");

        head("Audio");
        sw("Mute launcher song (the song only plays in the launcher, never in the game)", AkConfig.muteSong(this), "mute_song");
        int cur = AkArcade.getSpuBlocks();
        int start = AkConfig.spuBlocks(this) > 0 ? AkConfig.spuBlocks(this) : (cur > 0 ? cur : 100);
        note("Audio buffer (SPU block count): bigger = fewer crackles but a little more delay. " + (cur > 0 ? "Play! is currently using " + cur + "." : "Start a game to see the current value."));
        final TextView at = new TextView(this); at.setText("Audio buffer: " + start); root.addView(at);
        SeekBar asb = new SeekBar(this); asb.setMax(390); asb.setProgress(Math.max(0, Math.min(390, start - 10)));
        asb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar x, int p, boolean u) { at.setText("Audio buffer: " + (p + 10)); }
            public void onStartTrackingTouch(SeekBar x) { }
            public void onStopTrackingTouch(SeekBar x) { int val = x.getProgress() + 10; AkConfig.put(AkSettingsActivity.this, "spu_blocks", val); AkArcade.setSpuBlocks(val); } });
        root.addView(asb);

        head("Advanced card settings");
        note("Normally leave these alone. Found from Play!'s source: POST /sys147/barcode with the 8-character code as the body.");
        field("Host", AkConfig.host(this), "host", false);
        field("URL path ({code} allowed)", AkConfig.path(this), "path", false);
        spin("HTTP method", new String[]{"POST", "GET", "PUT"}, AkConfig.method(this), "method");
        field("Body template ({code})", AkConfig.bodyTemplate(this), "body", false);

        head("About");
        note(AkArcade.aboutText());
    }

    // ---------- tiny UI helpers ----------
    private void head(String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(18); t.setPadding(0, pad, 0, pad / 3); t.setTypeface(null, android.graphics.Typeface.BOLD); root.addView(t); }
    private void note(String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(13); t.setPadding(0, 0, 0, pad / 2); root.addView(t); }
    private void btn(String s, View.OnClickListener l) { Button x = new Button(this); x.setText(s); x.setAllCaps(false); x.setOnClickListener(l); root.addView(x); }
    private void sw(String s, boolean v, final String key) {
        Switch x = new Switch(this); x.setText(s); x.setChecked(v); x.setPadding(0, pad / 3, 0, pad / 3);
        x.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { public void onCheckedChanged(CompoundButton c, boolean on) { AkConfig.put(AkSettingsActivity.this, key, on); } });
        root.addView(x);
    }
    private void seek(String s, int v, final int min, int max, final String key) {
        final TextView t = new TextView(this); t.setText(s + ": " + v); root.addView(t);
        SeekBar sb = new SeekBar(this); sb.setMax(max - min); sb.setProgress(v - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar x, int p, boolean u) { int val = p + min; t.setText(t.getText().toString().replaceAll(":.*", ": " + val)); AkConfig.put(AkSettingsActivity.this, key, val); }
            public void onStartTrackingTouch(SeekBar x) { } public void onStopTrackingTouch(SeekBar x) { } });
        root.addView(sb);
    }
    private void spin(String s, final String[] opts, String cur, final String key) {
        TextView t = new TextView(this); t.setText(s); root.addView(t);
        Spinner sp = new Spinner(this); sp.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, opts));
        for (int i = 0; i < opts.length; i++) if (opts[i].equals(cur)) sp.setSelection(i);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { AkConfig.put(AkSettingsActivity.this, key, opts[pos]); }
            public void onNothingSelected(AdapterView<?> p) { } });
        root.addView(sp);
    }
    private void field(String s, String cur, final String key, final boolean numeric) {
        TextView t = new TextView(this); t.setText(s); root.addView(t);
        final EditText e = new EditText(this); e.setText(cur); e.setSingleLine(true);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setOnFocusChangeListener(new View.OnFocusChangeListener() { public void onFocusChange(View v, boolean f) {
            if (f) return; String val = e.getText().toString();
            if (numeric) { try { AkConfig.put(AkSettingsActivity.this, key, Integer.parseInt(val.trim())); } catch (Exception ignored) { } }
            else AkConfig.put(AkSettingsActivity.this, key, val); } });
        root.addView(e);
    }
    @Override protected void onPause() { super.onPause(); View f = getCurrentFocus(); if (f != null) f.clearFocus(); }

    private void profileRow() {
        TextView t = new TextView(this); t.setText("Layout profile: " + AkConfig.activeProfile(this)); root.addView(t);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button sel = new Button(this); sel.setText("Choose"); sel.setAllCaps(false);
        sel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            final List<String> n = AkConfig.profileNames(AkSettingsActivity.this);
            new AlertDialog.Builder(AkSettingsActivity.this).setTitle("Layout profile")
                .setItems(n.toArray(new String[0]), new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                    AkConfig.setActiveProfile(AkSettingsActivity.this, n.get(w)); build(); } }).show(); } });
        Button nw = new Button(this); nw.setText("New"); nw.setAllCaps(false);
        nw.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            final EditText in = new EditText(AkSettingsActivity.this); in.setHint("Profile name");
            new AlertDialog.Builder(AkSettingsActivity.this).setTitle("New profile (copy of current)").setView(in)
                .setPositiveButton("Create", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                    String name = in.getText().toString().trim(); if (name.length() == 0) return;
                    AkConfig.saveLayout(AkSettingsActivity.this, name, AkConfig.activeLayout(AkSettingsActivity.this));
                    AkConfig.setActiveProfile(AkSettingsActivity.this, name); build(); } })
                .setNegativeButton("Cancel", null).show(); } });
        Button del = new Button(this); del.setText("Delete"); del.setAllCaps(false);
        del.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            AkConfig.deleteProfile(AkSettingsActivity.this, AkConfig.activeProfile(AkSettingsActivity.this)); build(); } });
        row.addView(sel); row.addView(nw); row.addView(del); root.addView(row);
    }
}

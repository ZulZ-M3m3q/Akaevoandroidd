package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.List;

/** AkaiserEvodroid settings - replaces the arcade staff menu for day-to-day options. */
public class AkSettingsActivity extends Activity {
    private LinearLayout root;
    private int pad;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        pad = (int) (14 * getResources().getDisplayMetrics().density);
        ScrollView sv = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(pad, pad, pad, pad * 3);
        sv.addView(root);
        setContentView(sv);
        setTitle("AkaiserEvodroid " + AkConfig.VERSION + " – Settings");
        build();
    }

    private void build() {
        root.removeAllViews();
        head("AkaiserEvodroid " + AkConfig.VERSION);
        note("Settings menu (replaces the arcade staff menu). Close with Back to return to the game.");

        head("Staff / service menu");
        note("The game's own staff menu is opened with the orange TEST (1) button on the touch overlay: hold it (or turn on Latch below) and use ▲ ▼ and OK. "
           + "One-time setup: Coin Options → Free Play = ON, Game Options → Card Dispenser = OFF.");
        sw("Latch TEST (tap once = hold, tap again = release)", AkConfig.latchTest(this), "latch_test");
        spin("OK button sends", new String[]{"A", "B", "X", "Y"}, AkConfig.confirmKey(this), "confirm_key");

        head("Touch controls");
        sw("Show on-screen buttons", AkConfig.overlayVisible(this), "overlay_visible");
        sw("Vibrate on press", AkConfig.haptics(this), "haptics");
        seek("Opacity", AkConfig.opacity(this), 10, 100, "opacity");
        seek("Button size %", AkConfig.scale(this), 50, 200, "scale");
        profileRow();
        btn("Edit layout (drag buttons)", new View.OnClickListener() { public void onClick(View v) {
            AkConfig.editRequested = true; finish(); } });

        head("Card scanner");
        btn("Scan card with camera", new View.OnClickListener() { public void onClick(View v) {
            startActivity(new Intent(AkSettingsActivity.this, AkScanActivity.class)); } });
        final EditText code = new EditText(this); code.setHint("Type 8-character barcode"); code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        root.addView(code);
        btn("Send typed barcode", new View.OnClickListener() { public void onClick(View v) {
            String s = code.getText().toString().trim(); if (s.length() > 0) AkHttp.send(AkSettingsActivity.this, s, null); } });
        note(AkDefaults.DETECTED ? "Endpoint values below were detected from Play!'s source at build time."
                                  : "Endpoint values below are DEFAULTS (not detected). If card sends fail, check the build log and adjust here.");
        field("Host", AkConfig.host(this), "host", false);
        field("Port", String.valueOf(AkConfig.port(this)), "port", true);
        field("URL path ({code} allowed)", AkConfig.path(this), "path", false);
        spin("HTTP method", new String[]{"POST", "GET", "PUT"}, AkConfig.method(this), "method");
        field("Body template ({code})", AkConfig.bodyTemplate(this), "body", false);
        btn("Test connection (sends 00000000)", new View.OnClickListener() { public void onClick(View v) {
            AkHttp.send(AkSettingsActivity.this, "00000000", null); } });
        note("Also enable \"Arcade I/O HTTP Server\" in Play!'s own settings (once). Cards only register while the game is running and at its scan screen.");

        head("About");
        note("AkaiserEvodroid " + AkConfig.VERSION + " – first test build. Based on the open-source Play! PS2 emulator. No game data is included; you supply your own legally obtained Animal Kaiser Evolution NAND.");
    }

    // ---------- tiny UI helpers ----------
    private void head(String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(18); t.setPadding(0, pad, 0, pad / 3); t.setTypeface(null, android.graphics.Typeface.BOLD); root.addView(t); }
    private void note(String s) { TextView t = new TextView(this); t.setText(s); t.setTextSize(13); t.setPadding(0, 0, 0, pad / 2); root.addView(t); }
    private void btn(String s, View.OnClickListener l) { Button x = new Button(this); x.setText(s); x.setAllCaps(false); x.setOnClickListener(l); root.addView(x); }
    private void sw(String s, boolean v, final String key) {
        Switch x = new Switch(this); x.setText(s); x.setChecked(v); x.setPadding(0, pad / 3, 0, pad / 3);
        x.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { public void onCheckedChanged(CompoundButton c, boolean on) { AkConfig.put(AkSettingsActivity.this, key, on); } });
        root.addView(x);
    }
    private void seek(String s, int v, final int min, int max, final String key) {
        final TextView t = new TextView(this); t.setText(s + ": " + v); root.addView(t);
        SeekBar sb = new SeekBar(this); sb.setMax(max - min); sb.setProgress(v - min);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar x, int p, boolean u) { int val = p + min; t.setText(t.getText().toString().replaceAll(":.*", ": " + val)); AkConfig.put(AkSettingsActivity.this, key, val); }
            public void onStartTrackingTouch(SeekBar x) { } public void onStopTrackingTouch(SeekBar x) { } });
        root.addView(sb);
    }
    private void spin(String s, final String[] opts, String cur, final String key) {
        TextView t = new TextView(this); t.setText(s); root.addView(t);
        Spinner sp = new Spinner(this); sp.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, opts));
        for (int i = 0; i < opts.length; i++) if (opts[i].equals(cur)) sp.setSelection(i);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { AkConfig.put(AkSettingsActivity.this, key, opts[pos]); }
            public void onNothingSelected(AdapterView<?> p) { } });
        root.addView(sp);
    }
    private void field(String s, String cur, final String key, final boolean numeric) {
        TextView t = new TextView(this); t.setText(s); root.addView(t);
        final EditText e = new EditText(this); e.setText(cur); e.setSingleLine(true);
        if (numeric) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setOnFocusChangeListener(new View.OnFocusChangeListener() { public void onFocusChange(View v, boolean f) {
            if (f) return; String val = e.getText().toString();
            if (numeric) { try { AkConfig.put(AkSettingsActivity.this, key, Integer.parseInt(val.trim())); } catch (Exception ignored) { } }
            else AkConfig.put(AkSettingsActivity.this, key, val); } });
        root.addView(e);
    }
    @Override protected void onPause() { super.onPause(); View f = getCurrentFocus(); if (f != null) f.clearFocus(); }

    private void profileRow() {
        TextView t = new TextView(this); t.setText("Layout profile: " + AkConfig.activeProfile(this)); root.addView(t);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button sel = new Button(this); sel.setText("Choose"); sel.setAllCaps(false);
        sel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            final List<String> n = AkConfig.profileNames(AkSettingsActivity.this);
            new AlertDialog.Builder(AkSettingsActivity.this).setTitle("Layout profile")
                .setItems(n.toArray(new String[0]), new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                    AkConfig.setActiveProfile(AkSettingsActivity.this, n.get(w)); build(); } }).show(); } });
        Button nw = new Button(this); nw.setText("New"); nw.setAllCaps(false);
        nw.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            final EditText in = new EditText(AkSettingsActivity.this); in.setHint("Profile name");
            new AlertDialog.Builder(AkSettingsActivity.this).setTitle("New profile (copy of current)").setView(in)
                .setPositiveButton("Create", new DialogInterface.OnClickListener() { public void onClick(DialogInterface d, int w) {
                    String name = in.getText().toString().trim(); if (name.length() == 0) return;
                    AkConfig.saveLayout(AkSettingsActivity.this, name, AkConfig.activeLayout(AkSettingsActivity.this));
                    AkConfig.setActiveProfile(AkSettingsActivity.this, name); build(); } })
                .setNegativeButton("Cancel", null).show(); } });
        Button del = new Button(this); del.setText("Delete"); del.setAllCaps(false);
        del.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
            AkConfig.deleteProfile(AkSettingsActivity.this, AkConfig.activeProfile(AkSettingsActivity.this)); build(); } });
        row.addView(sel); row.addView(nw); row.addView(del); root.addView(row);
    }
}

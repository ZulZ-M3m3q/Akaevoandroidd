package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.content.Context;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.KeyEvent;
import java.util.HashSet;
import java.util.Set;

/** Sends gamepad key events into Play!'s emulator activity. TEST = PS2 L1: the Animal Kaiser arcade definition maps its TEST input to L1. */
public final class AkInput {
    private static final Set<Integer> held = new HashSet<Integer>();

    public static int[] codes(Context c, String id) {
        if ("LEFT".equals(id))  return new int[]{KeyEvent.KEYCODE_DPAD_LEFT};
        if ("RIGHT".equals(id)) return new int[]{KeyEvent.KEYCODE_DPAD_RIGHT};
        if ("UP".equals(id))    return new int[]{KeyEvent.KEYCODE_DPAD_UP};
        if ("DOWN".equals(id))  return new int[]{KeyEvent.KEYCODE_DPAD_DOWN};
        // Player 2 buttons use PS2 SQUARE (green) / CIRCLE (yellow) on pad 1's behalf: the build remaps the arcade definition's player-2 inputs to these.
        if ("P2G".equals(id) || "P2Y".equals(id)) {
            boolean green = "P2G".equals(id); if (AkConfig.swapP2(c)) green = !green;
            return new int[]{green ? KeyEvent.KEYCODE_BUTTON_X : KeyEvent.KEYCODE_BUTTON_B};
        }
        if ("COIN".equals(id))  return new int[]{KeyEvent.KEYCODE_BUTTON_SELECT};
        if ("START".equals(id)) return new int[]{KeyEvent.KEYCODE_BUTTON_START};
        if ("TEST".equals(id))  return new int[]{KeyEvent.KEYCODE_BUTTON_L1};
        if ("OK".equals(id)) {
            String k = AkConfig.confirmKey(c);
            if ("B".equals(k)) return new int[]{KeyEvent.KEYCODE_BUTTON_B};
            if ("X".equals(k)) return new int[]{KeyEvent.KEYCODE_BUTTON_X};
            if ("Y".equals(k)) return new int[]{KeyEvent.KEYCODE_BUTTON_Y};
            return new int[]{KeyEvent.KEYCODE_BUTTON_A};
        }
        return new int[0];
    }

    public static void set(Activity a, String id, boolean down) {
        for (int code : codes(a, id)) send(a, code, down);
    }

    private static void send(Activity a, int code, boolean down) {
        synchronized (held) { if (down) held.add(code); else held.remove(code); }
        try {
            long t = SystemClock.uptimeMillis();
            KeyEvent e = new KeyEvent(t, t, down ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP, code, 0, 0, -1, 0, 0, InputDevice.SOURCE_GAMEPAD);
            a.dispatchKeyEvent(e);
        } catch (Throwable ignored) { /* never crash the game because of an overlay press */ }
    }

    /** Release everything (called when overlay pauses / edit mode starts). */
    public static void releaseAll(Activity a) {
        Integer[] copy; synchronized (held) { copy = held.toArray(new Integer[0]); }
        for (int c : copy) send(a, c, false);
    }
}

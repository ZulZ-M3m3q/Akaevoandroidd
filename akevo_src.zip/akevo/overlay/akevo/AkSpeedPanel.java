package com.virtualapplications.play.akevo;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** In-game panel (scrollable): game speed presets + frame limiter switch. */
public final class AkSpeedPanel {
    private static final int[] PRESETS = {25, 50, 60, 70, 80, 90, 100, 110, 125, 150, 200};

    public static void show(final Activity a) {
        try {
            final float d = a.getResources().getDisplayMetrics().density;
            LinearLayout col = new LinearLayout(a); col.setOrientation(LinearLayout.VERTICAL); col.setPadding((int) (18 * d), (int) (10 * d), (int) (18 * d), (int) (10 * d));
            TextView hint = new TextView(a);
            hint.setText("Game speed (emulated CPU speed). Lower = lighter for your phone, but the game can run slower. 100% is normal. Scroll for more options.");
            hint.setTextSize(13); col.addView(hint);

            final RadioGroup g = new RadioGroup(a); g.setOrientation(RadioGroup.VERTICAL);
            int cur = AkConfig.speedPercent(a);
            for (int p : PRESETS) {
                RadioButton r = new RadioButton(a); r.setId(1000 + p);
                r.setText(p + "%" + (p == 100 ? "  (normal)" : p < 100 ? "  (slower)" : "  (faster)")); r.setTextSize(16);
                g.addView(r, new RadioGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (46 * d)));
                if (p == cur) r.setChecked(true);
            }
            g.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { public void onCheckedChanged(RadioGroup grp, int id) {
                AkConfig.put(a, "speed_percent", id - 1000); AkArcade.applySpeed(a); } });
            col.addView(g);

            final Switch lim = new Switch(a); lim.setText("Frame limiter (turn OFF for unlimited / turbo)"); lim.setChecked(AkConfig.limiter(a)); lim.setPadding(0, (int) (10 * d), 0, (int) (10 * d));
            lim.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { public void onCheckedChanged(CompoundButton b, boolean on) {
                AkConfig.put(a, "limiter", on); AkArcade.applySpeed(a); } });
            col.addView(lim);

            Button reset = new Button(a); reset.setText("Reset to normal (100%, limiter on)"); reset.setAllCaps(false);
            reset.setOnClickListener(new View.OnClickListener() { public void onClick(View v) {
                AkConfig.put(a, "speed_percent", 100); AkConfig.put(a, "limiter", true); lim.setChecked(true); g.check(1100); AkArcade.applySpeed(a); } });
            col.addView(reset);

            ScrollView sv = new ScrollView(a); sv.addView(col);
            new AlertDialog.Builder(a).setTitle("Game speed").setView(sv).setPositiveButton("Close", null).show();
        } catch (Throwable t) { android.widget.Toast.makeText(a, "Speed panel failed: " + t, android.widget.Toast.LENGTH_LONG).show(); }
    }
}

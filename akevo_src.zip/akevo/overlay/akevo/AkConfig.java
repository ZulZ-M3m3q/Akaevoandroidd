package com.virtualapplications.play.akevo;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** All AkaiserEvodroid settings + button-layout profiles (stored in SharedPreferences). */
public final class AkConfig {
    public static final String VERSION = "A.3";
    public static boolean editRequested = false;   // set by settings, consumed by overlay on resume

    public static final class Btn {
        public String id, label;
        public float x, y;     // centre, fraction of screen (0..1)
        public float size;     // diameter in dp
        public Btn(String id, String label, float x, float y, float size) {
            this.id = id; this.label = label; this.x = x; this.y = y; this.size = size;
        }
        public Btn copy() { return new Btn(id, label, x, y, size); }
    }

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("akevo", Context.MODE_PRIVATE); }

    // ---------- simple settings ----------
    public static int opacity(Context c) { return sp(c).getInt("opacity", 70); }
    public static int scale(Context c) { return sp(c).getInt("scale", 100); }
    public static boolean haptics(Context c) { return sp(c).getBoolean("haptics", true); }
    public static boolean latchTest(Context c) { return sp(c).getBoolean("latch_test", true); }
    public static boolean ioEnabled(Context c) { return sp(c).getBoolean("io_enabled", true); }
    public static int spuBlocks(Context c) { return sp(c).getInt("spu_blocks", 0); }
    public static boolean showService(Context c) { return sp(c).getBoolean("show_service", false); }
    public static boolean overlayVisible(Context c) { return sp(c).getBoolean("overlay_visible", true); }
    public static String confirmKey(Context c) { return sp(c).getString("confirm_key", "A"); }
    public static String host(Context c) { return sp(c).getString("host", "127.0.0.1"); }
    public static int port(Context c) { return sp(c).getInt("port", AkDefaults.PORT); }
    public static String path(Context c) { return sp(c).getString("path", AkDefaults.PATH); }
    public static String method(Context c) { return sp(c).getString("method", AkDefaults.METHOD); }
    public static String bodyTemplate(Context c) { return sp(c).getString("body", AkDefaults.BODY); }
    public static void put(Context c, String k, Object v) {
        SharedPreferences.Editor e = sp(c).edit();
        if (v instanceof Integer) e.putInt(k, (Integer) v);
        else if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else e.putString(k, String.valueOf(v));
        e.apply();
    }

    // ---------- layouts ----------
    public static List<Btn> defaultLayout(boolean leftHanded) {
        List<Btn> l = new ArrayList<Btn>();
        float dx = leftHanded ? 1f : 0f;
        // The two big game buttons sit in the black side bars: green on the left, yellow on the right.
        l.add(new Btn("LEFT",  "",      mx(0.10f, dx), 0.74f, 100));
        l.add(new Btn("RIGHT", "",      mx(0.90f, dx), 0.74f, 100));
        l.add(new Btn("COIN",  "COIN",  mx(0.07f, dx), 0.13f, 50));
        l.add(new Btn("START", "START", mx(0.07f, dx), 0.33f, 50));
        // Service buttons: only shown while TEST is held / latched (or when switched on in Settings).
        l.add(new Btn("UP",    "\u25B2", mx(0.06f, dx), 0.50f, 44));
        l.add(new Btn("DOWN",  "\u25BC", mx(0.15f, dx), 0.50f, 44));
        l.add(new Btn("OK",    "OK",    mx(0.105f, dx), 0.62f, 48));
        l.add(new Btn("SET",   "\u2699", mx(0.94f, dx), 0.09f, 44));
        l.add(new Btn("SCAN",  "CARD",  mx(0.92f, dx), 0.32f, 56));
        l.add(new Btn("TEST",  "1\nTEST", mx(0.92f, dx), 0.52f, 52));
        return l;
    }
    private static float mx(float x, float mirror) { return mirror > 0 ? 1f - x : x; }

    public static String activeProfile(Context c) { return sp(c).getString("active_profile", "Default"); }
    public static void setActiveProfile(Context c, String n) { put(c, "active_profile", n); }

    private static JSONObject profiles(Context c) {
        try { return new JSONObject(sp(c).getString("profiles", "{}")); } catch (Exception e) { return new JSONObject(); }
    }
    public static List<String> profileNames(Context c) {
        List<String> n = new ArrayList<String>(); n.add("Default"); n.add("Left-handed");
        Iterator<String> it = profiles(c).keys();
        while (it.hasNext()) { String k = it.next(); if (!n.contains(k)) n.add(k); }
        return n;
    }
    public static List<Btn> layout(Context c, String name) {
        try {
            JSONArray a = profiles(c).optJSONArray(name);
            if (a != null) {
                List<Btn> l = new ArrayList<Btn>();
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    l.add(new Btn(o.getString("id"), o.getString("label"), (float) o.getDouble("x"), (float) o.getDouble("y"), (float) o.getDouble("size")));
                }
                return l;
            }
        } catch (Exception ignored) { }
        return defaultLayout("Left-handed".equals(name));
    }
    public static List<Btn> activeLayout(Context c) { return layout(c, activeProfile(c)); }
    public static void saveLayout(Context c, String name, List<Btn> l) {
        try {
            JSONArray a = new JSONArray();
            for (Btn b : l) {
                JSONObject o = new JSONObject();
                o.put("id", b.id); o.put("label", b.label); o.put("x", b.x); o.put("y", b.y); o.put("size", b.size);
                a.put(o);
            }
            JSONObject all = profiles(c); all.put(name, a);
            sp(c).edit().putString("profiles", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    public static void deleteProfile(Context c, String name) {
        JSONObject all = profiles(c); all.remove(name);
        sp(c).edit().putString("profiles", all.toString()).apply();
        if (name.equals(activeProfile(c))) setActiveProfile(c, "Default");
    }
}

#!/usr/bin/env python3
"""AkaiserEvodroid A.1 patcher for a fresh checkout of jpd002/Play-.
Every step is verified; ANY problem aborts with a clear message (exit code 1) so the build never continues half-patched."""
import os, re, sys, shutil, glob

PLAY = os.path.abspath(sys.argv[1]); HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
APP_ID, APP_NAME, VERSION = "com.akaiser.evodroid", "AkaiserEvodroid", "A.2"
SKIP = {"build", ".git", "Dependencies", "node_modules", ".gradle", ".cxx", ".idea"}
def log(*a): print("[akevo]", *a, flush=True)
def die(m, extra=None):
    print("[akevo] ERROR:", m, flush=True)
    if extra: print(extra, flush=True)
    sys.exit(1)
def rd(p): return open(p, encoding="utf-8", errors="surrogateescape").read()
def wr(p, s): open(p, "w", encoding="utf-8", errors="surrogateescape").write(s)
def walk(sub, pat):
    for r, d, f in os.walk(os.path.join(PLAY, sub)):
        d[:] = [x for x in d if x not in SKIP]
        for n in f:
            if re.search(pat, n): yield os.path.join(r, n)
def rel(p): return os.path.relpath(p, PLAY)

# ---- 0. project layout report (always printed, helps diagnose future failures) ---------------------
BA = os.path.join(PLAY, "build_android")
if not os.path.isdir(BA): die("build_android/ not found in the Play! checkout", "top level: " + ", ".join(sorted(os.listdir(PLAY))))
log("build_android contents:", ", ".join(sorted(os.listdir(BA))))
log("manifests found:", [rel(p) for p in walk(".", r"^AndroidManifest\.xml$")])
log("gradle files found:", [rel(p) for p in walk("build_android", r"^build\.gradle(\.kts)?$")])

# ---- 1. overlay sources ---------------------------------------------------------------------------------
emu = list(walk("Source", r"^EmulatorActivity\.java$"))
if not emu: die("EmulatorActivity.java not found (Play! layout changed)")
jdir = os.path.dirname(emu[0]); dst = os.path.join(jdir, "akevo"); os.makedirs(dst, exist_ok=True)
need = ["AkConfig", "AkInput", "AkHttp", "AkPadView", "AkOverlay", "AkSettingsActivity", "AkScanActivity"]
for n in need:
    s = os.path.join(ROOT, "overlay", "akevo", n + ".java")
    if not os.path.exists(s): die("overlay source missing: " + s)
    shutil.copy(s, dst)
log("copied", len(need), "overlay classes to", rel(dst))

# ---- 2. card-scan endpoint discovery (informational + defaults) ----------------------------------------
port, path, method, body, detected = 8080, "/", "POST", "{code}", False
src_files = [p for p in walk("Source", r"\.(cpp|h|hpp|java)$") if "/akevo/" not in p.replace(os.sep, "/")]
hits = []
for p in src_files:
    try: s = rd(p)
    except Exception: continue
    if re.search(r"HttpServer", s) and re.search(r"namco|sys147|barcode|arcade", p + s[:4000], re.I): hits.append((p, s))
log("AKEVO endpoint scan: %d candidate file(s) mention an HTTP server" % len(hits))
for p, s in hits:
    log("  file:", rel(p))
    for i, line in enumerate(s.splitlines()):
        if re.search(r"(?i)barcode|HttpServer|http|port\b|\"/[A-Za-z_/]*\"", line) and len(line) < 220:
            print("    %5d: %s" % (i + 1, line.strip()), flush=True)
    m = re.search(r"CHttpServer\s*>?\s*(?:\w+\s*)?[\(\{]\s*(\d{3,5})", s) or re.search(r"(?i)http\w*port\w*\s*[=:\(]\s*(\d{3,5})", s)
    if m: port = int(m.group(1)); detected = True; log("  -> port", port)
    m = re.search(r"url\.find\(\s*\"(/[A-Za-z0-9_/\-]*barcode[A-Za-z0-9_/\-]*)\"", s)
    if m: path = m.group(1); detected = True; log("  -> barcode route", path)
# default port of the 'Arcade I/O HTTP Server' preference, if Play! registers one
for p2 in walk("Source", r"\.(cpp|h)$"):
    try: s2 = rd(p2)
    except Exception: continue
    m = re.search(r"PREF_PS2_ARCADE_IO_SERVER_PORT\s*,\s*(\d{3,5})", s2)
    if m: port = int(m.group(1)); log("  -> default I/O server port", port, "from", rel(p2)); break
tmpl = rd(os.path.join(ROOT, "overlay", "akevo", "AkDefaults.java.template"))
wr(os.path.join(dst, "AkDefaults.java"), tmpl.replace("@PORT@", str(port)).replace("@PATH@", path).replace("@METHOD@", method).replace("@BODY@", body).replace("@DETECTED@", "true" if detected else "false"))
log("endpoint defaults: %s 127.0.0.1:%d%s detected=%s (Settings -> 'Find endpoint automatically' can correct this)" % (method, port, path, detected))

# ---- 3. hook overlay into EmulatorActivity.onCreate ---------------------------------------------------
HOOK = "com.virtualapplications.play.akevo.AkOverlay.attach(this);"
s = rd(emu[0])
if HOOK not in s:
    m = re.search(r"super\.onCreate\([^;]*\);", s)
    if not m: die("super.onCreate(...) not found in EmulatorActivity.java")
    s = s[:m.end()] + "\n\t\t" + HOOK + s[m.end():]; wr(emu[0], s)
log("hooked", rel(emu[0]))

# ---- 4. manifest ------------------------------------------------------------------------------------------
cands = [os.path.join(BA, "src", "main", "AndroidManifest.xml")] + list(walk("build_android", r"^AndroidManifest\.xml$")) + list(walk("Source", r"^AndroidManifest\.xml$"))
man = next((p for p in cands if os.path.exists(p) and "<application" in rd(p)), None)
if not man: die("no AndroidManifest.xml containing <application> found", "looked at: %s" % [rel(p) for p in cands])
m = rd(man)
if "AkSettingsActivity" not in m:
    acts = ('\n\t\t<activity android:name="com.virtualapplications.play.akevo.AkSettingsActivity" android:exported="false" android:label="%s Settings" android:theme="@android:style/Theme.Material.Light.NoActionBar" />'
            '\n\t\t<activity android:name="com.virtualapplications.play.akevo.AkScanActivity" android:exported="false" android:theme="@style/Theme.AppCompat.NoActionBar" />\n\t' % APP_NAME)
    if "</application>" not in m:                                   # tolerate a self-closing <application ... />
        m, k = re.subn(r"(<application\b[^>]*?)\s*/>", r"\1></application>", m, 1, flags=re.S)
        if not k: die("</application> missing in " + rel(man))
    m = m.replace("</application>", acts + "</application>", 1)
    add = ""
    for pm in ("android.permission.CAMERA", "android.permission.INTERNET", "android.permission.VIBRATE"):
        if pm not in m: add += '\n\t<uses-permission android:name="%s" />' % pm
    if "android.hardware.camera" not in m: add += '\n\t<uses-feature android:name="android.hardware.camera" android:required="false" />'
    m2 = re.sub(r"(<manifest\b[^>]*>)", lambda x: x.group(1) + add, m, 1, flags=re.S)
    if m2 == m and add: die("could not locate <manifest ...> tag to add permissions")
    m = m2
    m = re.sub(r'(<application\b[^>]*?android:label=")[^"]*(")', r"\g<1>%s\2" % APP_NAME, m, 1, flags=re.S)
    wr(man, m)
if "AkScanActivity" not in rd(man): die("manifest patch did not apply")
log("manifest patched:", rel(man))

# ---- 5. app name -------------------------------------------------------------------------------------------
n = 0
for p in walk("build_android", r"\.xml$"):
    if "/res/values" not in p.replace(os.sep, "/"): continue
    t = rd(p)
    if 'name="app_name"' in t:
        wr(p, re.sub(r'(<string\b[^>]*name="app_name"[^>]*>)[^<]*(</string>)', r"\g<1>%s\2" % APP_NAME, t)); n += 1
log("app_name updated in %d resource file(s)" % n)

# ---- 6. Gradle: id, version, ABI, SDK levels, dependencies -------------------------------------------
# Play! may keep the app module in build_android/ or elsewhere, and (with new Android Gradle Plugin versions)
# may NOT contain an explicit applicationId at all. So: find the *application* module, then replace OR insert.
gcands = [os.path.join(BA, "build.gradle"), os.path.join(BA, "build.gradle.kts")] + list(walk("build_android", r"^build\.gradle(\.kts)?$")) + list(walk("Source", r"^build\.gradle(\.kts)?$"))
seen = set(); gcands = [p for p in gcands if os.path.exists(p) and not (p in seen or seen.add(p))]
def is_app(p):
    t = rd(p); return bool(re.search(r"com\.android\.application", t))
g = next((p for p in gcands if is_app(p)), None) or next((p for p in gcands if "defaultConfig" in rd(p)), None)
if not g: die("no Android application build.gradle found", "looked at: %s" % [rel(p) for p in gcands])
log("app module build file:", rel(g))
t = rd(g); kts = g.endswith(".kts"); q = lambda v: ('= "%s"' if kts else '"%s"') % v
def block_span(txt, head_re, start=0):
    """span (open_brace_index, close_brace_index) of the first block whose header matches head_re"""
    m = re.compile(head_re).search(txt, start)
    if not m: return None
    i = txt.index("{", m.start()); depth = 0
    for k in range(i, len(txt)):
        if txt[k] == "{": depth += 1
        elif txt[k] == "}":
            depth -= 1
            if depth == 0: return (i, k)
    return None
def insert_after_open(txt, span, line_txt):
    return txt[:span[0] + 1] + "\n        " + line_txt + txt[span[0] + 1:]

dc = block_span(t, r"\bdefaultConfig\s*\{")
if not dc: die("defaultConfig block not found in " + rel(g), "file starts with:\n" + "\n".join(t.splitlines()[:80]))

def set_or_insert(t, key_re, key, value_txt):
    """replace an existing assignment, or insert a new one at the top of defaultConfig"""
    t2, c = re.subn(key_re + r"\s*=?\s*[\"'][^\"']*[\"']", key + " " + value_txt, t, 1)
    if c: return t2, "replaced"
    span = block_span(t, r"\bdefaultConfig\s*\{")
    return insert_after_open(t, span, key + " " + value_txt), "inserted"

t, how = set_or_insert(t, r"\bapplicationId", "applicationId", q(APP_ID)); log("applicationId", how)
t, how = set_or_insert(t, r"\bversionName", "versionName", q(VERSION)); log("versionName", how)

mc = re.search(r"compileSdk(?:Version)?\s*(?:=|\s)\s*(\d+)", t); csdk = int(mc.group(1)) if mc else 0
mm = re.search(r"minSdk(?:Version)?\s*(?:=|\s)\s*(\d+)", t)
if mm and int(mm.group(1)) < 21: t = t[:mm.start(1)] + "21" + t[mm.end(1):]; log("minSdk raised to 21")
cam = "1.3.4" if csdk >= 34 else "1.2.3"
log("compileSdk=%s -> CameraX %s" % (csdk or "unknown", cam))
deps = ["androidx.camera:camera-core:" + cam, "androidx.camera:camera-camera2:" + cam, "androidx.camera:camera-lifecycle:" + cam,
        "androidx.camera:camera-view:" + cam, "com.google.mlkit:barcode-scanning:17.3.0"]
if "androidx.appcompat" not in t: deps.append("androidx.appcompat:appcompat:1.6.1")
def line(d): return ('    implementation("%s")' if kts else "    implementation '%s'") % d
if "mlkit" not in t:
    block = "\n".join(line(d) for d in deps)
    m3 = re.search(r"^dependencies\s*\{", t, re.M)
    t = (t[:m3.end()] + "\n" + block + t[m3.end():]) if m3 else (t + "\n\ndependencies {\n" + block + "\n}\n")

# ABI: arm64 only by default (much faster build, smaller APK). Set AK_ABIS=all to keep every ABI.
if os.environ.get("AK_ABIS", "arm64").lower() != "all":
    if re.search(r"abiFilters\b", t):
        t = re.sub(r"abiFilters\b[^\n}]*", ("abiFilters += listOf(\"arm64-v8a\") " if kts else "abiFilters 'arm64-v8a' "), t, 1); log("ABI filter replaced -> arm64-v8a")
    elif re.search(r"\bsplits\s*\{", t) and re.search(r"\binclude\b[^\n]*", t):
        t = re.sub(r"(\binclude\b)[^\n]*", r"\1 'arm64-v8a'", t, 1); log("ABI splits include -> arm64-v8a")
    else:
        span = block_span(t, r"\bdefaultConfig\s*\{")
        t = insert_after_open(t, span, ("ndk { abiFilters += listOf(\"arm64-v8a\") }" if kts else "ndk { abiFilters 'arm64-v8a' }")); log("ABI filter inserted -> arm64-v8a")

# lint must never fail a release build because of third-party/overlay code
if not re.search(r"abortOnError", t):
    am = block_span(t, r"\bandroid\s*\{")
    if am: t = insert_after_open(t, am, ("lint { abortOnError = false; checkReleaseBuilds = false }" if kts else "lint { abortOnError false; checkReleaseBuilds false }")); log("lint made non-fatal")
    else: log("WARNING: android {} block not found, lint left as is")
wr(g, t)
t = rd(g)
for need_s in ("mlkit", APP_ID):
    if need_s not in t: die("Gradle patch verification failed: '%s' missing in %s" % (need_s, rel(g)), "\n".join(t.splitlines()[:120]))
log("gradle patched:", rel(g))
print("----- patched %s (first 140 lines) -----" % rel(g), flush=True)
print("\n".join(t.splitlines()[:140]), flush=True)
print("----- end -----", flush=True)

# ---- 7. final verification ---------------------------------------------------------------------------------
for f in need + ["AkDefaults"]:
    if not os.path.exists(os.path.join(dst, f + ".java")): die("verification: missing " + f + ".java")
if HOOK not in rd(emu[0]): die("verification: hook missing")
log("ALL PATCHES VERIFIED - AkaiserEvodroid", VERSION)
